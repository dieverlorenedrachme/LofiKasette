// Simuliert die Java-Seite (MainActivity.command) und prüft den kompletten Speicherweg der App.
const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const ctx = await browser.newContext({ viewport: { width: 412, height: 892 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true,
    userAgent: 'Mozilla/5.0 (Linux; Android 15; CPH2653 Build/AP3A; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/140.0 Mobile Safari/537.36' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.addInitScript(() => {
    // Nachbau von MainActivity.command()/begin()/chunk()/end()
    const J = window.__java = { files: [], cur: null, log: [], screen: null };
    window.prompt = function (msg, arg) {
      if (!msg.startsWith('lofi:')) return null;
      const cmd = msg.slice(5); J.log.push(cmd);
      if (cmd === 'ping') return 'android';
      if (cmd === 'screen') { J.screen = arg; return 'ok'; }
      if (cmd === 'begin') {
        const a = arg.indexOf('\n'), b = arg.indexOf('\n', a + 1);
        if (a < 0 || b < 0) return 'error:args';
        J.cur = { kind: arg.slice(0, a), name: arg.slice(a + 1, b), mime: arg.slice(b + 1), parts: [] };
        return 'ok';
      }
      if (cmd === 'chunk') {
        if (!J.cur) return 'error:closed';
        const bin = atob(arg); const u = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
        J.cur.parts.push(u); return 'ok';
      }
      if (cmd === 'end') {
        if (!J.cur) return 'error:closed';
        const len = J.cur.parts.reduce((s, p) => s + p.length, 0), all = new Uint8Array(len);
        let o = 0; for (const p of J.cur.parts) { all.set(p, o); o += p.length; }
        J.files.push({ kind: J.cur.kind, name: J.cur.name, mime: J.cur.mime, bytes: all, chunks: J.cur.parts.length });
        J.cur = null; return 'ok';
      }
      if (cmd === 'abort') { J.cur = null; return 'ok'; }
      return 'unknown';
    };
  });
  // Die Seite muss wie in der App über file:// laufen
  await page.goto('file://' + require('path').resolve(__dirname, '../app/assets/index.html'));
  await page.waitForTimeout(500);
  const has = await page.evaluate(() => LK.UI.Native.has);
  console.log('Brücke erkannt:', has);

  await page.click('#btnPlay'); await page.waitForTimeout(600);
  const scr1 = await page.evaluate(() => __java.screen);
  await page.click('#btnPlay'); await page.waitForTimeout(200);
  const scr2 = await page.evaluate(() => __java.screen);
  console.log('Bildschirm-an beim Abspielen/Stoppen:', scr1, scr2);

  // Zurück-Taste: ohne offenes Blatt -> false (App schließt), mit Blatt -> true
  await page.click('#tabs button[data-tab="proj"]');
  const back0 = await page.evaluate(() => window.lofiBack ? lofiBack() : 'fehlt');
  await page.click('#view >> text=Als Musik speichern'); await page.waitForTimeout(200);
  const back1 = await page.evaluate(() => lofiBack());
  console.log('lofiBack ohne/mit Blatt:', back0, back1);

  // WAV-Export über die Oberfläche; Quelle abgreifen, um Byte für Byte zu vergleichen
  await page.evaluate(() => { const orig = LK.Audio.wavSource; LK.Audio.wavSource = function (b) { const s = orig(b); window.__src = s; return s; }; });
  await page.click('#view >> text=Als Musik speichern'); await page.waitForTimeout(200);
  await page.click('.sheet .chip:has-text("ca. 1 Min")');
  await page.click('text=Musik erstellen');
  await page.waitForFunction(() => /Fertig|fehlgeschlagen/.test((document.querySelector('.sheet .status') || {}).textContent || ''), null, { timeout: 180000 });
  const res = await page.evaluate(() => {
    const f = __java.files[__java.files.length - 1], ref = __src.materialize();
    let same = f.bytes.length === ref.length;
    for (let i = 0; same && i < ref.length; i++) if (f.bytes[i] !== ref[i]) same = false;
    const full = LK.Audio.encodeWav ? null : null;
    let bin = ''; for (let i = 0; i < 44; i++) bin += String.fromCharCode(f.bytes[i]);
    return { status: document.querySelector('.sheet .status').textContent, name: f.name, kind: f.kind, mime: f.mime,
             size: f.bytes.length, chunks: f.chunks, identisch: same, header: btoa(bin) };
  });
  console.log('WAV:', JSON.stringify({ ...res, header: undefined }));
  const hdr = Buffer.from(res.header, 'base64');
  console.log('RIFF', hdr.toString('ascii', 0, 4), hdr.toString('ascii', 8, 12), 'Kanäle', hdr.readUInt16LE(22), 'Rate', hdr.readUInt32LE(24), 'Bits', hdr.readUInt16LE(34), 'Daten', hdr.readUInt32LE(40), 'passt', hdr.readUInt32LE(40) + 44 === res.size);

  // Projektdatei exportieren und wieder einlesen
  await page.click('#sheetClose');
  await page.click('text=Projektdatei exportieren'); await page.waitForTimeout(300);
  const proj = await page.evaluate(() => {
    const f = __java.files[__java.files.length - 1];
    const txt = new TextDecoder().decode(f.bytes), P = JSON.parse(txt), N = LK.M.normalize(P);
    return { name: f.name, kind: f.kind, mime: f.mime, ok: JSON.stringify(N) === JSON.stringify(LK.M.normalize(LK.UI.state.P)) };
  });
  console.log('Projekt:', JSON.stringify(proj));
  console.log('Befehle:', await page.evaluate(() => [...new Set(__java.log)].join(',')));
  console.log('FEHLER:', JSON.stringify(errors));
  await browser.close();
})();
