// Kompletter Durchlauf wie ein neuer Nutzer: Stimmung wählen, Spuren tauschen, Regler, Feinschliff, Export.
// Die Java-Seite der App (Speichern über prompt-Brücke) wird nachgespielt.
const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
const path = require('path');
const UA = 'Mozilla/5.0 (Linux; Android 14; CPH2581 Build/UKQ1.230924.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/129.0.0.0 Mobile Safari/537.36';
const results = [];
function check(name, ok, info) { results.push({ name, ok: !!ok, info }); }

(async () => {
  const b = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const ctx = await b.newContext({ viewport: { width: 412, height: 892 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: UA });
  const p = await ctx.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push('pageerror: ' + e.message));
  p.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errs.push(m.type() + ': ' + m.text()); });
  const saved = []; let cur = null;
  p.on('dialog', async d => {
    const msg = d.message();
    if (d.type() !== 'prompt' || !msg.startsWith('lofi:')) { errs.push('fremder Dialog ' + msg); return d.dismiss(); }
    const cmd = msg.slice(5), arg = d.defaultValue();
    if (cmd === 'ping') return d.accept('android');
    if (cmd === 'screen') return d.accept('ok');
    if (cmd === 'begin') { const [kind, name, mime] = arg.split('\n'); cur = { kind, name, mime, parts: [] }; return d.accept('ok'); }
    if (cmd === 'chunk') { cur.parts.push(Buffer.from(arg, 'base64')); return d.accept('ok'); }
    if (cmd === 'end') { cur.data = Buffer.concat(cur.parts); delete cur.parts; saved.push(cur); cur = null; return d.accept('ok'); }
    if (cmd === 'abort') { cur = null; return d.accept('ok'); }
    return d.accept('unknown');
  });
  const P = () => p.evaluate(() => LK.UI.state.P);
  const songStyles = {};
  function LK_songStyle(id) { return songStyles[id]; }
  const shot = n => p.screenshot({ path: path.resolve(__dirname, '../shots/' + n + '.png') });
  await p.goto('file://' + path.resolve(__dirname, '../app/assets/index.html'));
  await p.waitForTimeout(1000);
  Object.assign(songStyles, await p.evaluate(() => Object.fromEntries(LK.SONGS.map(s => [s.id, s.style]))));

  // 1. Start im Studio mit Anleitung
  check('Start im Studio', await p.locator('#tabs button[data-tab="studio"].on').count() === 1);
  check('Anleitung sichtbar', await p.locator('.intro').count() === 1);
  await p.click('.intro .text-btn');
  check('Anleitung weggeklickt', await p.locator('.intro').count() === 0);
  check('9 Stimmungen', await p.locator('.styles .style').count() === 9);

  // 2. Stimmung antippen = neuer Track, spielt sofort
  await p.click('.style[data-style="bossa"]');
  await p.waitForTimeout(2200);
  let st = await P();
  check('Stil Bossa gewählt', st.style === 'bossa' && st.drums.pattern === 'bossa' && st.chords.inst === 'guitar', st.name);
  check('spielt sofort', await p.evaluate(() => LK.Audio.isPlaying()));
  const meta = await p.textContent('#cMeta');
  check('Deck zeigt Stimmung und Songteil', /Bossa am Meer/.test(meta) && /(Intro|Teil A)/.test(meta), meta);
  check('Karte markiert', await p.locator('.style[data-style="bossa"].on').count() === 1);
  check('Grundmusik geladen', !!st.song_id && LK_songStyle(st.song_id) === 'bossa', st.song_id);
  check('4 Grundmusiken zur Auswahl', await p.locator('.songs .chip').count() === 4);
  const other = await p.locator('.songs .chip:not(.on)').first().getAttribute('data-song');
  await p.click(`.songs .chip[data-song="${other}"]`);
  st = await P();
  check('andere Grundmusik gewählt', st.song_id === other && await p.locator(`.songs .chip.on[data-song="${other}"]`).count() === 1, st.name);
  await p.waitForTimeout(1500);

  // 3. "Anders" tauscht nur eine Spur
  const melBefore = JSON.stringify(st.melody.notes), chordsBefore = JSON.stringify(st.chords.list);
  await p.click('.layer[data-layer="melody"] .lagain');
  st = await P();
  check('Anders: neue Melodie', JSON.stringify(st.melody.notes) !== melBefore);
  check('Anders: Akkorde unverändert', JSON.stringify(st.chords.list) === chordsBefore);
  await p.click('.layer[data-layer="chords"] .lagain');
  st = await P();
  check('Anders: neue Akkordfolge', JSON.stringify(st.chords.list) !== chordsBefore, st.chords.prog);

  // 4. Spur aus- und einschalten
  await p.click('.layer[data-layer="bass"] .lsw');
  check('Bass stumm', (await P()).mute.bass === true);
  check('Zeile gedimmt', await p.locator('.layer[data-layer="bass"].muted').count() === 1);
  await p.click('.layer[data-layer="bass"] .lsw');
  check('Bass wieder an', (await P()).mute.bass === false);

  // 5. Umgebung aufklappen und wechseln
  await p.click('.layer[data-layer="atmo"] .lmain');
  await p.click('.layer[data-layer="atmo"] .lmore .chip[data-id="cafe"]');
  check('Umgebung Café', (await P()).atmo.type === 'cafe');

  // 6. Makro-Regler "Lofi", Farbe, Ablauf
  const fxBefore = (await P()).fx;
  await p.evaluate(() => {
    const inp = [...document.querySelectorAll('.slider')].find(s => s.querySelector('.top span').textContent === 'Lofi').querySelector('input');
    inp.dispatchEvent(new Event('pointerdown')); inp.value = 95; inp.dispatchEvent(new Event('input')); inp.dispatchEvent(new Event('change'));
  });
  const fxAfter = (await P()).fx;
  check('Lofi-Regler färbt mehrere Effekte', fxAfter.vinyl > fxBefore.vinyl && fxAfter.filter < fxBefore.filter && fxAfter.wobble > fxBefore.wobble && fxAfter.crush === 0, fxAfter);
  const modeBefore = (await P()).mode;
  const target = modeBefore === 'minor' ? 'major' : 'minor';
  await p.click(`#view .seg button[data-id="${target}"]`);
  check('Farbe gewechselt', (await P()).mode === target);
  await p.click('#view .seg button[data-id="loop"]');
  check('Ablauf Schleife', (await P()).song === 'loop');
  await p.waitForTimeout(700);
  check('Deck zeigt Schleife', /Schleife/.test(await p.textContent('#cMeta')));
  await shot('t-studio');

  // 7. Neu würfeln bleibt in der Stimmung, Rückgängig
  const nameA = (await P()).name;
  await p.click('#btnNew');
  st = await P();
  check('Neu würfeln bleibt im Stil', st.style === 'bossa' && st.name !== nameA, st.name);
  await p.click('#btnUndo');
  check('Rückgängig', (await P()).name === nameA);

  // 8. Feinschliff
  await p.click('#tabs button[data-tab="edit"]');
  await p.click('.subnav button[data-id="beat"]');
  const kick0 = (await P()).drums.steps.kick.join('');
  await p.locator('#view .grid .cell[data-r="0"][data-c="4"]').first().click();
  check('Beat-Raster', (await P()).drums.steps.kick.join('') !== kick0);
  await p.waitForTimeout(300);
  check('Laufposition im Raster', await p.locator('#view .cell.now').count() > 0);
  await p.click('.subnav button[data-id="harm"]');
  await p.locator('#view [data-bar="1"]').first().click();
  await p.waitForTimeout(250);
  await p.click('#sheet .seg button[data-id="h2"]');
  st = await P();
  check('Takt geteilt', !!st.chords.list[1].h2, st.chords.list[1]);
  await p.locator('#sheet .switch', { hasText: 'Halbton' }).click();
  check('♭ für zweite Hälfte', (await P()).chords.list[1].h2.a === -1, (await P()).chords.list[1]);
  await shot('t-chordsheet');
  check('Zurück schließt Blatt', await p.evaluate(() => window.lofiBack()) === true);
  await p.waitForTimeout(300);
  check('Zurück ohne Blatt = App verlassen', await p.evaluate(() => window.lofiBack()) === false);
  check('Karte zeigt beide Akkorde', /\//.test(await p.textContent('#view [data-bar="1"] .name')));
  await p.click('.subnav button[data-id="mel"]');
  const m0 = (await P()).melody.notes[0][6];
  await p.locator('#view .grid .cell[data-r="2"][data-c="6"]').first().click();
  check('Melodie-Raster', (await P()).melody.notes[0][6] !== m0);
  await p.click('.subnav button[data-id="sound"]');
  await p.click('#view .chip[data-id="meer"]');
  check('Klang: Umgebung Meer', (await P()).atmo.type === 'meer');
  await shot('t-sound');

  // 9. App in den Hintergrund
  await p.evaluate(() => window.lofiPause());
  check('Pause stoppt', !(await p.evaluate(() => LK.Audio.isPlaying())));

  // 10. Export aus dem Studio (ca. 1 Minute, mit Intro/Outro)
  await p.click('#tabs button[data-tab="studio"]');
  await p.click('#view .cta .action.primary');
  await p.waitForTimeout(300);
  await p.click('#sheet .chip[data-id="1"]');
  const shownDur = await p.textContent('#sheet .bigdur');
  await shot('t-export');
  const t0 = Date.now();
  await p.locator('#sheet button', { hasText: 'Musik erstellen' }).click();
  await p.waitForFunction(() => /Fertig|fehlgeschlagen/.test(document.querySelector('#sheet .status').textContent), null, { timeout: 180000 });
  const status = await p.textContent('#sheet .status');
  check('Export fertig', /Fertig/.test(status), status + ' (' + (Date.now() - t0) + ' ms)');
  await p.evaluate(() => window.lofiBack());
  const wav = saved.find(s => s.kind === 'audio');
  if (wav) {
    const d = wav.data, sec = d.readUInt32LE(40) / 4 / 44100;
    let pk = 0; for (let i = 44; i < d.length; i += 2) pk = Math.max(pk, Math.abs(d.readInt16LE(i)));
    check('WAV gültig', d.toString('ascii', 0, 4) === 'RIFF' && d.readUInt32LE(24) === 44100 && d.readUInt16LE(22) === 2, { name: wav.name, sec: sec.toFixed(1), shownDur, peak: pk });
    check('Länge ca. 1 Minute', sec > 40 && sec < 85, sec.toFixed(1));
    require('fs').writeFileSync(path.resolve(__dirname, 'export.wav'), d);
  } else check('WAV gespeichert', false);

  // 11. Projekt: Datei, Neuladen
  await p.click('#tabs button[data-tab="proj"]');
  await p.getByText('Projektdatei exportieren').click();
  await p.waitForTimeout(400);
  const proj = saved.find(s => s.kind === 'download');
  check('Projektdatei', proj && JSON.parse(proj.data.toString()).v === 2, proj && proj.name);
  const nameNow = (await P()).name;
  await p.waitForTimeout(500);
  await p.reload(); await p.waitForTimeout(900);
  check('Autosave nach Neuladen', (await P()).name === nameNow);
  check('Reiter gemerkt', await p.locator('#tabs button[data-tab="proj"].on').count() === 1);

  // 12. Alte v1-Projekte werden übernommen
  const mig = await p.evaluate(() => {
    const v1 = { name: 'Alt', bpm: 80, key: 3, mode: 'major', bars: 4, fx: { vinyl: 30, rain: 60, filter: 50 }, bass: { on: false, inst: 'sub', style: 'grund' },
      chords: { inst: 'rhodes', style: 'halten', list: [{ d: 0, q: 'maj7' }, { d: 3, q: 'maj7' }, { d: 1, q: 'm9' }, { d: 4, q: '9' }] } };
    const n = LK.M.normalize(v1);
    return { atmo: n.atmo, muteBass: n.mute.bass, style: n.style, echo: n.fx.echo, song: n.song, list8: n.chords.list.length };
  });
  check('v1-Migration', mig.atmo.type === 'regen' && mig.atmo.amount === 60 && mig.muteBass && mig.style === 'eigen' && mig.echo === 0 && mig.song === 'loop', mig);

  const failed = results.filter(r => !r.ok);
  results.forEach(r => console.log((r.ok ? 'OK    ' : 'FEHLT ') + r.name + (r.info !== undefined ? '  ' + JSON.stringify(r.info) : '')));
  console.log(`\n${results.length - failed.length}/${results.length} bestanden`);
  console.log('Fehler/Warnungen:', JSON.stringify(errs));
  await b.close();
  process.exit(failed.length || errs.length ? 1 : 0);
})();
