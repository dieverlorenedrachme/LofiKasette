const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const ctx = await browser.newContext({ viewport: { width: 412, height: 892 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, acceptDownloads: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.type() + ': ' + m.text()); });
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  await page.goto('file://' + require('path').resolve(__dirname, '../app/assets/index.html'));
  await page.waitForTimeout(500);
  // Live-Wiedergabe
  await page.click('#btnPlay');
  await page.waitForTimeout(2500);
  const live = await page.evaluate(() => ({ state: LK.Audio.ensure().ctx.state, pos: LK.Audio.position(), playing: LK.Audio.isPlaying(),
    reelClass: document.getElementById('cassette').classList.contains('playing'), nowCells: document.querySelectorAll('.cell.now').length }));
  console.log('LIVE', JSON.stringify(live));
  await page.screenshot({ path: require('path').resolve(__dirname, '../shots/playing.png') });
  // Neuer Track während Wiedergabe, dann Stopp
  await page.click('#btnNew'); await page.waitForTimeout(800);
  await page.click('#btnPlay'); await page.waitForTimeout(300);
  console.log('STOPPED', await page.evaluate(() => LK.Audio.isPlaying()));

  // Offline-Renderings analysieren
  const res = await page.evaluate(async () => {
    function stats(buf, P, loops, song) {
      const sr = buf.sampleRate, ch = [buf.getChannelData(0), buf.getChannelData(1)];
      let peak = 0, sum = 0, nan = 0;
      for (const a of ch) for (let i = 0; i < a.length; i++) { const v = a[i]; if (v !== v) nan++; else { const x = Math.abs(v); if (x > peak) peak = x; sum += v * v; } }
      const rms = Math.sqrt(sum / (ch[0].length * 2));
      // RMS je Abschnitt (Schleife)
      const loopDur = P.bars * 16 * 60 / P.bpm / 4, secs = [];
      for (let t = 0; t + 0.5 < buf.duration; t += loopDur) {
        let s2 = 0, n = 0; const a = ch[0], i0 = Math.floor(t * sr), i1 = Math.min(a.length, Math.floor((t + loopDur) * sr));
        for (let i = i0; i < i1; i++) { s2 += a[i] * a[i]; n++; }
        secs.push(+(20 * Math.log10(Math.sqrt(s2 / Math.max(1, n)) + 1e-9)).toFixed(1));
      }
      return { dur: +buf.duration.toFixed(2), peak: +peak.toFixed(3), rmsDb: +(20 * Math.log10(rms)).toFixed(1), nan, secs };
    }
    const out = [];
    const T = LK.M.templates();
    for (const P of T) {
      const t0 = performance.now();
      const buf = await LK.Audio.render(P, { loops: 2, songForm: true });
      out.push({ name: P.name, ms: Math.round(performance.now() - t0), ...stats(buf, P, 2, true) });
    }
    for (let seed = 1; seed <= 6; seed++) {
      const P = LK.M.randomProject(LK.M.seeded(seed));
      const t0 = performance.now();
      const buf = await LK.Audio.render(P, { loops: 1, songForm: false });
      out.push({ name: 'zufall' + seed + ' ' + P.name + ' ' + P.chords.inst + '/' + P.melody.inst + '/' + P.bass.inst, ms: Math.round(performance.now() - t0), ...stats(buf, P, 1, false) });
    }
    // Langer Export: 12 Durchläufe mit Songform
    const P = T[0]; const t0 = performance.now();
    const buf = await LK.Audio.render(P, { loops: 12, songForm: true });
    const wav = LK.Audio.encodeWav(buf);
    out.push({ name: 'lang', ms: Math.round(performance.now() - t0), wavMB: +(wav.bytes.length / 1e6).toFixed(1), ...stats(buf, P, 12, true) });
    return out;
  });
  res.forEach(r => console.log(JSON.stringify(r)));
  console.log('ERRORS:', JSON.stringify(errors));
  await browser.close();
})();
