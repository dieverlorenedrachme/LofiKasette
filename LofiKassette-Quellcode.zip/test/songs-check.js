// Prüft alle Grundmusiken ohne Browser: Gültigkeit, Melodie passt zu den Akkorden, Stabilität beim Speichern
global.window = {};
const fs = require('fs'), path = require('path');
for (const f of ['music.js', 'songs.js']) eval(fs.readFileSync(path.resolve(__dirname, '../app/assets/js/' + f), 'utf8'));
const LK = window.LK, M = LK.M;
let bad = 0;
const ids = new Set();
function fail(sg, msg) { bad++; console.log('FEHLER', sg.id, msg); }
for (const sg of LK.SONGS) {
  if (ids.has(sg.id)) fail(sg, 'doppelte Kennung'); ids.add(sg.id);
  if (!M.STYLE_BY_ID[sg.style]) fail(sg, 'Stimmung ' + sg.style);
  if (M.parseProg(sg.chords).length !== 8) fail(sg, 'nicht 8 Takte Akkorde');
  if (!M.byId(M.CHORD_INST, sg.inst)) fail(sg, 'Akkordinstrument ' + sg.inst);
  if (!M.byId(M.MELODY_INST, sg.mel[0])) fail(sg, 'Melodieinstrument ' + sg.mel[0]);
  if (!M.byId(M.BASS_INST, sg.bass[0])) fail(sg, 'Bass ' + sg.bass[0]);
  if (sg.bass[1].length === 16 ? !/^[r357oa.\-]{16}$/.test(sg.bass[1]) : !M.byId(M.BASS_STYLES, sg.bass[1])) fail(sg, 'Basslinie ' + sg.bass[1]);
  if (!M.byId(M.KITS, sg.kit)) fail(sg, 'Kit ' + sg.kit);
  if (Array.isArray(sg.drums)) { if (sg.drums.length !== 5 || sg.drums.some(r => !/^[xor.]{16}$/.test(r))) fail(sg, 'Schlagzeugzeilen'); }
  else if (sg.drums !== 'aus' && !M.byId(M.DRUM_PRESETS, sg.drums)) fail(sg, 'Muster ' + sg.drums);
  if (sg.mel[4].length !== 8 || sg.mel[4].some(b => !/^[0-9.]{16}$/.test(b))) fail(sg, 'Melodiezeilen');
  if (!M.byId(M.ATMOS, sg.atmo[0])) fail(sg, 'Umgebung ' + sg.atmo[0]);
  const P = M.fromSong(sg.id);
  const issues = M.melodyIssues(P);
  if (issues.length) fail(sg, 'Melodie reibt mit Akkord bei Takt:Schritt ' + issues.join(' '));
  const N = M.normalize(JSON.parse(JSON.stringify(P)));
  if (JSON.stringify(N) !== JSON.stringify(P)) fail(sg, 'Speichern/Laden verändert das Projekt');
  const D = M.derive(P), notes = P.melody.notes.flat().filter(r => r >= 0).map(r => D.rows[r]);
  if (Math.min(...notes) < 45 || Math.max(...notes) > 100) fail(sg, 'Melodie außerhalb des Tonumfangs ' + Math.min(...notes) + '–' + Math.max(...notes));
}
const per = {}; LK.SONGS.forEach(s => per[s.style] = (per[s.style] || 0) + 1);
// Vielfalt: Kombinationen und Eckdaten
const combos = new Set(LK.SONGS.map(s => [s.inst, s.mel[0], s.bass[0], s.kit].join('/')));
const bpms = LK.SONGS.map(s => s.bpm);
console.log(LK.SONGS.length, 'Grundmusiken', JSON.stringify(per));
console.log('verschiedene Klangkombinationen:', combos.size, ' Tempo', Math.min(...bpms) + '–' + Math.max(...bpms), 'BPM',
  ' Tonarten', new Set(LK.SONGS.map(s => s.key + s.mode)).size, ' Grooves', new Set(LK.SONGS.map(s => JSON.stringify(s.drums))).size,
  ' Basslinien', new Set(LK.SONGS.map(s => s.bass.join())).size);
console.log(bad ? bad + ' Fehler' : 'alles in Ordnung');
process.exit(bad ? 1 : 0);
