// Klarheit und Rauschen messen: je Stimmung komplett / nur Musik / nur Geräusche (Vinyl, Umgebung)
const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto('file://' + require('path').resolve(__dirname, 'engine-test.html'));
  const res = await p.evaluate(async (which) => {
    if (LK.Audio.ready) await LK.Audio.ready();
    const db = x => +(10 * Math.log10(x + 1e-12)).toFixed(1);
    function power(buf, from, to) { const d = buf.getChannelData(0); let s = 0; const a = Math.floor(from * d.length), e = Math.floor(to * d.length); for (let i = a; i < e; i++) s += d[i] * d[i]; return s / Math.max(1, e - a); }
    async function band(buf, type, f) {
      const c = new OfflineAudioContext(1, buf.length, buf.sampleRate), s = c.createBufferSource(), fl = c.createBiquadFilter(), f2 = c.createBiquadFilter();
      s.buffer = buf; fl.type = type; fl.frequency.value = f; f2.type = type; f2.frequency.value = f; s.connect(fl); fl.connect(f2); f2.connect(c.destination); s.start();
      return power(await c.startRendering(), 0.05, 0.95);
    }
    function floor(buf) { // leiseste 10 % der 50-ms-Fenster
      const d = buf.getChannelData(0), w = Math.floor(buf.sampleRate * 0.05), v = [];
      for (let i = Math.floor(d.length * 0.05); i + w < d.length * 0.95; i += w) { let s = 0; for (let k = 0; k < w; k++) s += d[i + k] * d[i + k]; v.push(s / w); }
      v.sort((a, b) => a - b); return v[Math.floor(v.length * 0.1)];
    }
    const out = [];
    const [w0, a0, b0] = which.split(':'); const list = w0 === 'songs' ? LK.SONGS.slice(+a0 || 0, +b0 || 40).map(s => LK.M.fromSong(s.id)) : LK.M.STYLES.map((st, i) => LK.M.fromStyle(st.id, LK.M.seeded(40 + i)));
    for (const P0 of list) {
      const P = LK.M.normalize(P0);
      const full = await LK.Audio.render(P, { loops: 2, songForm: false });
      const M = LK.M.copy(P); M.mute.atmo = true; M.fx.vinyl = 0;
      const music = await LK.Audio.render(M, { loops: 2, songForm: false });
      const N = LK.M.copy(P); ['drums', 'chords', 'bass', 'melody'].forEach(k => N.mute[k] = true);
      const noise = await LK.Audio.render(N, { loops: 2, songForm: false });
      const tot = power(full, 0.05, 0.95);
      out.push({ id: (P.song_id || P.style), full: db(tot), noise: db(power(noise, 0.05, 0.95)),
        snr: +(db(power(music, 0.05, 0.95)) - db(power(noise, 0.05, 0.95))).toFixed(1), floor: db(floor(music)),
        air: +(db(await band(full, 'highpass', 5000)) - db(tot)).toFixed(1), mud: +(db(await band(full, 'bandpass', 300)) - db(tot)).toFixed(1),
        lp: Math.round(600 * Math.pow(30, P.fx.filter / 100)) });
    }
    return out;
  }, process.argv[2] || 'styles');
  res.forEach(r => console.log(JSON.stringify(r)));
  const avg = k => (res.reduce((a, r) => a + r[k], 0) / res.length).toFixed(1);
  console.log('MITTEL', JSON.stringify({ snr: avg('snr'), noise: avg('noise'), floor: avg('floor'), air: avg('air'), mud: avg('mud') }));
  console.log('Fehler:', JSON.stringify(errs));
  await b.close();
})();
