// Screenshot-Rundgang durch alle Ansichten (412 px, OnePlus-Breite)
const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const ctx = await browser.newContext({ viewport: { width: 412, height: 892 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.type() + ': ' + m.text()); });
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/assets/index.html'));
  await page.waitForTimeout(600);
  const shot = n => page.screenshot({ path: path.resolve(__dirname, `../shots/${n}.png`) });
  await shot('studio');
  await page.click('#tabs button[data-tab="edit"]');
  for (const sub of ['beat', 'harm', 'mel', 'sound']) {
    await page.click(`.subnav button[data-id="${sub}"]`);
    await page.waitForTimeout(200);
    await shot('edit-' + sub);
  }
  await page.click('#tabs button[data-tab="proj"]');
  await page.waitForTimeout(200);
  await shot('proj');
  console.log('ERRORS:', JSON.stringify(errors, null, 1));
  await browser.close();
})();
