const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
(async () => {
  const b = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type()==='error') errs.push(m.text()); });
  await p.goto('file://' + require('path').resolve(__dirname, 'engine-test.html'));
  const res = await p.evaluate(async () => {
    const out = [];
    const T = LK.M.templates();
    const projs = T.concat([LK.M.randomProject(LK.M.seeded(1)), LK.M.randomProject(LK.M.seeded(2)), LK.M.randomProject(LK.M.seeded(3))]);
    for (const P0 of projs) {
      const P = LK.M.normalize(P0);
      const t0 = performance.now();
      const buf = await LK.Audio.render(P, { loops: 2, songForm: true });
      const ms = performance.now() - t0;
      let peak = 0, sum = 0, nan = 0; const d0 = buf.getChannelData(0), d1 = buf.getChannelData(1);
      for (let i = 0; i < d0.length; i++) { const v = d0[i]; if (!isFinite(v) || !isFinite(d1[i])) nan++; else { peak = Math.max(peak, Math.abs(v), Math.abs(d1[i])); sum += v*v; } }
      // RMS in Abschnitten (Intro leise gefiltert, Mitte voll, Ende ausgeblendet)
      const seg = n => { const a = Math.floor(d0.length*n), e = a + 44100; let s=0; for (let i=a;i<e && i<d0.length;i++) s+=d0[i]*d0[i]; return Math.sqrt(s/44100).toFixed(3); };
      const w = LK.Audio.encodeWav(buf);
      out.push({ name: P.name, inst: P.chords.inst+'/'+P.melody.inst+'/'+P.bass.inst+'/'+P.drums.kit, style: P.chords.style, sec: buf.duration.toFixed(1), renderMs: Math.round(ms), peak: peak.toFixed(3), rms: Math.sqrt(sum/d0.length).toFixed(3), nan, segs: [seg(0.05), seg(0.5), seg(0.97)], wavBytes: w.bytes.length });
    }
    return out;
  });
  console.log(JSON.stringify(res, null, 1));
  console.log('Fehler:', errs);
  await b.close();
})();
