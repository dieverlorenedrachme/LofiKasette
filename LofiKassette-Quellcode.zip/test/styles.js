// Rendert jeden Stil mit mehreren Zufallsständen und misst Pegel, Helligkeit, Dichte und Tempo.
const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
const path = require('path');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto('file://' + path.resolve(__dirname, 'engine-test.html'));
  const res = await p.evaluate(async () => {
    const out = [];
    function analyse(buf) {
      const L = buf.getChannelData(0), R = buf.getChannelData(1), n = L.length, sr = buf.sampleRate;
      let s = 0, pk = 0, nan = 0, zc = 0, prev = 0;
      const win = Math.floor(sr * 0.02), env = [];
      let acc = 0;
      for (let i = 0; i < n; i++) {
        const m = (L[i] + R[i]) / 2;
        if (!isFinite(m)) { nan++; continue; }
        s += m * m; pk = Math.max(pk, Math.abs(L[i]), Math.abs(R[i]));
        if ((m > 0) !== (prev > 0)) zc++; prev = m;
        acc += m * m; if ((i + 1) % win === 0) { env.push(Math.sqrt(acc / win)); acc = 0; }
      }
      // Anschläge pro Sekunde: Sprünge in der Hüllkurve
      let on = 0; for (let i = 2; i < env.length; i++) if (env[i] > env[i - 1] * 1.35 && env[i] > 0.02) on++;
      // Bass-Anteil: Energie eines einfachen Tiefpasses relativ zur Gesamtenergie
      let lp = 0, lpE = 0, a = 1 - Math.exp(-2 * Math.PI * 150 / sr);
      for (let i = 0; i < n; i++) { lp += a * ((L[i] + R[i]) / 2 - lp); lpE += lp * lp; }
      return { rmsDb: +(10 * Math.log10(s / n + 1e-12)).toFixed(1), peak: +pk.toFixed(2), nan,
               bright: Math.round(zc / (n / sr) / 2), onsets: +(on / (n / sr)).toFixed(1), bass: +(lpE / s).toFixed(2) };
    }
    for (const st of LK.M.STYLES) {
      for (let k = 0; k < 3; k++) {
        const P = LK.M.normalize(LK.M.fromStyle(st.id, LK.M.seeded(100 + k * 17 + st.id.length)));
        const t0 = performance.now();
        const buf = await LK.Audio.render(P, { loops: 2, songForm: false });
        const a = analyse(buf);
        out.push(Object.assign({ style: st.id, k, bpm: P.bpm, mode: P.mode, inst: [P.chords.inst, P.melody.inst, P.bass.inst, P.drums.kit, P.atmo.type].join('/'),
          drums: P.mute.drums ? 'aus' : P.drums.pattern, ms: Math.round(performance.now() - t0) }, a));
      }
    }
    return out;
  });
  for (const r of res) console.log(JSON.stringify(r));
  console.log('FEHLER:', JSON.stringify(errs));
  await b.close();
})();
