// Prüft die Live-Wiedergabe bei Handy-typischen Abtastraten und misst, ob wirklich Ton herauskommt.
const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  let allOk = true;
  for (const rate of [48000, 44100, 96000]) {
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
    // AudioContext wie auf dem Handy mit fester Geräte-Abtastrate erzeugen
    await page.addInitScript((sr) => {
      const Orig = window.AudioContext;
      window.AudioContext = function (opts) { return new Orig(Object.assign({}, opts || {}, { sampleRate: sr })); };
      window.AudioContext.prototype = Orig.prototype;
    }, rate);
    await page.goto('file://' + path.resolve(__dirname, '../app/assets/index.html'));
    await page.waitForTimeout(600);
    await page.click('#btnPlay');
    // Ausgang anzapfen und Pegel messen
    const res = await page.evaluate(async () => {
      const L = LK.Audio.ensure();
      const an = L.ctx.createAnalyser(); an.fftSize = 2048;
      L.E.limiter.connect(an);
      const buf = new Float32Array(an.fftSize);
      let peak = 0, frames = 0;
      const t0 = L.ctx.currentTime;
      for (let i = 0; i < 40; i++) {
        await new Promise(r => setTimeout(r, 50));
        an.getFloatTimeDomainData(buf);
        for (const v of buf) peak = Math.max(peak, Math.abs(v));
        frames++;
      }
      return { state: L.ctx.state, rate: L.ctx.sampleRate, advanced: +(L.ctx.currentTime - t0).toFixed(2), peak: +peak.toFixed(3),
               playing: LK.Audio.isPlaying(), btnOn: document.getElementById('btnPlay').classList.contains('on') };
    }).catch(e => ({ error: e.message }));
    const ok = !res.error && res.peak > 0.05 && res.playing && !errors.length;
    allOk = allOk && ok;
    console.log(rate + ' Hz:', ok ? 'TON OK' : 'KEIN TON', JSON.stringify(res), errors.length ? 'Fehler: ' + errors.join(' | ') : '');
    await page.close();
  }
  await browser.close();
  process.exit(allOk ? 0 : 1);
})();
