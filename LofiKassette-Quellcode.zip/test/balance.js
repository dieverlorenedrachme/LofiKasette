// Pegel der Umgebungen und des Vinyls im Vergleich zur Musik (gleiche Kette wie im Export)
const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage();
  await p.goto('file://' + require('path').resolve(__dirname, 'engine-test.html'));
  const res = await p.evaluate(async () => {
    const out = {};
    async function level(P) {
      const buf = await LK.Audio.render(P, { loops: 1, songForm: false });
      const d = buf.getChannelData(0); let s = 0;
      for (let i = 0; i < d.length; i++) s += d[i] * d[i];
      return +(10 * Math.log10(s / d.length + 1e-12)).toFixed(1);
    }
    const base = LK.M.normalize(LK.M.templates()[0]);
    out.musik = await level(LK.M.copy(base));
    const quiet = P => { ['drums', 'chords', 'melody', 'bass'].forEach(x => P.mute[x] = true); P.fx.pump = 0; return P; };
    { const P = quiet(LK.M.copy(base)); P.atmo.type = 'keine'; P.fx.vinyl = 40; out.vinyl40 = await level(P); }
    for (const a of LK.M.ATMOS) {
      if (a.id === 'keine') continue;
      const P = quiet(LK.M.copy(base)); P.fx.vinyl = 0; P.atmo = { type: a.id, amount: 50 };
      out[a.id + '50'] = await level(P);
    }
    return out;
  });
  console.log(JSON.stringify(res));
  await b.close();
})();
