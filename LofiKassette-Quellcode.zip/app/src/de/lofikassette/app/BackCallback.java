package de.lofikassette.app;

import android.webkit.ValueCallback;

/** Ergebnis von lofiBack(): "true" = Oberfläche hat die Zurück-Taste verarbeitet. */
class BackCallback implements ValueCallback<String> {
    final MainActivity activity;

    BackCallback(MainActivity activity) {
        this.activity = activity;
    }

    @Override
    public void onReceiveValue(String value) {
        activity.backResult(value);
    }
}
