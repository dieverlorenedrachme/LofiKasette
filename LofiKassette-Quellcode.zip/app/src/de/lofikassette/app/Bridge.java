package de.lofikassette.app;

import android.net.Uri;
import android.webkit.JsPromptResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

/** Verbindet die lokale Seite mit der Activity (prompt-Brücke, Dateiauswahl). */
class Bridge extends WebChromeClient {
    final MainActivity activity;

    Bridge(MainActivity activity) {
        this.activity = activity;
    }

    @Override
    public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
        if (url == null || !url.startsWith("file:///android_asset/")) {
            return false;
        }
        if (message == null || !message.startsWith("lofi:")) {
            return false;
        }
        result.confirm(activity.command(message.substring(5), defaultValue));
        return true;
    }

    @Override
    public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
        return activity.openChooser(callback, params);
    }
}
