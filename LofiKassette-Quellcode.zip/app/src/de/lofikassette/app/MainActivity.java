package de.lofikassette.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Window;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.io.OutputStream;

/**
 * Hülle für die lokale Oberfläche in assets/: WebView ohne Internet,
 * Speichern über MediaStore (Musik/LofiKassette, Download/LofiKassette),
 * Dateiauswahl für Projektdateien und Zurück-Taste.
 */
public class MainActivity extends Activity {
    static final int BG = 0xFF1D1829;
    static final int PICK_FILE = 7;
    static final int FLAG_KEEP_SCREEN_ON = 0x00000080;
    static final int FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS = 0x80000000;

    WebView web;
    ValueCallback<Uri[]> chooser;
    OutputStream out;
    Uri outUri;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window w = getWindow();
        w.addFlags(FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        w.setBackgroundDrawable(new ColorDrawable(BG));
        w.getDecorView().setSystemUiVisibility(0);

        web = new WebView(this);
        web.setBackgroundColor(BG);
        web.setOverScrollMode(2);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        web.setWebChromeClient(new Bridge(this));
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onPause() {
        getWindow().clearFlags(FLAG_KEEP_SCREEN_ON);
        if (web != null) {
            web.evaluateJavascript("window.lofiPause&&lofiPause()", null);
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        abort();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("window.lofiBack?lofiBack():false", new BackCallback(this));
    }

    void backResult(String value) {
        if (!"true".equals(value)) {
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_FILE) {
            if (chooser != null) {
                chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                chooser = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    boolean openChooser(ValueCallback<Uri[]> callback, WebChromeClient.FileChooserParams params) {
        if (chooser != null) {
            chooser.onReceiveValue(null);
        }
        chooser = callback;
        try {
            startActivityForResult(params.createIntent(), PICK_FILE);
            return true;
        } catch (Exception e) {
            chooser = null;
            return false;
        }
    }

    /** Befehle der Oberfläche (über prompt("lofi:befehl", argument)). */
    String command(String cmd, String arg) {
        if ("ping".equals(cmd)) {
            return "android";
        }
        if ("begin".equals(cmd)) {
            return begin(arg);
        }
        if ("chunk".equals(cmd)) {
            return chunk(arg);
        }
        if ("end".equals(cmd)) {
            return end();
        }
        if ("abort".equals(cmd)) {
            abort();
            return "ok";
        }
        if ("screen".equals(cmd)) {
            if ("1".equals(arg)) {
                getWindow().addFlags(FLAG_KEEP_SCREEN_ON);
            } else {
                getWindow().clearFlags(FLAG_KEEP_SCREEN_ON);
            }
            return "ok";
        }
        return "unknown";
    }

    /** arg = "audio|download" + "\n" + Dateiname + "\n" + MIME-Typ */
    String begin(String arg) {
        abort();
        if (arg == null) {
            return "error:args";
        }
        int a = arg.indexOf('\n');
        if (a < 0) {
            return "error:args";
        }
        int b = arg.indexOf('\n', a + 1);
        if (b < 0) {
            return "error:args";
        }
        String kind = arg.substring(0, a);
        String name = arg.substring(a + 1, b);
        String mime = arg.substring(b + 1);
        try {
            ContentValues v = new ContentValues();
            v.put("_display_name", name);
            v.put("mime_type", mime);
            Uri target;
            if ("audio".equals(kind)) {
                v.put("relative_path", "Music/LofiKassette");
                target = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            } else {
                v.put("relative_path", "Download/LofiKassette");
                target = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            }
            v.put("is_pending", Integer.valueOf(1));
            ContentResolver r = getContentResolver();
            outUri = r.insert(target, v);
            if (outUri == null) {
                return "error:insert";
            }
            out = r.openOutputStream(outUri);
            if (out == null) {
                abort();
                return "error:stream";
            }
            return "ok";
        } catch (Exception e) {
            abort();
            return "error:" + e.getMessage();
        }
    }

    String chunk(String data) {
        if (out == null) {
            return "error:closed";
        }
        try {
            out.write(Base64.decode(data, Base64.DEFAULT));
            return "ok";
        } catch (Exception e) {
            abort();
            return "error:" + e.getMessage();
        }
    }

    String end() {
        if (out == null) {
            return "error:closed";
        }
        try {
            out.close();
            out = null;
            ContentValues v = new ContentValues();
            v.put("is_pending", Integer.valueOf(0));
            getContentResolver().update(outUri, v, null, null);
            outUri = null;
            return "ok";
        } catch (Exception e) {
            abort();
            return "error:" + e.getMessage();
        }
    }

    void abort() {
        if (out != null) {
            try {
                out.close();
            } catch (Exception e) {
                // bereits geschlossen
            }
            out = null;
        }
        if (outUri != null) {
            try {
                getContentResolver().delete(outUri, null, null);
            } catch (Exception e) {
                // Eintrag existiert nicht mehr
            }
            outUri = null;
        }
    }
}
