/* Lofi Kassette – Bedienoberfläche */
'use strict';
(function (LK) {
  var M = LK.M, A = LK.Audio;

  // ---------- Hilfen ----------
  function $(id) { return document.getElementById(id); }
  function h(tag, props, kids) {
    var el = document.createElement(tag);
    if (props) Object.keys(props).forEach(function (k) {
      var v = props[k];
      if (v == null || v === false) return;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'style') el.setAttribute('style', v);
      else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    });
    (kids || []).forEach(function (c) { if (c != null) el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return el;
  }
  var ICON = {
    dice: '<svg viewBox="0 0 24 24"><rect x="3.5" y="3.5" width="17" height="17" rx="4"/><circle class="dot" cx="8.5" cy="8.5" r="1.3"/><circle class="dot" cx="15.5" cy="15.5" r="1.3"/><circle class="dot" cx="12" cy="12" r="1.3"/><circle class="dot" cx="15.5" cy="8.5" r="1.3"/><circle class="dot" cx="8.5" cy="15.5" r="1.3"/></svg>',
    clear: '<svg viewBox="0 0 24 24"><path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12"/></svg>',
    copy: '<svg viewBox="0 0 24 24"><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M5 15V6a1 1 0 0 1 1-1h9"/></svg>',
    wave: '<svg viewBox="0 0 24 24"><path d="M3 12h2l2-6 3 12 3-9 2 6 2-3h4"/></svg>',
    save: '<svg viewBox="0 0 24 24"><path d="M5 4h11l3 3v13H5z"/><path d="M8 4v5h7V4M8 20v-6h8v6"/></svg>',
    open: '<svg viewBox="0 0 24 24"><path d="M4 7a2 2 0 0 1 2-2h4l2 2h6a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/></svg>',
    file: '<svg viewBox="0 0 24 24"><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M12 11v6M9 14l3 3 3-3"/></svg>',
    plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M8 6v12l9-6z"/></svg>',
    reroll: '<svg viewBox="0 0 24 24"><path d="M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3"/><path d="M18 3v4h-4M6 21v-4h4"/></svg>',
    chev: '<svg viewBox="0 0 24 24"><path d="M7 10l5 5 5-5"/></svg>'
  };
  function action(label, icon, fn, cls) {
    var b = h('button', { class: 'action' + (cls ? ' ' + cls : ''), onclick: fn });
    b.innerHTML = (icon ? ICON[icon] : '') + '<span></span>';
    b.lastChild.textContent = label;
    return b;
  }

  var toastTimer = 0;
  function toast(msg) {
    var t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2600);
  }

  // ---------- Android-Brücke ----------
  var Native = {
    has: false,
    call: function (cmd, arg) {
      if (!this.has) return null;
      try { return window.prompt('lofi:' + cmd, arg == null ? '' : String(arg)); } catch (e) { return null; }
    },
    init: function () {
      if (/; wv\)/.test(navigator.userAgent) && location.protocol === 'file:') {
        this.has = true;
        if (this.call('ping', '') !== 'android') this.has = false;
      }
    }
  };

  function bytesToB64(bytes) {
    var s = '', CH = 0x8000;
    for (var i = 0; i < bytes.length; i += CH) s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    return btoa(s);
  }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  // Speichert Bytes (Uint8Array oder Quelle mit length/subarray): in der App über MediaStore, im Browser als Download
  function saveFile(kind, name, mime, bytes, onProgress) {
    onProgress = onProgress || function () {};
    if (!Native.has) {
      var url = URL.createObjectURL(new Blob([bytes.materialize ? bytes.materialize() : bytes], { type: mime }));
      var a = h('a', { href: url, download: name }); document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
      onProgress(1);
      return Promise.resolve('download');
    }
    var r = Native.call('begin', kind + '\n' + name + '\n' + mime);
    if (r !== 'ok') return Promise.reject(new Error(r || 'Speicherort nicht verfügbar'));
    var CH = 3 * 65536, pos = 0;
    function next() {
      if (pos >= bytes.length) {
        var e = Native.call('end', '');
        if (e !== 'ok') return Promise.reject(new Error(e || 'Abschluss fehlgeschlagen'));
        onProgress(1);
        return Promise.resolve('saved');
      }
      var res = Native.call('chunk', bytesToB64(bytes.subarray(pos, pos + CH)));
      if (res !== 'ok') { Native.call('abort', ''); return Promise.reject(new Error(res || 'Schreiben fehlgeschlagen')); }
      pos += CH;
      onProgress(Math.min(1, pos / bytes.length));
      return wait(0).then(next);
    }
    return next();
  }
  function safeName(s) {
    s = String(s || '').replace(/[\\/:*?"<>|\n\r\t]/g, '').replace(/\s+/g, ' ').trim();
    return s || 'Lofi Track';
  }

  // ---------- Zustand ----------
  var S = { P: null, undo: [], pending: null, tab: 'studio', sub: 'beat', open: null, bar: 0, view: 'all', saveTimer: 0 };

  function storeGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function storeSet(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } }

  function loadInitial() {
    var s = storeGet('lk.current');
    if (s) { try { return M.normalize(JSON.parse(s)); } catch (e) { /* kaputt → Vorlage */ } }
    return M.templates()[0];
  }
  function autosave() {
    clearTimeout(S.saveTimer);
    S.saveTimer = setTimeout(function () { storeSet('lk.current', JSON.stringify(S.P)); }, 300);
  }
  function snap() { return JSON.stringify(S.P); }
  function begin() { if (!S.pending) S.pending = snap(); }
  function commit(rerender) {
    if (S.pending && S.pending !== snap()) {
      S.undo.push(S.pending);
      if (S.undo.length > 40) S.undo.shift();
    }
    S.pending = null;
    changed(rerender);
  }
  function changed(rerender) {
    A.update(S.P);
    autosave();
    renderDeck();
    $('btnUndo').disabled = !S.undo.length;
    if (rerender) renderView();
  }
  function edit(fn, rerender) { begin(); fn(S.P); commit(rerender !== false); }
  function replaceProject(P, msg) {
    begin(); S.P = M.normalize(P); S.bar = 0; commit(true);
    if (msg) toast(msg);
  }
  function undo() {
    var s = S.undo.pop();
    if (!s) return;
    S.P = M.normalize(JSON.parse(s));
    S.bar = Math.min(S.bar, S.P.bars - 1);
    changed(true);
    toast('Rückgängig gemacht');
  }

  // ---------- Deck ----------
  function renderDeck() {
    var P = S.P, t = $('cTitle');
    var name = P.name || 'Ohne Titel';
    t.style.fontSize = name.length > 24 ? '16px' : name.length > 18 ? '18px' : '';
    t.textContent = name.length > 30 ? name.slice(0, 29) + '\u2026' : name;
    deckMeta(A.isPlaying() ? A.section() : '');
  }
  function styleName(P) { var st = M.STYLE_BY_ID[P.style]; return st ? st.name : 'Eigener Mix'; }
  function deckMeta(sec) {
    var P = S.P;
    $('cMeta').textContent = styleName(P) + '    ' + M.keyName(P) + '    ' + P.bpm + ' BPM' + (sec ? '    ' + sec : '');
  }
  function setReels(p) {
    var L = 12 + 16 * (1 - p), R = 12 + 16 * p;
    $('packL').setAttribute('r', L.toFixed(1));
    $('packR').setAttribute('r', R.toFixed(1));
  }

  // ---------- Transport ----------
  function togglePlay() {
    if (A.isPlaying()) stopPlay(); else startPlay();
  }
  function startPlay() {
    try {
      A.play(S.P);
    } catch (e) {
      toast('Ton konnte nicht gestartet werden: ' + (e && e.message ? e.message : e));
      return;
    }
    $('btnPlay').classList.add('on'); $('btnPlay').setAttribute('aria-label', 'Stopp');
    $('cassette').classList.add('playing');
    Native.call('screen', '1');
    requestAnimationFrame(frame);
    // Läuft die Audio-Uhr nicht an, Bescheid geben statt stumm zu bleiben
    var st0 = A.status();
    setTimeout(function () {
      var st = A.status();
      if (!A.isPlaying() || !st) return;
      if (st.state !== 'running' || (st0 && st.time - st0.time < 0.3)) {
        A.resume();
        toast('Audio startet nicht (Status: ' + st.state + '). Bitte Medienlautstärke prüfen und Play erneut tippen.');
      }
    }, 1500);
  }
  function stopPlay() {
    A.stop();
    $('btnPlay').classList.remove('on'); $('btnPlay').setAttribute('aria-label', 'Abspielen');
    $('cassette').classList.remove('playing');
    if (!document.hidden) Native.call('screen', '0');
    showNow(null);
    lastSec = null; deckMeta('');
  }

  var lastG = null, lastSec = null;
  function frame() {
    if (!A.isPlaying()) return;
    var g = A.position();
    if (g !== lastG) { lastG = g; showNow(g); }
    var sec = A.section();
    if (sec !== lastSec) { lastSec = sec; deckMeta(sec); }
    requestAnimationFrame(frame);
  }
  var nowEls = [];
  function showNow(g) {
    nowEls.forEach(function (e) { e.classList.remove('now'); });
    nowEls = [];
    if (g == null) return;
    var P = S.P, loop = P.bars * 16, bar = Math.floor(g / 16) % P.bars, s = g % 16;
    setReels((g % loop) / loop);
    var grid = document.querySelector('#view .grid');
    var sub = S.tab === 'edit' ? S.sub : '';
    if (grid && (sub === 'beat' || (sub === 'mel' && bar === S.bar))) {
      grid.querySelectorAll('.cell[data-c="' + s + '"]').forEach(function (e) { e.classList.add('now'); nowEls.push(e); });
    }
    document.querySelectorAll('#view [data-bar="' + bar + '"]').forEach(function (e) { e.classList.add('now'); nowEls.push(e); });
  }

  // ---------- Bausteine ----------
  function chips(list, current, onPick, cls) {
    return h('div', { class: 'row' }, list.map(function (it) {
      return h('button', { class: 'chip' + (cls ? ' ' + cls : '') + (it.id === current ? ' on' : ''), 'data-id': String(it.id), text: it.name, onclick: function () { onPick(it.id); } });
    }));
  }
  function seg(list, current, onPick) {
    return h('div', { class: 'seg' }, list.map(function (it) {
      return h('button', { class: it.id === current ? 'on' : '', 'data-id': String(it.id), 'aria-pressed': it.id === current ? 'true' : 'false', text: it.name, onclick: function () { onPick(it.id); } });
    }));
  }
  function section(title, kids, small) {
    return h('div', { class: 'section' }, [h('h2', null, [title, small ? h('small', { text: small }) : null])].concat(kids));
  }
  function toggle(label, on, fn) {
    return h('button', { class: 'switch' + (on ? ' on' : ''), role: 'switch', 'aria-checked': on ? 'true' : 'false', onclick: fn },
      [h('span', { text: label }), h('span', { class: 'knob' })]);
  }
  function slider(label, get, set, opts) {
    opts = opts || {};
    var min = opts.min || 0, max = opts.max == null ? 100 : opts.max;
    var val = h('span');
    var input = h('input', { type: 'range', min: min, max: max, step: 1, value: get(), 'aria-label': label });
    function show() {
      var v = Number(input.value);
      val.textContent = opts.fmt ? opts.fmt(v) : String(v);
      input.style.setProperty('--p', ((v - min) / (max - min) * 100) + '%');
    }
    input.addEventListener('pointerdown', begin);
    input.addEventListener('focus', begin);
    input.addEventListener('input', function () { begin(); set(Number(input.value)); show(); A.update(S.P); if (opts.deck) renderDeck(); });
    input.addEventListener('change', function () { commit(false); });
    show();
    var kids = [h('div', { class: 'top' }, [h('span', { text: label }), val]), input];
    if (opts.ends) kids.push(h('div', { class: 'ends' }, [h('span', { text: opts.ends[0] }), h('span', { text: opts.ends[1] })]));
    return h('div', { class: 'slider' }, kids);
  }

  function cellsRow(cols, mk, cls) {
    var wrap = h('div', { class: cls || 'cells' }), grp = null;
    for (var c = cols[0]; c < cols[1]; c++) {
      if (c % 4 === 0 || !grp) { grp = h('div', { class: 'grp' }); wrap.appendChild(grp); }
      grp.appendChild(mk(c));
    }
    return wrap;
  }
  var VIEW_OPTS = [{ id: 'all', name: '16 Schritte' }, { id: 'a', name: '1–8' }, { id: 'b', name: '9–16' }];
  function visibleCols() { return S.view === 'a' ? [0, 8] : S.view === 'b' ? [8, 16] : [0, 16]; }
  function stepsHead(cols) {
    var nums = cellsRow(cols, function (c) { return h('span', { class: c % 4 === 0 ? 'beat' : '', text: c % 4 === 0 ? String(c / 4 + 1) : '·' }); }, 'nums');
    return h('div', { class: 'steps-head' }, [h('div', { class: 'sp' }), nums]);
  }

  // Raster mit Tippen und Zeichnen
  function paintGrid(el, onStart, onPaint) {
    var painting = null, last = null;
    function cellAt(x, y) {
      var e = document.elementFromPoint(x, y);
      e = e && e.closest ? e.closest('.cell') : null;
      return e && el.contains(e) ? e : null;
    }
    el.addEventListener('pointerdown', function (e) {
      var cell = e.target.closest && e.target.closest('.cell');
      if (!cell) return;
      e.preventDefault();
      try { el.setPointerCapture(e.pointerId); } catch (err) { /* egal */ }
      begin();
      painting = onStart(+cell.dataset.r, +cell.dataset.c, cell);
      last = cell;
    });
    el.addEventListener('pointermove', function (e) {
      if (!painting) return;
      var cell = cellAt(e.clientX, e.clientY);
      if (cell && cell !== last) { last = cell; onPaint(painting, +cell.dataset.r, +cell.dataset.c, cell); }
    });
    function end() { if (painting) { painting = null; last = null; commit(false); } }
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
  }

  // ---------- Tab: Beat ----------
  function viewBeat() {
    var P = S.P, cols = visibleCols(), v = $('view');
    v.style.setProperty('--accent', 'var(--drums)');
    var grid = h('div', { class: 'grid beat' });
    M.DRUM_ROWS.forEach(function (row, r) {
      var cells = cellsRow(cols, function (c) {
        var val = P.drums.steps[row.id][c];
        return h('div', { class: 'cell' + (val === 1 ? ' on' : val === 2 ? ' ghost' : ''), 'data-r': r, 'data-c': c });
      });
      grid.appendChild(h('div', { class: 'grow' }, [
        h('button', { class: 'rlabel', text: row.name, onclick: function () { A.preview('drum', row.id); } }), cells]));
    });
    function setCell(cell, val) {
      cell.classList.toggle('on', val === 1); cell.classList.toggle('ghost', val === 2);
    }
    paintGrid(grid, function (r, c, cell) {
      var id = M.DRUM_ROWS[r].id, nv = (S.P.drums.steps[id][c] + 1) % 3;
      S.P.drums.steps[id][c] = nv; S.P.drums.pattern = 'eigen'; setCell(cell, nv); A.update(S.P);
      if (nv && !A.isPlaying()) A.preview('drum', id);
      return { v: nv };
    }, function (st, r, c, cell) {
      S.P.drums.steps[M.DRUM_ROWS[r].id][c] = st.v; setCell(cell, st.v); A.update(S.P);
    });

    v.appendChild(section('Schlagzeug', [
      h('p', { class: 'hint', text: 'Tippen setzt einen Schlag, nochmal tippen macht ihn leise, ein drittes Mal löscht ihn. Über das Raster wischen zeichnet mehrere.' }),
      h('div', { class: 'gridbar' }, [seg(VIEW_OPTS, S.view, function (id) { S.view = id; renderView(); })]),
      stepsHead(cols), grid,
      h('div', { class: 'row', style: 'margin-top:12px' }, [
        action('Anderer Beat', 'dice', function () { edit(function (p) { M.reroll(p, 'drums'); }); toast(beatName(S.P)); }),
        action('Leeren', 'clear', function () { edit(function (p) { M.DRUM_ROWS.forEach(function (r) { p.drums.steps[r.id] = M.emptyRow(); }); }); })
      ])
    ]));
    v.appendChild(section('Muster', [
      h('div', { class: 'row' }, M.DRUM_PRESETS.map(function (pr) {
        return h('button', { class: 'chip' + (pr.id === P.drums.pattern ? ' on' : ''), text: pr.name, onclick: function () { edit(function (p) { p.drums.steps = M.copy(pr.steps); p.drums.pattern = pr.id; p.mute.drums = false; }); toast(pr.name); } });
      }))
    ]));
    v.appendChild(section('Kit', [chips(M.KITS, P.drums.kit, function (id) { edit(function (p) { p.drums.kit = id; }); A.preview('drum', 'snare'); })]));
    v.appendChild(section('Feel', [
      slider('Groove', function () { return S.P.drums.groove; }, function (x) { S.P.drums.groove = x; }, { ends: ['exakt', 'menschlich'] }),
      toggle('Kleiner Fill im letzten Takt', P.drums.fill, function () { edit(function (p) { p.drums.fill = !p.drums.fill; }); }),
      toggle('Schlagzeug spielt', !P.mute.drums, function () { edit(function (p) { p.mute.drums = !p.mute.drums; }); })
    ]));
  }

  // ---------- Feinschliff: Akkorde ----------
  function viewHarm() {
    var P = S.P, v = $('view');
    v.style.setProperty('--accent', 'var(--harm)');
    var grid = h('div', { class: 'chords' });
    for (var b = 0; b < P.bars; b++) {
      (function (b) {
        var ch = P.chords.list[b];
        grid.appendChild(h('button', { class: 'chordcard' + (ch.h2 ? ' split' : ''), 'data-bar': b, onclick: function () { chordSheet(b, 0); } }, [
          h('span', { class: 'n' }, [h('span', { text: 'Takt ' + (b + 1) }), h('span', { text: M.romanOf(P, ch) + (ch.h2 ? ' ' + M.romanOf(P, ch.h2) : '') })]),
          h('span', { class: 'name', text: M.barName(P, ch) })
        ]));
      })(b);
    }
    var progs = M.PROGRESSIONS[P.mode] || [];
    v.appendChild(section('Akkorde', [
      h('p', { class: 'hint', text: 'Ein Akkord pro Takt, auf Wunsch zwei. Antippen, um ihn zu ändern.' }),
      grid,
      h('div', { class: 'row', style: 'margin-top:12px' }, [
        action('Andere Folge', 'dice', function () { edit(function (p) { M.reroll(p, 'chords'); }); toast(S.P.chords.prog || 'Neue Folge'); })
      ])
    ], M.keyName(P)));
    v.appendChild(section('Fertige Folgen', [h('div', { class: 'row' }, progs.map(function (pr) {
      return h('button', { class: 'chip' + (pr.name === P.chords.prog ? ' on' : ''), text: pr.name, onclick: function () {
        edit(function (p) { for (var i = 0; i < 8; i++) p.chords.list[i] = M.copy(pr.chords[i % pr.chords.length]); p.chords.prog = pr.name; });
        if (!A.isPlaying()) A.preview('chord', 0);
        toast(pr.name);
      } });
    }))]));
    v.appendChild(section('Instrument', [
      chips(M.CHORD_INST, P.chords.inst, function (id) { edit(function (p) { p.chords.inst = id; }); A.preview('chord', 0); }),
      h('div', { class: 'label', text: 'Rhythmus' }),
      chips(M.CHORD_STYLES, P.chords.style, function (id) { edit(function (p) { p.chords.style = id; }); }),
      h('div', { class: 'label', text: 'Lage' }),
      seg(M.VOICINGS, P.chords.voicing, function (id) { edit(function (p) { p.chords.voicing = id; }); A.preview('chord', 0); }),
      toggle('Akkorde spielen', !P.mute.chords, function () { edit(function (p) { p.mute.chords = !p.mute.chords; }); })
    ]));
    var bass = section('Bass', [toggle('Bass spielt mit', !P.mute.bass, function () { edit(function (p) { p.mute.bass = !p.mute.bass; }); })]);
    bass.style.setProperty('--accent', 'var(--bass)');
    if (!P.mute.bass) {
      bass.appendChild(chips(M.BASS_INST, P.bass.inst, function (id) { edit(function (p) { p.bass.inst = id; }); A.preview('bass', M.derive(S.P).bars[0].bassRoot + 12); }));
      bass.appendChild(h('div', { class: 'label', text: 'Spielweise' }));
      bass.appendChild(chips(M.BASS_STYLES, P.bass.style, function (id) { edit(function (p) { p.bass.style = id; }); }));
    }
    v.appendChild(bass);
  }

  function chordSheet(bar, half) {
    function target(p) { var c = p.chords.list[bar]; return half === 1 && c.h2 ? c.h2 : c; }
    function hear() { A.previewChord(bar, half); }
    function body() {
      var P = S.P, bc = P.chords.list[bar], ch = target(P), wrap = h('div');
      wrap.style.setProperty('--accent', 'var(--harm)');
      wrap.appendChild(h('div', { class: 'label', text: 'Aufteilung' }));
      wrap.appendChild(seg([{ id: 'ganz', name: 'Ein Akkord' }, { id: 'h1', name: '1. Hälfte' }, { id: 'h2', name: '2. Hälfte' }],
        !bc.h2 ? 'ganz' : half === 1 ? 'h2' : 'h1', function (id) {
          if (id === 'ganz') { edit(function (p) { delete p.chords.list[bar].h2; }, false); half = 0; }
          else {
            if (!S.P.chords.list[bar].h2) edit(function (p) { // Vorschlag: Dominante zum nächsten Akkord
              var nx = p.chords.list[(bar + 1) % p.bars];
              p.chords.list[bar].h2 = { d: (nx.d + 4) % 7, q: '7' };
            }, false);
            half = id === 'h2' ? 1 : 0;
          }
          refresh(); hear();
        }));
      var degs = h('div', { class: 'pickgrid' });
      for (var d = 0; d < 7; d++) {
        (function (d) {
          var tmp = { d: d, q: d === ch.d ? ch.q : M.DEFAULT_Q[P.mode][d], a: d === ch.d ? ch.a : 0 };
          degs.appendChild(h('button', { class: 'pick' + (d === ch.d ? ' on' : ''), onclick: function () {
            edit(function (p) { var c = target(p); c.d = d; c.q = M.DEFAULT_Q[p.mode][d]; delete c.a; }, false);
            refresh(); hear();
          } }, [h('span', { class: 'r', text: M.romanOf(P, tmp) }), h('span', { class: 'c', text: M.chordName(P, tmp) })]));
        })(d);
      }
      var quals = h('div', { class: 'pickgrid' });
      M.QUALITY_ORDER.forEach(function (q) {
        quals.appendChild(h('button', { class: 'pick' + (q === ch.q ? ' on' : ''), onclick: function () {
          edit(function (p) { target(p).q = q; }, false);
          refresh(); hear();
        } }, [h('span', { class: 'c', text: M.chordName(P, { d: ch.d, q: q, a: ch.a }) })]));
      });
      wrap.appendChild(h('div', { class: 'label', text: 'Stufe in ' + M.keyName(P) }));
      wrap.appendChild(degs);
      wrap.appendChild(toggle('Einen Halbton tiefer (\u266d)', ch.a === -1, function () {
        edit(function (p) { var c = target(p); if (c.a) delete c.a; else c.a = -1; }, false);
        refresh(); hear();
      }));
      wrap.appendChild(h('div', { class: 'label', text: 'Farbe' }));
      wrap.appendChild(quals);
      wrap.appendChild(h('div', { class: 'row', style: 'margin-top:16px' }, [
        action('Anhören', 'play', hear),
        bar < S.P.bars - 1 ? action('Nächster Takt', null, function () { closeSheet(true); chordSheet(bar + 1, 0); }) : null
      ]));
      return wrap;
    }
    function refresh() { $('sheetBody').innerHTML = ''; $('sheetBody').appendChild(body()); }
    openSheet('Takt ' + (bar + 1), body(), function () { renderView(); });
  }

  // ---------- Tab: Melodie ----------
  function viewMel() {
    var P = S.P, v = $('view'), cols = visibleCols();
    v.style.setProperty('--accent', 'var(--mel)');
    if (S.bar >= P.bars) S.bar = 0;
    var D = M.derive(P), rows = D.rows, flats = M.useFlats(P);
    var tones = D.bars[S.bar].tones;

    var bars = h('div', { class: 'bars' });
    for (var b = 0; b < P.bars; b++) {
      (function (b) {
        bars.appendChild(h('button', { class: 'barbtn' + (b === S.bar ? ' on' : ''), 'data-bar': b, onclick: function () { S.bar = b; renderView(); } },
          [h('b', { text: 'Takt ' + (b + 1) }), h('i', { text: M.chordName(P, P.chords.list[b]) })]));
      })(b);
    }

    var grid = h('div', { class: 'grid mel' });
    for (var r = M.MELODY_ROWS - 1; r >= 0; r--) {
      var isTone = tones.indexOf(rows[r] % 12) >= 0;
      var cells = cellsRow(cols, function (c) {
        return h('div', { class: 'cell' + (P.melody.notes[S.bar][c] === r ? ' on' : ''), 'data-r': r, 'data-c': c });
      });
      (function (r) {
        grid.appendChild(h('div', { class: 'grow' + (isTone ? ' row-tone' : '') }, [
          h('button', { class: 'rlabel' + (isTone ? ' tone' : ''), text: M.noteName(rows[r], flats), onclick: function () { A.preview('melody', rows[r]); } }),
          cells]));
      })(r);
    }
    function redrawCol(c) {
      grid.querySelectorAll('.cell[data-c="' + c + '"]').forEach(function (e) { e.classList.toggle('on', +e.dataset.r === S.P.melody.notes[S.bar][c]); });
    }
    paintGrid(grid, function (r, c) {
      var notes = S.P.melody.notes[S.bar], erase = notes[c] === r;
      notes[c] = erase ? -1 : r; redrawCol(c); A.update(S.P);
      if (!erase && !A.isPlaying()) A.preview('melody', rows[r]);
      return { erase: erase };
    }, function (st, r, c) {
      var notes = S.P.melody.notes[S.bar];
      if (st.erase) { if (notes[c] === r) notes[c] = -1; } else notes[c] = r;
      redrawCol(c); A.update(S.P);
    });

    v.appendChild(section('Melodie', [
      h('p', { class: 'hint', text: 'Pro Schritt eine Note. Zeilen mit Punkt passen zum Akkord des Takts.' }),
      bars,
      h('div', { class: 'gridbar' }, [seg(VIEW_OPTS, S.view, function (id) { S.view = id; renderView(); })]),
      stepsHead(cols), grid,
      h('div', { class: 'row', style: 'margin-top:12px' }, [
        action('Würfeln', 'dice', function () { edit(function (p) { p.melody.notes = M.randomMelody(p); }); toast('Neue Melodie'); }),
        action('Takt ' + (S.bar + 1) + ' → ' + ((S.bar + 1) % P.bars + 1), 'copy', function () {
          var to = (S.bar + 1) % S.P.bars;
          edit(function (p) { p.melody.notes[to] = p.melody.notes[S.bar].slice(); });
          toast('In Takt ' + (to + 1) + ' kopiert');
        }),
        action('Takt leeren', 'clear', function () { edit(function (p) { p.melody.notes[S.bar] = M.emptyMelody()[0]; }); })
      ])
    ]));
    v.appendChild(section('Instrument', [
      chips(M.MELODY_INST, P.melody.inst, function (id) {
        edit(function (p) { p.melody.inst = id; });
        A.preview('melody', M.derive(S.P).rows[4]);
      }),
      h('div', { class: 'label', text: 'Lage' }),
      seg([{ id: -1, name: 'Tief' }, { id: 0, name: 'Mitte' }, { id: 1, name: 'Hoch' }], P.melody.octave, function (id) { edit(function (p) { p.melody.octave = id; }); }),
      h('div', { class: 'label', text: 'Notenlänge' }),
      seg([{ id: 1, name: 'Kurz' }, { id: 2, name: 'Mittel' }, { id: 4, name: 'Lang' }], P.melody.length, function (id) { edit(function (p) { p.melody.length = id; }); }),
      h('div', { class: 'label', text: 'Töne' }),
      seg([{ id: 'penta', name: 'Pentatonik' }, { id: 'full', name: 'Ganze Tonleiter' }], P.melody.scale, function (id) { edit(function (p) { p.melody.scale = id; }); }),
      toggle('Melodie spielt', !P.mute.melody, function () { edit(function (p) { p.mute.melody = !p.mute.melody; }); })
    ]));
  }

  // ---------- Feinschliff: Klang ----------
  function viewSound() {
    var P = S.P, v = $('view');
    v.style.setProperty('--accent', 'var(--lamp)');
    var flatsOf = function (k) { return M.useFlats({ key: k, mode: P.mode }); };
    var keys = h('div', { class: 'row' });
    for (var k = 0; k < 12; k++) {
      (function (k) {
        keys.appendChild(h('button', { class: 'chip small' + (k === P.key ? ' on' : ''), text: M.noteName(k, flatsOf(k)), onclick: function () { edit(function (p) { p.key = k; }); A.preview('chord', 0); } }));
      })(k);
    }
    v.appendChild(section('Tempo und Tonart', [
      slider('Tempo', function () { return S.P.bpm; }, function (x) { S.P.bpm = x; }, { min: 55, max: 120, fmt: function (x) { return x + ' BPM'; }, deck: true }),
      slider('Swing', function () { return S.P.swing; }, function (x) { S.P.swing = x; }, { max: 60, fmt: function (x) { return x + ' %'; } }),
      h('div', { class: 'label', text: 'Swing auf' }),
      seg([{ id: '16', name: 'Sechzehnteln' }, { id: '8', name: 'Achteln' }], P.feel, function (id) { edit(function (p) { p.feel = id; }); }),
      h('div', { class: 'label', text: 'Grundton' }), keys,
      h('div', { class: 'row', style: 'margin-top:10px' }, [
        seg(M.MODES, P.mode, function (id) { if (id !== S.P.mode) { edit(function (p) { M.setMode(p, id); }); A.preview('chord', 0); } }),
        seg([{ id: 4, name: '4 Takte' }, { id: 8, name: '8 Takte' }], P.bars, function (id) {
          if (id === S.P.bars) return;
          edit(function (p) {
            if (id === 8) for (var i = 0; i < 4; i++) { p.chords.list[i + 4] = M.copy(p.chords.list[i]); p.melody.notes[i + 4] = p.melody.notes[i].slice(); }
            p.bars = id;
          });
        })
      ])
    ]));
    function fx(label, key, ends, fmt) {
      return slider(label, function () { return S.P.fx[key]; }, function (x) { S.P.fx[key] = x; }, { ends: ends, fmt: fmt });
    }
    v.appendChild(section('Umgebung', [
      chips(M.ATMOS, P.atmo.type, function (id) { edit(function (p) { p.atmo.type = id; p.mute.atmo = false; }); try { A.warmFor(S.P); } catch (e) { /* später */ } }),
      slider('Lautstärke der Umgebung', function () { return S.P.atmo.amount; }, function (x) { S.P.atmo.amount = x; }),
      fx('Vinyl-Knistern', 'vinyl')
    ]));
    v.appendChild(section('Lofi-Färbung', [
      fx('Filter', 'filter', ['dumpf', 'klar']),
      fx('Band leiert', 'wobble', ['stabil', 'wackelig']),
      fx('Sättigung', 'drive'),
      fx('Bitcrusher', 'crush', ['aus', 'grob'], function (x) { return x === 0 ? 'aus' : Math.round(12 - x / 100 * 8) + ' Bit'; }),
      fx('Hall', 'reverb'),
      fx('Echo', 'echo'),
      fx('Pumpen', 'pump', ['aus', 'deutlich'])
    ]));
    function mix(label, key) {
      return slider(label, function () { return S.P.mix[key]; }, function (x) { S.P.mix[key] = x; });
    }
    v.appendChild(section('Mischpult', [
      mix('Schlagzeug', 'drums'), mix('Akkorde', 'chords'), mix('Melodie', 'melody'), mix('Bass', 'bass'),
      mix('Umgebung und Vinyl', 'atmos'), mix('Gesamt', 'master')
    ]));
  }

  // ---------- Tab: Projekt ----------
  function library() { try { return JSON.parse(storeGet('lk.library') || '[]'); } catch (e) { return []; } }
  function setLibrary(l) { return storeSet('lk.library', JSON.stringify(l)); }
  function fmtDate(ts) {
    var d = new Date(ts);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return z(d.getDate()) + '.' + z(d.getMonth() + 1) + '.' + d.getFullYear() + ', ' + z(d.getHours()) + ':' + z(d.getMinutes());
  }
  function fmtDur(sec) { var m = Math.floor(sec / 60), s = Math.round(sec % 60); if (s === 60) { m++; s = 0; } return m + ':' + (s < 10 ? '0' : '') + s; }

  function saveToLibrary() {
    var lib = library(), i = -1;
    lib.forEach(function (it, k) { if (it.name === S.P.name) i = k; });
    var item = { id: i >= 0 ? lib[i].id : Date.now(), name: S.P.name, date: Date.now(), data: M.copy(S.P) };
    if (i >= 0) lib.splice(i, 1);
    lib.unshift(item);
    if (setLibrary(lib)) { toast('„' + S.P.name + '“ gespeichert'); renderView(); } else toast('Speicher voll – bitte alte Tracks löschen');
  }

  function viewProj() {
    var P = S.P, v = $('view');
    v.style.setProperty('--accent', 'var(--lamp)');
    var name = h('input', { class: 'field', type: 'text', maxlength: 60, value: P.name, 'aria-label': 'Name des Tracks', enterkeyhint: 'done' });
    name.addEventListener('change', function () { edit(function (p) { p.name = name.value.trim().slice(0, 60) || 'Ohne Titel'; }, false); });
    name.addEventListener('keydown', function (e) { if (e.key === 'Enter') name.blur(); });

    v.appendChild(section('Dein Track', [
      name,
      h('div', { class: 'row', style: 'margin-top:12px' }, [
        action('Als Musik speichern', 'wave', exportSheet, 'primary'),
        action('Track merken', 'save', saveToLibrary)
      ])
    ]));

    var lib = library();
    var list = h('div', { class: 'lib' });
    if (!lib.length) list.appendChild(h('div', { class: 'empty', text: 'Noch nichts gemerkt. „Track merken“ legt den aktuellen Track hier ab.' }));
    lib.forEach(function (it) {
      var del = h('button', { class: 'chip small', text: 'Löschen' });
      var armed = 0;
      del.addEventListener('click', function () {
        if (!armed) { del.textContent = 'Sicher?'; del.classList.add('on'); armed = setTimeout(function () { armed = 0; del.textContent = 'Löschen'; del.classList.remove('on'); }, 3000); return; }
        clearTimeout(armed);
        setLibrary(library().filter(function (x) { return x.id !== it.id; }));
        toast('Gelöscht'); renderView();
      });
      list.appendChild(h('div', { class: 'libitem' }, [
        h('div', { class: 't' }, [h('b', { text: it.name }), h('span', { text: fmtDate(it.date) })]),
        h('button', { class: 'chip small', text: 'Laden', onclick: function () { replaceProject(it.data, '„' + it.name + '“ geladen'); } }),
        del
      ]));
    });
    v.appendChild(section('Gespeicherte Tracks', [list]));

    v.appendChild(section('Dateien', [
      h('p', { class: 'hint', text: Native.has ? 'Projektdateien landen in Download/LofiKassette, WAV-Dateien in Musik/LofiKassette.' : 'Projektdateien und WAV-Dateien werden heruntergeladen.' }),
      h('div', { class: 'row' }, [
        action('Projektdatei exportieren', 'file', function () {
          var bytes = new TextEncoder().encode(JSON.stringify(S.P, null, 1));
          saveFile('download', safeName(S.P.name) + '.lofi.json', 'application/json', bytes).then(function (r) {
            toast(r === 'saved' ? 'Gespeichert in Download/LofiKassette' : 'Projektdatei heruntergeladen');
          }, function (e) { toast('Nicht gespeichert: ' + e.message); });
        }),
        action('Projektdatei öffnen', 'open', function () { $('fileIn').value = ''; $('fileIn').click(); }),
        action('Leerer Track', 'plus', function () {
          var p = M.blankProject();
          p.style = 'eigen';
          M.DRUM_ROWS.forEach(function (r) { p.drums.steps[r.id] = M.emptyRow(); });
          replaceProject(p, 'Leerer Track – leg los');
        })
      ])
    ]));

    v.appendChild(section('Vorlagen', [
      h('div', { class: 'row' }, M.templates().map(function (t) {
        return h('button', { class: 'chip', text: t.name, onclick: function () { replaceProject(t, '„' + t.name + '“ geladen'); } });
      }))
    ]));

    v.appendChild(section('So geht’s', [h('div', { class: 'help', html:
      '<p><b>Studio</b>: Stimmung antippen, schon läuft ein fertiger Track. Mit <b>Anders</b> tauschst du einzelne Spuren aus, der Schalter daneben blendet sie aus.</p>' +
      '<p><b>Tempo, Lofi und Raum</b> formen den Klang: Lofi macht ihn staubiger und wackeliger, Raum gibt Hall und Echo dazu.</p>' +
      '<p><b>Ganzer Song</b> spielt Intro, Teil A, eine Pause und Teil B wie ein echtes Stück. <b>Schleife</b> wiederholt einfach alles.</p>' +
      '<p><b>Feinschliff</b> ist für Tüftler: Beat und Melodie Note für Note, Akkorde, Tonart und alle Effekte.</p>' +
      '<p><b>Rückgängig</b> oben links nimmt bis zu 40 Schritte zurück. Alles bleibt automatisch auf dem Gerät gespeichert, ohne Internet und ohne Konto.</p>' })]));
  }

  function exportSheet() {
    var st = { min: 2, song: S.P.song !== 'loop', busy: false };
    var body = h('div');
    body.style.setProperty('--accent', 'var(--lamp)');
    var dur = h('div', { class: 'bigdur' }), bar = h('i'), status = h('div', { class: 'status' });
    var go = action('Musik erstellen', 'wave', run, 'primary wide');
    function loops() { return A.loopsForMinutes(S.P, st.min, st.song); }
    function upd() { dur.textContent = fmtDur(A.exportDuration(S.P, loops(), st.song)); }
    var mins = h('div', { class: 'row' }, [1, 2, 3, 5].map(function (n) {
      return h('button', { class: 'chip' + (n === st.min ? ' on' : ''), 'data-id': String(n), text: 'ca. ' + n + ' Min', onclick: function (e) {
        if (st.busy) return;
        st.min = n; mins.querySelectorAll('.chip').forEach(function (c) { c.classList.remove('on'); }); e.currentTarget.classList.add('on'); upd();
      } });
    }));
    var sw = toggle('Mit Intro, Pause und Outro', st.song, function () {
      if (st.busy) return;
      st.song = !st.song; sw.classList.toggle('on', st.song); sw.setAttribute('aria-checked', st.song ? 'true' : 'false'); upd();
    });
    function run() {
      if (st.busy) return;
      st.busy = true; go.disabled = true;
      stopPlay();
      status.textContent = 'Wird gemischt …'; bar.style.width = '0%';
      var t0 = Date.now();
      A.render(S.P, { loops: loops(), songForm: st.song, onProgress: function (p) { bar.style.width = (p * 80).toFixed(1) + '%'; } })
        .then(function (buf) {
          status.textContent = 'Wird gespeichert …';
          return wait(30).then(function () {
            var wav = A.wavSource(buf); // kodiert stückweise beim Speichern
            return saveFile('audio', safeName(S.P.name) + '.wav', 'audio/x-wav', wav, function (p) { bar.style.width = (80 + p * 20).toFixed(1) + '%'; });
          });
        })
        .then(function (r) {
          bar.style.width = '100%';
          status.textContent = r === 'saved' ? 'Fertig. Du findest den Track in deiner Musik-App unter Musik/LofiKassette.' : 'Fertig. Die WAV-Datei wurde heruntergeladen.';
          window.__lastExportMs = Date.now() - t0;
        }, function (e) {
          status.textContent = 'Export fehlgeschlagen: ' + (e && e.message ? e.message : e) + '. Bitte erneut versuchen.';
        })
        .then(function () { st.busy = false; go.disabled = false; });
    }
    upd();
    body.appendChild(h('div', { class: 'label', text: 'Wie lang soll der Track werden?' }));
    body.appendChild(mins);
    body.appendChild(h('div', { style: 'margin-top:8px' }, [sw]));
    body.appendChild(h('p', { class: 'hint', style: 'margin-top:6px', text: 'Mit Intro und Outro klingt es wie ein fertiges Stück: sanfter Anfang, Pause in der Mitte, Ausblenden am Ende.' }));
    body.appendChild(h('div', { class: 'label', text: 'Länge' }));
    body.appendChild(dur);
    body.appendChild(h('div', { class: 'progress' }, [bar]));
    body.appendChild(status);
    body.appendChild(h('div', { style: 'margin-top:12px' }, [go]));
    openSheet('Als Musik speichern', body, null, function () { return st.busy; });
  }

  // ---------- Sheet ----------
  var sheetClose = null, sheetBusy = null;
  function openSheet(title, content, onClose, busy) {
    $('sheetTitle').textContent = title;
    var b = $('sheetBody'); b.innerHTML = ''; b.appendChild(content);
    $('sheet').hidden = false; $('scrim').hidden = false;
    sheetClose = onClose || null; sheetBusy = busy || null;
  }
  function closeSheet(silent) {
    if ($('sheet').hidden) return false;
    if (!silent && sheetBusy && sheetBusy()) { toast('Export läuft noch …'); return true; }
    $('sheet').hidden = true; $('scrim').hidden = true;
    var fn = sheetClose; sheetClose = null; sheetBusy = null;
    if (fn && !silent) fn();
    return true;
  }

  // ---------- Ansicht ----------
  // ---------- Studio (Startseite für alle) ----------
  function beatName(P) {
    var pat = P.drums.pattern || '', pr = M.byId(M.DRUM_PRESETS, pat), name = pr ? pr.name : 'Eigener Beat';
    if (pat.indexOf('song:') === 0) {
      var sg = LK.SONG_BY_ID[pat.slice(5)];
      name = !sg || sg.id === P.song_id ? 'Eigener Groove' : 'Groove aus ' + sg.name;
    }
    return name + ', ' + M.byId(M.KITS, P.drums.kit).name;
  }
  var LAYERS = [
    { id: 'drums', name: 'Beat', c: 'var(--drums)', label: 'Schlagzeug-Klang', list: function () { return M.KITS; },
      cur: function (P) { return P.drums.kit; }, set: function (p, id) { p.drums.kit = id; }, desc: beatName,
      vol: 'drums', hear: function () { A.preview('drum', 'snare'); } },
    { id: 'chords', name: 'Akkorde', c: 'var(--harm)', label: 'Instrument', list: function () { return M.CHORD_INST; },
      cur: function (P) { return P.chords.inst; }, set: function (p, id) { p.chords.inst = id; },
      desc: function (P) { return M.byId(M.CHORD_INST, P.chords.inst).name + ', ' + (P.chords.prog || 'eigene Folge'); },
      vol: 'chords', hear: function () { A.preview('chord', 0); } },
    { id: 'bass', name: 'Bass', c: 'var(--bass)', label: 'Instrument', list: function () { return M.BASS_INST; },
      cur: function (P) { return P.bass.inst; }, set: function (p, id) { p.bass.inst = id; },
      desc: function (P) { return M.byId(M.BASS_INST, P.bass.inst).name + ', ' + M.byId(M.BASS_STYLES, P.bass.style).name.toLowerCase(); },
      vol: 'bass', hear: function () { A.preview('bass', M.derive(S.P).bars[0].bassRoot + 12); } },
    { id: 'melody', name: 'Melodie', c: 'var(--mel)', label: 'Instrument', list: function () { return M.MELODY_INST; },
      cur: function (P) { return P.melody.inst; }, set: function (p, id) { p.melody.inst = id; },
      desc: function (P) { return M.byId(M.MELODY_INST, P.melody.inst).name; },
      vol: 'melody', hear: function () { A.preview('melody', M.derive(S.P).rows[5]); } },
    { id: 'atmo', name: 'Umgebung', c: 'var(--atmo)', label: 'Geräusch', list: function () { return M.ATMOS.filter(function (a) { return a.id !== 'keine'; }); },
      cur: function (P) { return P.atmo.type; }, set: function (p, id) { p.atmo.type = id; },
      desc: function (P) { return M.byId(M.ATMOS, P.atmo.type).name; }, vol: 'atmo' }
  ];

  // Stimmung antippen: eine andere Grundmusik dieser Stimmung laden
  function newFromStyle(id) {
    var sid = M.nextSong(id, S.P.song_id);
    if (sid) { loadSong(sid); return; }
    replaceProject(M.fromStyle(id), null);
    toast(styleName(S.P) + ': „' + S.P.name + '“');
    try { A.warmFor(S.P); } catch (e) { /* wird beim Abspielen berechnet */ }
    if (!A.isPlaying()) startPlay();
  }
  function loadSong(id) {
    replaceProject(M.fromSong(id), null);
    toast(styleName(S.P) + ': „' + S.P.name + '“');
    try { A.warmFor(S.P); } catch (e) { /* wird beim Abspielen berechnet */ }
    if (!A.isPlaying()) startPlay();
  }

  function layerRow(L) {
    var P = S.P, muted = P.mute[L.id] || (L.id === 'atmo' && P.atmo.type === 'keine'), open = S.open === L.id;
    var row = h('div', { class: 'layer' + (muted ? ' muted' : '') + (open ? ' open' : ''), style: '--c:' + L.c, 'data-layer': L.id });
    var main = h('button', { class: 'lmain', 'aria-expanded': open ? 'true' : 'false', onclick: function () { S.open = open ? null : L.id; renderView(); } }, [
      h('span', { class: 'ldot' }),
      h('span', { class: 'ltxt' }, [h('b', { text: L.name }), h('span', { text: muted ? 'aus' : L.desc(P) })]),
      h('span', { class: 'chev', html: ICON.chev })
    ]);
    var again = h('button', { class: 'lagain', 'aria-label': L.name + ': andere Variante', onclick: function () {
      edit(function (p) { M.reroll(p, L.id); p.mute[L.id] = false; });
      if (L.id === 'atmo' || L.id === 'drums') { try { A.warmFor(S.P); } catch (e) { /* später */ } }
      toast(L.name + ': ' + L.desc(S.P));
      if (!A.isPlaying()) startPlay();
    } });
    again.innerHTML = ICON.reroll + '<span>Anders</span>';
    var sw = h('button', { class: 'lsw' + (muted ? '' : ' on'), role: 'switch', 'aria-checked': muted ? 'false' : 'true', 'aria-label': L.name + ' ein oder aus', onclick: function () {
      edit(function (p) { p.mute[L.id] = !muted ? true : false; if (L.id === 'atmo' && p.atmo.type === 'keine') { p.atmo.type = 'regen'; p.mute.atmo = false; } });
    } }, [h('span', { class: 'knob' })]);
    row.appendChild(h('div', { class: 'lrow' }, [main, again, sw]));
    if (open) {
      var vol = L.vol === 'atmo'
        ? slider('Lautstärke', function () { return S.P.atmo.amount; }, function (x) { S.P.atmo.amount = x; })
        : slider('Lautstärke', function () { return S.P.mix[L.vol]; }, function (x) { S.P.mix[L.vol] = x; });
      row.appendChild(h('div', { class: 'lmore' }, [
        h('div', { class: 'label', text: L.label }),
        chips(L.list(), L.cur(P), function (id) {
          edit(function (p) { L.set(p, id); p.mute[L.id] = false; });
          if (L.id === 'atmo' || L.id === 'drums') { try { A.warmFor(S.P); } catch (e) { /* später */ } }
          if (L.hear && !A.isPlaying()) L.hear();
        }),
        vol
      ]));
    }
    return row;
  }

  function viewStudio() {
    var P = S.P, v = $('view');
    v.style.setProperty('--accent', 'var(--lamp)');
    if (!storeGet('lk.intro2')) {
      v.appendChild(h('div', { class: 'intro' }, [
        h('b', { text: 'So einfach geht’s' }),
        h('ol', null, [
          h('li', { text: 'Stimmung antippen: dein Track entsteht und spielt sofort.' }),
          h('li', { text: 'Mit „Anders“ tauschst du einzelne Spuren aus, bis es passt.' }),
          h('li', { text: 'Tempo, Lofi und Raum einstellen, dann als Musik speichern.' })
        ]),
        h('button', { class: 'text-btn', text: 'Verstanden', onclick: function () { storeSet('lk.intro2', '1'); renderView(); } })
      ]));
    }
    v.appendChild(section('Stimmung', [
      h('div', { class: 'styles' }, M.STYLES.map(function (st) {
        return h('button', { class: 'style' + (st.id === P.style ? ' on' : ''), style: '--c:' + st.color, 'data-style': st.id,
          'aria-pressed': st.id === P.style ? 'true' : 'false', onclick: function () { newFromStyle(st.id); } },
          [h('b', { text: st.name }), h('span', { text: st.desc })]);
      })),
      M.songsOf(P.style).length ? h('div', { class: 'label', text: 'Grundmusiken in „' + styleName(P) + '“' }) : null,
      h('div', { class: 'row songs' }, M.songsOf(P.style).map(function (sg) {
        return h('button', { class: 'chip' + (sg.id === P.song_id ? ' on' : ''), 'data-song': sg.id, text: sg.name,
          style: '--accent:' + (M.STYLE_BY_ID[sg.style] || {}).color, onclick: function () { loadSong(sg.id); } });
      }))
    ], 'antippen = neuer Track'));
    v.appendChild(section('Deine Spuren', LAYERS.map(layerRow), '„Anders“ tauscht aus'));
    function macro(label, key, ends) {
      return slider(label, function () { return S.P.macro[key]; }, function (x) { S.P.macro[key] = x; M.applyMacros(S.P); },
        { ends: ends, fmt: function (x) { return x < 34 ? ends[0] : x > 66 ? ends[1] : 'mittel'; } });
    }
    v.appendChild(section('Klang', [
      slider('Tempo', function () { return S.P.bpm; }, function (x) { S.P.bpm = x; }, { min: 55, max: 120, fmt: function (x) { return x + ' BPM'; }, ends: ['gemütlich', 'flott'], deck: true }),
      macro('Lofi', 'dust', ['sauber', 'staubig']),
      macro('Raum', 'space', ['nah', 'weit']),
      h('div', { class: 'label', text: 'Farbe' }),
      seg(M.MODES.map(function (m) { return { id: m.id, name: m.easy }; }), P.mode, function (id) {
        if (id === S.P.mode) return;
        edit(function (p) { M.setMode(p, id); });
        if (!A.isPlaying()) A.preview('chord', 0);
      })
    ]));
    v.appendChild(section('Ablauf', [
      seg([{ id: 'song', name: 'Ganzer Song' }, { id: 'loop', name: 'Schleife' }], P.song, function (id) { edit(function (p) { p.song = id; }); }),
      h('p', { class: 'hint', style: 'margin-top:8px', text: P.song === 'song' ? 'Intro, Teil A, Pause, Teil B – wie ein echtes Stück.' : 'Alles läuft ohne Pause immer weiter.' })
    ]));
    v.appendChild(h('div', { class: 'cta' }, [
      action('Als Musik speichern', 'wave', exportSheet, 'primary'),
      action('Track merken', 'save', saveToLibrary)
    ]));
    v.appendChild(h('p', { class: 'hint center', text: 'Noch genauer? Im Feinschliff setzt du jede Note selbst.' }));
  }

  // ---------- Feinschliff (für Tüftler) ----------
  var SUBS = [{ id: 'beat', name: 'Beat' }, { id: 'harm', name: 'Akkorde' }, { id: 'mel', name: 'Melodie' }, { id: 'sound', name: 'Klang' }];
  var SUBVIEWS = { beat: viewBeat, harm: viewHarm, mel: viewMel, sound: viewSound };
  function viewEdit() {
    var v = $('view');
    v.appendChild(h('div', { class: 'subnav' }, [seg(SUBS, S.sub, function (id) { S.sub = id; storeSet('lk.sub', id); $('view').scrollTop = 0; renderView(); })]));
    SUBVIEWS[S.sub]();
  }

  var VIEWS = { studio: viewStudio, edit: viewEdit, proj: viewProj };
  function renderView() {
    var v = $('view'), top = v.scrollTop;
    v.innerHTML = '';
    nowEls = [];
    VIEWS[S.tab]();
    v.scrollTop = top;
    document.querySelectorAll('#tabs button').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === S.tab); });
    if (A.isPlaying() && lastG != null) showNow(lastG);
  }
  function setTab(t) {
    if (SUBVIEWS[t]) { S.sub = t; t = 'edit'; if (S.tab === 'edit') { $('view').scrollTop = 0; renderView(); return; } }
    if (S.tab === t) return;
    S.tab = t; $('view').scrollTop = 0; renderView();
    storeSet('lk.tab', t);
  }

  // ---------- Start ----------
  function init() {
    Native.init();
    S.P = loadInitial();
    var t = storeGet('lk.tab'); if (t && VIEWS[t]) S.tab = t;
    var sb = storeGet('lk.sub'); if (sb && SUBVIEWS[sb]) S.sub = sb;
    A.update(S.P);
    renderDeck(); setReels(0);
    renderView();

    $('btnPlay').addEventListener('click', togglePlay);
    $('btnUndo').addEventListener('click', undo);
    $('btnNew').addEventListener('click', function () {
      newFromStyle(M.STYLE_BY_ID[S.P.style] ? S.P.style : M.pick(M.STYLES).id);
    });
    $('cassette').addEventListener('click', function () { setTab('proj'); setTimeout(function () { var f = document.querySelector('#view .field'); if (f) f.focus(); }, 50); });
    setTimeout(function () { try { A.warmFor(S.P); } catch (e) { /* später */ } }, 900);
    document.querySelectorAll('#tabs button').forEach(function (b) { b.addEventListener('click', function () { setTab(b.dataset.tab); }); });
    $('sheetClose').addEventListener('click', function () { closeSheet(); });
    $('scrim').addEventListener('click', function () { closeSheet(); });
    $('fileIn').addEventListener('change', function () {
      var f = this.files && this.files[0];
      if (!f) return;
      var rd = new FileReader();
      rd.onload = function () {
        try {
          var data = JSON.parse(String(rd.result));
          if (!data || typeof data !== 'object' || !data.chords) throw new Error('keine Lofi-Kassette-Datei');
          replaceProject(data, '„' + (data.name || 'Track') + '“ geöffnet');
        } catch (e) { toast('Datei nicht lesbar: ' + e.message); }
      };
      rd.onerror = function () { toast('Datei konnte nicht gelesen werden'); };
      rd.readAsText(f);
    });
    document.addEventListener('visibilitychange', function () { if (document.hidden) stopPlay(); });
    document.addEventListener('pointerdown', function () { A.resume(); }, true);
    // Unerwartete Fehler sichtbar machen (in der App gibt es keine Konsole)
    var shownErr = {};
    window.addEventListener('error', function (ev) {
      var m = ev && ev.message ? ev.message : 'Unbekannter Fehler';
      if (shownErr[m]) return;
      shownErr[m] = true;
      toast('Fehler: ' + m);
    });

    // Von der Android-Hülle aufgerufen
    window.lofiBack = function () { return closeSheet(); };
    window.lofiPause = function () { stopPlay(); return true; };

    // Klänge vorberechnen, bevor jemand auf Play tippt
    setTimeout(function () { try { A.warm(); } catch (e) { /* später */ } }, 400);
  }

  LK.UI = { init: init, state: S, Native: Native, saveFile: saveFile, edit: edit, setTab: setTab, startPlay: startPlay, stopPlay: stopPlay };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})(LK);
