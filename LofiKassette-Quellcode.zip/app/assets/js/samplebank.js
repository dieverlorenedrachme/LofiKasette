/* Lofi Kassette – Instrumenten-Samples: bei Bedarf laden, dekodieren, Ton für Ton bereitstellen */
'use strict';
var LK = window.LK || (window.LK = {});

(function (LK) {
  // Welche Instrumente als Samples vorliegen (erzeugt von offline-build/make_samples.py)
  var SAMPLED = { piano: 1, felt: 1, rhodes: 1, guitar: 1, upright: 1, harp: 1, vibes: 1, marimba: 1, musicbox: 1, kalimba: 1, strings: 1 };
  var me = document.currentScript && document.currentScript.src;
  var BASE = me ? me.replace(/samplebank\.js(\?.*)?$/, 'samples/') : 'js/samples/';
  var specs = {}, raw = {}, bufs = {}, pending = {}, decoder = null;

  function b64(s) {
    var bin = atob(s), n = bin.length, u = new Uint8Array(n);
    for (var i = 0; i < n; i++) u[i] = bin.charCodeAt(i);
    return u;
  }
  function decodeCtx() {
    if (!decoder) { var OAC = window.OfflineAudioContext || window.webkitOfflineAudioContext; decoder = new OAC(1, 1, 44100); }
    return decoder;
  }
  function decode(id) {
    var bytes = b64(raw[id]);
    raw[id] = null; // Base64-Text freigeben
    return new Promise(function (res, rej) { decodeCtx().decodeAudioData(bytes.buffer, res, rej); }).then(function (full) {
      var sr = full.sampleRate, ch = full.getChannelData(0);
      var list = specs[id].notes.map(function (n) {
        var a = Math.round(n.s * sr), len = Math.max(1, Math.min(Math.round(n.l * sr), ch.length - a));
        var b = new AudioBuffer({ length: len, numberOfChannels: 1, sampleRate: sr });
        b.copyToChannel(ch.subarray(a, a + len), 0);
        return { m: n.m, buf: b, loop: n.loop || null };
      });
      bufs[id] = list;
      return list;
    });
  }
  // Wird von den Dateien js/samples/<id>.js aufgerufen
  function add(id, spec, data) {
    specs[id] = spec; raw[id] = data;
    if (pending[id] && pending[id].go) pending[id].go();
  }
  function load(id) {
    if (bufs[id]) return Promise.resolve(bufs[id]);
    if (!SAMPLED[id]) return Promise.resolve(null);
    if (pending[id]) return pending[id].promise;
    var p = pending[id] = {};
    p.promise = new Promise(function (res, rej) {
      p.go = function () { p.go = null; decode(id).then(res, rej); };
      if (raw[id]) { p.go(); return; }
      var s = document.createElement('script');
      s.src = BASE + id + '.js';
      s.onerror = function () { rej(new Error('Klänge für ' + id + ' fehlen')); };
      document.head.appendChild(s);
    });
    p.promise.catch(function () { delete pending[id]; });
    return p.promise;
  }
  // nächstgelegener aufgenommener Ton
  function pick(id, m) {
    var list = bufs[id];
    if (!list) return null;
    var best = list[0], bd = 1e9;
    for (var i = 0; i < list.length; i++) {
      var d = Math.abs(list[i].m - m) + (list[i].m < m ? 0.01 : 0); // bei Gleichstand eher herunter als hinauf transponieren
      if (d < bd) { bd = d; best = list[i]; }
    }
    return best;
  }

  LK.SampleBank = {
    SAMPLED: SAMPLED, add: add, load: load, pick: pick,
    has: function (id) { return !!bufs[id]; },
    isSampled: function (id) { return !!SAMPLED[id]; }
  };
})(LK);
