/* Lofi Kassette 2 – Musiktheorie, Projektmodell, Stil-Rezepte und Generatoren */
'use strict';
var LK = window.LK || (window.LK = {});

(function (LK) {
  var SHARP = ['C', 'Cis', 'D', 'Dis', 'E', 'F', 'Fis', 'G', 'Gis', 'A', 'Ais', 'H'];
  var FLAT = ['C', 'Des', 'D', 'Es', 'E', 'F', 'Ges', 'G', 'As', 'A', 'B', 'H'];
  var FLAT_MAJOR = [false, true, false, true, false, true, true, false, true, false, true, false];
  var FLAT_MINOR = [true, false, true, true, false, true, false, true, false, false, true, false];

  var SCALE = { major: [0, 2, 4, 5, 7, 9, 11], minor: [0, 2, 3, 5, 7, 8, 10], dorian: [0, 2, 3, 5, 7, 9, 10] };
  var PENTA = { major: [0, 2, 4, 7, 9], minor: [0, 3, 5, 7, 10], dorian: [0, 3, 5, 7, 10] };
  var MODES = [
    { id: 'major', name: 'Dur', easy: 'Hell' },
    { id: 'minor', name: 'Moll', easy: 'Dunkel' },
    { id: 'dorian', name: 'Dorisch', easy: 'Jazzig' }
  ];
  var ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];

  // Obere Stimmen (ohne Grundton; den spielen linke Hand und Bass) und Akkordtöne
  var QUALITIES = {
    maj7: { label: 'maj7', upper: [4, 7, 11], tones: [0, 4, 7, 11] },
    maj9: { label: 'maj9', upper: [4, 7, 11, 14], tones: [0, 4, 7, 11, 14] },
    maj7s11: { label: 'maj7\u266f11', upper: [4, 11, 14, 18], tones: [0, 4, 7, 11, 18] },
    '6': { label: '6', upper: [4, 7, 9], tones: [0, 4, 7, 9] },
    '69': { label: '6/9', upper: [4, 7, 9, 14], tones: [0, 4, 7, 9, 14] },
    add9: { label: 'add9', upper: [4, 7, 14], tones: [0, 4, 7, 14] },
    '7': { label: '7', upper: [4, 7, 10], tones: [0, 4, 7, 10] },
    '9': { label: '9', upper: [4, 7, 10, 14], tones: [0, 4, 7, 10, 14] },
    '13': { label: '13', upper: [4, 10, 14, 21], tones: [0, 4, 7, 10, 14, 21] },
    '7b9': { label: '7\u266d9', upper: [4, 10, 13], tones: [0, 4, 7, 10, 13] },
    sus: { label: '9sus', upper: [5, 7, 10, 14], tones: [0, 5, 7, 10, 14] },
    m7: { label: 'm7', upper: [3, 7, 10], tones: [0, 3, 7, 10] },
    m9: { label: 'm9', upper: [3, 7, 10, 14], tones: [0, 3, 7, 10, 14] },
    m11: { label: 'm11', upper: [3, 10, 14, 17], tones: [0, 3, 7, 10, 14, 17] },
    m6: { label: 'm6', upper: [3, 7, 9], tones: [0, 3, 7, 9] },
    m7b5: { label: 'm7\u266d5', upper: [3, 6, 10], tones: [0, 3, 6, 10] },
    dim7: { label: '\u00b07', upper: [3, 6, 9], tones: [0, 3, 6, 9] }
  };
  var QUALITY_ORDER = ['maj7', 'maj9', 'maj7s11', '6', '69', 'add9', '7', '9', '13', '7b9', 'sus', 'm7', 'm9', 'm11', 'm6', 'm7b5', 'dim7'];
  var DEFAULT_Q = {
    major: ['maj9', 'm9', 'm7', 'maj7', '9', 'm9', 'm7b5'],
    minor: ['m9', 'm7b5', 'maj7', 'm9', 'm7', 'maj7', '9'],
    dorian: ['m9', 'm7', 'maj7', '9', 'm7', 'm7b5', 'maj7']
  };

  // ---------- Instrumente, Kits, Muster ----------
  var DRUM_ROWS = [
    { id: 'kick', name: 'Kick' }, { id: 'snare', name: 'Snare' }, { id: 'hat', name: 'Hi-Hat' },
    { id: 'rim', name: 'Rim' }, { id: 'shaker', name: 'Shaker' }
  ];
  function p(str) { var a = []; for (var i = 0; i < 16; i++) { var ch = str.charAt(i); a.push(ch === 'x' ? 1 : ch === 'o' ? 2 : ch === 'r' ? 3 : 0); } return a; }
  function pat(id, name, k, s, h, r, sh) { return { id: id, name: name, steps: { kick: p(k), snare: p(s), hat: p(h), rim: p(r), shaker: p(sh) } }; }
  var DRUM_PRESETS = [
    pat('boombap', 'Boom Bap', 'x......x..x.....', '....x.......x...', 'x.o.x.o.x.o.x.oo', '................', '..o...o...o...o.'),
    pat('schlurfen', 'Schlurfen', 'x.........x..x..', '....x.......x..o', 'xoxoxoxoxoxoxoxo', '.......o........', '................'),
    pat('halbzeit', 'Halbzeit', 'x..........x....', '........x.......', 'x.x.x.x.x.x.x.x.', '..............o.', 'o.o.o.o.o.o.o.o.'),
    pat('jazzig', 'Jazzig', 'x.........o.....', '......o.......o.', '....x.......x...', '....x.......x...', 'xoooxoooxoooxooo'),
    pat('stolpern', 'Stolpern', 'x..x.....xx.....', '....x.......x...', 'x.xox.xox.xox.xo', '...........o....', '................'),
    pat('minimal', 'Minimal', 'x.......x.......', '................', '..x...x...x...x.', '....x.......x...', '................'),
    pat('kopfnicker', 'Kopfnicker', 'x......xx.x.....', '....x.......x..o', 'x.x.x.x.x.x.x.x.', '...o............', '..............x.'),
    pat('bossa', 'Bossa', 'x.....x.x.....x.', '................', '................', 'x..x..x...x..x..', 'xoooxoooxoooxooo'),
    pat('besen', 'Besen-Swing', 'o...o...o...o...', '....o.......o...', 'x...x.x.x...x.x.', '................', '................'),
    pat('elektro', 'Elektro', 'x......x..x.....', '....x.......x...', 'xoxoxoxoxoxoxoxx', '................', '......x.......x.'),
    pat('sanft', 'Sanft', 'x.......x.o.....', '................', 'o.o.o.o.o.o.o.o.', '....x.......x...', '..o.......o.....')
  ];
  var KITS = [
    { id: 'staub', name: 'Staubig' }, { id: 'weich', name: 'Weich' }, { id: 'kassette', name: 'Kassette' },
    { id: 'kiste', name: 'Holzkiste' }, { id: 'besen', name: 'Besen' }, { id: 'elektro', name: 'Elektro' }
  ];
  var CHORD_INST = [
    { id: 'rhodes', name: 'E-Piano' }, { id: 'piano', name: 'Klavier' }, { id: 'felt', name: 'Filzklavier' },
    { id: 'guitar', name: 'Gitarre' }, { id: 'harp', name: 'Harfe' }, { id: 'strings', name: 'Streicher' },
    { id: 'pad', name: 'Fläche' }, { id: 'synthpad', name: 'Synthfläche' }
  ];
  var CHORD_STYLES = [
    { id: 'halten', name: 'Halten' }, { id: 'synkope', name: 'Synkope' }, { id: 'zweimal', name: 'Zweimal' },
    { id: 'stakkato', name: 'Stakkato' }, { id: 'arpeggio', name: 'Arpeggio' }, { id: 'bossa', name: 'Bossa' },
    { id: 'puls', name: 'Puls' }
  ];
  var VOICINGS = [{ id: 'nah', name: 'Eng' }, { id: 'weit', name: 'Weit' }, { id: 'hoch', name: 'Hoch' }];
  var BASS_INST = [
    { id: 'upright', name: 'Kontrabass' }, { id: 'sub', name: 'Sub' }, { id: 'synth', name: 'Synthbass' }, { id: '808', name: '808' }
  ];
  var BASS_STYLES = [
    { id: 'grund', name: 'Grundton' }, { id: 'federnd', name: 'Federnd' }, { id: 'laufend', name: 'Laufend' },
    { id: 'synkope', name: 'Synkope' }, { id: 'bossa', name: 'Bossa' }, { id: 'achtel', name: 'Achtel' }, { id: 'lang', name: 'Lang' },
    { id: 'eigen', name: 'Eigene Linie' }
  ];
  var MELODY_INST = [
    { id: 'flute', name: 'Flöte' }, { id: 'musicbox', name: 'Spieluhr' }, { id: 'vibes', name: 'Vibraphon' },
    { id: 'kalimba', name: 'Kalimba' }, { id: 'marimba', name: 'Marimba' }, { id: 'piano', name: 'Klavier' },
    { id: 'rhodes', name: 'E-Piano' }, { id: 'guitar', name: 'Gitarre' }, { id: 'harp', name: 'Harfe' },
    { id: 'trumpet', name: 'Trompete' }, { id: 'whistle', name: 'Pfeifen' }, { id: 'vox', name: 'Stimme' },
    { id: 'soft', name: 'Sanfter Synth' }
  ];
  var ATMOS = [
    { id: 'keine', name: 'Keine' }, { id: 'regen', name: 'Regen' }, { id: 'cafe', name: 'Café' },
    { id: 'meer', name: 'Meer' }, { id: 'voegel', name: 'Vögel' }, { id: 'kamin', name: 'Kaminfeuer' },
    { id: 'grillen', name: 'Sommernacht' }, { id: 'stadt', name: 'Stadt' }
  ];
  var MELODY_ROWS = 10;

  // ---------- Stil-Rezepte ----------
  // Akkord-Schreibweise: "ii:m9" = Stufe + Klang, "bVII:maj7" = erniedrigte Stufe, "ii:m7|V:7" = zwei Akkorde im Takt
  var STYLES = [
    { id: 'regennacht', name: 'Regennacht', desc: 'melancholisch, Klavier, Regen', color: '#8fa6d8',
      bpm: [64, 74], swing: [25, 40], feel: '16', modes: ['minor', 'minor', 'dorian'], bars: [4, 8],
      prog: { minor: [['Tropfen', 'i:m9 VI:maj9 iv:m9 v:m7'], ['Nachtfenster', 'i:m9 iv:m9 VII:9 III:maj7'], ['Heimweg', 'VI:maj7 v:m7 i:m9 i:m11'], ['Laterne', 'i:m7 VI:maj7 iv:m9 V:7b9']],
              dorian: [['Nebel', 'i:m9 IV:9 i:m9 VII:maj7'], ['Späte Bahn', 'i:m11 v:m7 IV:9 i:m9']] },
      chordInst: ['felt', 'felt', 'piano', 'pad'], comp: ['halten', 'synkope', 'halten'], voicing: ['nah', 'weit'],
      bassInst: ['sub', 'upright'], bassStyle: ['grund', 'federnd', 'lang'],
      kits: ['weich', 'staub'], patterns: ['halbzeit', 'minimal', 'sanft', 'schlurfen'], groove: [30, 55],
      melInst: ['musicbox', 'flute', 'vibes', 'kalimba'], melGen: ['sparsam', 'motiv'],
      atmo: ['regen', 'regen', 'stadt'], atmoAmt: [45, 70], dust: [55, 75], space: [45, 65], pump: [10, 25] },
    { id: 'kaffee', name: 'Jazz-Café', desc: 'swingend, E‑Piano, Kontrabass', color: '#e0a86a',
      bpm: [84, 96], swing: [35, 55], feel: '8', modes: ['major', 'dorian', 'minor'], bars: [4, 8], split: 0.6,
      prog: { major: [['Klassiker', 'ii:m9 V:9 I:maj9 vi:7'], ['Stammtisch', 'I:maj7 vi:m9 ii:m7|V:7 I:6'], ['Nachschlag', 'iii:m7 VI:7 ii:m9 V:13'], ['Espresso', 'IV:maj7 iii:m7 ii:m7|V:7b9 I:maj9']],
              dorian: [['Vamp', 'i:m9 IV:9 i:m9 IV:13'], ['Blaue Note', 'i:m11 IV:9 v:m7 VII:maj7']],
              minor: [['Moll-Kadenz', 'ii:m7b5 V:7b9 i:m9 i:m6'], ['Keller', 'i:m9 iv:m9 ii:m7b5|V:7b9 i:m9']] },
      chordInst: ['rhodes', 'rhodes', 'piano'], comp: ['synkope', 'stakkato', 'zweimal'], voicing: ['nah', 'weit'],
      bassInst: ['upright'], bassStyle: ['laufend', 'laufend', 'federnd'],
      kits: ['besen', 'staub'], patterns: ['besen', 'jazzig', 'boombap'], groove: [35, 60],
      melInst: ['trumpet', 'flute', 'vibes', 'rhodes'], melGen: ['lebhaft', 'motiv'],
      atmo: ['cafe'], atmoAmt: [35, 60], dust: [40, 60], space: [25, 45], pump: [10, 20] },
    { id: 'sonntag', name: 'Morgensonne', desc: 'hell, fröhlich, Vögel', color: '#e8cf6a',
      bpm: [86, 96], swing: [18, 32], feel: '16', modes: ['major'], bars: [4, 8],
      prog: { major: [['Aufstehen', 'I:maj7 IV:maj9 vi:m9 V:add9'], ['Frühstück', 'I:add9 vi:m7 IV:maj7 V:sus'], ['Balkon', 'IV:maj7 V:sus iii:m7 vi:m9'], ['Sonnenfleck', 'I:maj9 iii:m7 IV:maj7 iv:m6'], ['Spaziergang', 'I:6 vi:m9 IV:maj9 V:9']] },
      chordInst: ['piano', 'rhodes', 'guitar'], comp: ['synkope', 'zweimal', 'stakkato'], voicing: ['nah'],
      bassInst: ['upright', 'synth'], bassStyle: ['federnd', 'synkope'],
      kits: ['kassette', 'staub'], patterns: ['boombap', 'schlurfen', 'stolpern'], groove: [25, 45],
      melInst: ['whistle', 'vibes', 'kalimba', 'guitar'], melGen: ['lebhaft', 'motiv'],
      atmo: ['voegel'], atmoAmt: [35, 60], dust: [25, 45], space: [30, 50], pump: [15, 30] },
    { id: 'bossa', name: 'Bossa am Meer', desc: 'Gitarre, Shaker, Wellen', color: '#6fc3c0',
      bpm: [72, 82], swing: [0, 10], feel: '16', modes: ['major', 'minor'], bars: [4, 8], split: 0.4,
      prog: { major: [['Strandbar', 'I:maj7 II:7 ii:m7 V:7'], ['Brandung', 'ii:m7|V:7 I:maj7 I:6 vi:7'], ['Muschel', 'I:maj9 IV:9 iii:m7 VI:7b9']],
              minor: [['Saudade', 'i:m7 iv:m7 ii:m7b5|V:7b9 i:m6'], ['Dünen', 'i:m9 iv:m9 VII:9 III:maj7']] },
      chordInst: ['guitar'], comp: ['bossa'], voicing: ['nah'],
      bassInst: ['upright'], bassStyle: ['bossa'],
      kits: ['kiste'], patterns: ['bossa'], groove: [20, 40],
      melInst: ['flute', 'whistle', 'guitar'], melGen: ['bossa'],
      atmo: ['meer'], atmoAmt: [40, 65], dust: [30, 50], space: [30, 50], pump: [0, 10] },
    { id: 'traum', name: 'Traumwolke', desc: 'schwebend, zum Einschlafen', color: '#b9a3f0',
      bpm: [56, 66], swing: [0, 15], feel: '16', modes: ['major', 'major', 'minor'], bars: [8], long: 1, drumsOff: 0.8,
      prog: { major: [['Schweben', 'I:maj7s11 V:add9 vi:m9 IV:maj9'], ['Sternstaub', 'IV:maj9 I:maj7 IV:maj7s11 V:sus'], ['Mondsee', 'I:maj9 iii:m7 vi:m9 IV:maj7s11']],
              minor: [['Tiefschlaf', 'i:m9 VI:maj7s11 III:maj9 VII:add9'], ['Nachtwolke', 'VI:maj9 i:m11 VI:maj9 VII:6']] },
      chordInst: ['synthpad', 'pad'], comp: ['halten'], voicing: ['weit', 'hoch'],
      bassInst: ['sub'], bassStyle: ['lang'],
      kits: ['weich'], patterns: ['sanft'], groove: [20, 40],
      melInst: ['musicbox', 'kalimba', 'vox', 'soft'], melGen: ['sparsam'],
      atmo: ['meer', 'grillen', 'regen'], atmoAmt: [30, 55], dust: [20, 40], space: [70, 90], pump: [0, 0] },
    { id: 'retro', name: 'Retro-Synth', desc: '80er-Synths, Stadtnacht', color: '#e98fb8',
      bpm: [80, 92], swing: [0, 12], feel: '16', modes: ['minor', 'minor', 'dorian'], bars: [4, 8],
      prog: { minor: [['Neonlicht', 'i:m9 VI:maj7 III:maj7 VII:6'], ['Nachtfahrt', 'i:m7 i:m7 VI:maj9 VII:add9'], ['Arcade', 'VI:maj7 VII:6 i:m9 v:m7']],
              dorian: [['Skyline', 'i:m9 IV:add9 VII:maj7 i:m9']] },
      chordInst: ['synthpad', 'synthpad', 'rhodes'], comp: ['puls', 'halten'], voicing: ['nah', 'weit'],
      bassInst: ['synth', '808'], bassStyle: ['achtel', 'grund'],
      kits: ['elektro'], patterns: ['elektro', 'halbzeit'], groove: [15, 30],
      melInst: ['soft', 'vox'], melGen: ['arpeggio', 'motiv'],
      atmo: ['stadt', 'regen'], atmoAmt: [30, 55], dust: [55, 75], space: [45, 65], pump: [30, 45] },
    { id: 'kamin', name: 'Kaminabend', desc: 'warm, akustisch, Feuer', color: '#e89468',
      bpm: [68, 78], swing: [30, 45], feel: '8', modes: ['major', 'minor'], bars: [4, 8],
      prog: { major: [['Wolldecke', 'I:maj7 iii:m7 vi:m9 IV:maj7'], ['Kerzenlicht', 'vi:m7 ii:m7 V:sus I:maj9'], ['Hütte', 'I:6 IV:maj7 ii:m9 V:9']],
              minor: [['Schneefall', 'i:m7 iv:m7 VII:7 III:maj7'], ['Glut', 'i:m9 VI:maj7 ii:m7b5 V:7']] },
      chordInst: ['guitar', 'felt'], comp: ['arpeggio', 'halten'], voicing: ['nah'],
      bassInst: ['upright'], bassStyle: ['grund', 'laufend'],
      kits: ['besen'], patterns: ['besen', 'sanft'], groove: [30, 50],
      melInst: ['guitar', 'whistle', 'rhodes', 'flute'], melGen: ['motiv', 'sparsam'],
      atmo: ['kamin'], atmoAmt: [40, 65], dust: [45, 65], space: [30, 45], pump: [0, 15] },
    { id: 'kopfnicker', name: 'Kopfnicker', desc: 'schwerer Beat, rau', color: '#9fcf7c',
      bpm: [84, 92], swing: [40, 55], feel: '16', modes: ['minor', 'dorian'], bars: [4, 8],
      prog: { minor: [['Hinterhof', 'i:m9 iv:m9 i:m9 V:7b9'], ['Beton', 'i:m9 VI:maj7 ii:m7b5 V:7b9'], ['Plattenkiste', 'i:m11 i:m11 VI:maj7 VII:9']],
              dorian: [['Kopfhörer', 'i:m9 IV:9 i:m9 v:m7']] },
      chordInst: ['rhodes', 'felt', 'piano'], comp: ['synkope', 'halten', 'stakkato'], voicing: ['nah'],
      bassInst: ['808', 'sub', 'upright'], bassStyle: ['synkope', 'federnd'],
      kits: ['staub', 'kassette'], patterns: ['kopfnicker', 'stolpern', 'boombap'], groove: [45, 70],
      melInst: ['vox', 'trumpet', 'flute'], melGen: ['motiv', 'lebhaft'],
      atmo: ['stadt', 'keine', 'regen'], atmoAmt: [25, 45], dust: [60, 80], space: [20, 40], pump: [35, 50] },
    { id: 'lernen', name: 'Lernzimmer', desc: 'ruhig, zum Konzentrieren', color: '#86cdb8',
      bpm: [70, 80], swing: [15, 30], feel: '16', modes: ['major', 'minor'], bars: [8], long: 0.6,
      prog: { major: [['Schreibtisch', 'I:maj7 IV:maj7 vi:m9 V:sus'], ['Bibliothek', 'vi:m9 IV:maj9 I:maj7 V:add9']],
              minor: [['Fokus', 'i:m9 VI:maj7 III:maj7 VII:add9'], ['Tee', 'i:m7 iv:m9 VI:maj7 v:m7']] },
      chordInst: ['felt', 'rhodes', 'pad'], comp: ['halten', 'arpeggio'], voicing: ['weit', 'nah'],
      bassInst: ['sub', 'upright'], bassStyle: ['grund', 'lang'],
      kits: ['weich'], patterns: ['sanft', 'minimal'], groove: [20, 35],
      melInst: ['kalimba', 'musicbox', 'rhodes'], melGen: ['sparsam', 'arpeggio'],
      atmo: ['regen', 'kamin', 'cafe', 'keine'], atmoAmt: [25, 45], dust: [35, 55], space: [35, 55], pump: [5, 15] }
  ];
  var STYLE_BY_ID = {};
  STYLES.forEach(function (s) { STYLE_BY_ID[s.id] = s; });

  // Folgen für den Feinschliff (nach Tonart gruppiert)
  var PROGRESSIONS = { major: [], minor: [], dorian: [] };
  STYLES.forEach(function (s) {
    Object.keys(s.prog).forEach(function (m) {
      s.prog[m].forEach(function (pr) { PROGRESSIONS[m].push({ name: pr[0], chords: parseProg(pr[1]), style: s.id }); });
    });
  });

  function parseChord(tok) {
    var parts = tok.split(':'), r = parts[0], a = 0;
    if (r.charAt(0) === 'b') { a = -1; r = r.slice(1); }
    var d = ROMAN.indexOf(r.toUpperCase());
    if (d < 0 || !QUALITIES[parts[1]]) throw new Error('Akkord ' + tok);
    var c = { d: d, q: parts[1] };
    if (a) c.a = a;
    return c;
  }
  function parseProg(str) {
    return str.split(/\s+/).map(function (bar) {
      var halves = bar.split('|'), c = parseChord(halves[0]);
      if (halves[1]) c.h2 = parseChord(halves[1]);
      return c;
    });
  }

  // ---------- Hilfen ----------
  function clamp(v, lo, hi, def) { v = Number(v); if (!isFinite(v)) return def; return Math.max(lo, Math.min(hi, v)); }
  function pick(list, rnd) { return list[Math.floor((rnd || Math.random)() * list.length)]; }
  function range(r, rnd) { return Math.round(r[0] + (rnd || Math.random)() * (r[1] - r[0])); }
  function hasId(list, id) { for (var i = 0; i < list.length; i++) if (list[i].id === id) return true; return false; }
  function byId(list, id) { for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i]; return null; }
  function emptyRow() { var a = []; for (var i = 0; i < 16; i++) a.push(0); return a; }
  function emptyMelody() { var b = []; for (var i = 0; i < 8; i++) { var r = []; for (var s = 0; s < 16; s++) r.push(-1); b.push(r); } return b; }
  function copy(o) { return JSON.parse(JSON.stringify(o)); }
  function sameChord(a, b) { return a && b && a.d === b.d && a.q === b.q && (a.a || 0) === (b.a || 0); }

  function blankProject() {
    return {
      v: 2, name: 'Neuer Track', style: 'regennacht', song_id: '', bpm: 72, swing: 30, feel: '16', key: 2, mode: 'minor', bars: 4, song: 'song',
      drums: { kit: 'staub', fill: true, groove: 45, pattern: 'boombap', steps: copy(DRUM_PRESETS[0].steps) },
      chords: { inst: 'rhodes', style: 'halten', voicing: 'nah', prog: '', list: parseProg('i:m9 VI:maj9 iv:m9 v:m7 i:m9 VI:maj9 iv:m9 v:m7') },
      bass: { inst: 'upright', style: 'grund' },
      melody: { inst: 'flute', octave: 0, length: 2, scale: 'penta', gen: 'motiv', notes: emptyMelody() },
      atmo: { type: 'regen', amount: 50 },
      mute: { drums: false, chords: false, bass: false, melody: false, atmo: false },
      macro: { dust: 55, space: 45 },
      fx: { vinyl: 40, wobble: 30, filter: 62, drive: 25, crush: 0, reverb: 35, echo: 20, pump: 25 },
      mix: { drums: 80, chords: 70, melody: 70, bass: 75, atmos: 60, master: 85 }
    };
  }

  function normChord(ch) {
    if (!ch || !QUALITIES[ch.q]) return null;
    var o = { d: Math.round(clamp(ch.d, 0, 6, 0)), q: ch.q };
    var a = Math.round(clamp(ch.a, -1, 1, 0));
    if (a) o.a = a;
    return o;
  }

  // Bringt alte (v1) und fremde Daten in die aktuelle Form
  function normalize(src) {
    var o = blankProject();
    if (!src || typeof src !== 'object') return o;
    if (typeof src.name === 'string') o.name = src.name.slice(0, 60) || o.name;
    o.song_id = typeof src.song_id === 'string' ? src.song_id.slice(0, 40) : '';
    o.style = STYLE_BY_ID[src.style] ? src.style : (src.style === 'eigen' ? 'eigen' : (src.v >= 2 ? o.style : 'eigen'));
    o.bpm = Math.round(clamp(src.bpm, 55, 120, o.bpm));
    o.swing = Math.round(clamp(src.swing, 0, 60, o.swing));
    o.feel = src.feel === '8' ? '8' : '16';
    o.key = Math.round(clamp(src.key, 0, 11, o.key));
    o.mode = SCALE[src.mode] ? src.mode : 'minor';
    o.bars = src.bars === 8 ? 8 : 4;
    o.song = src.song === 'loop' ? 'loop' : (src.v >= 2 ? 'song' : 'loop');
    var sd = src.drums || {};
    if (hasId(KITS, sd.kit)) o.drums.kit = sd.kit;
    o.drums.fill = sd.fill !== false;
    o.drums.groove = Math.round(clamp(sd.groove, 0, 100, o.drums.groove));
    o.drums.pattern = typeof sd.pattern === 'string' ? sd.pattern : '';
    if (sd.steps) {
      DRUM_ROWS.forEach(function (r) {
        var row = sd.steps[r.id], out = emptyRow();
        if (row && row.length) for (var i = 0; i < 16; i++) out[i] = row[i] === 2 ? 2 : row[i] === 3 ? 3 : row[i] ? 1 : 0;
        o.drums.steps[r.id] = out;
      });
    }
    var sc = src.chords || {};
    if (hasId(CHORD_INST, sc.inst)) o.chords.inst = sc.inst;
    if (hasId(CHORD_STYLES, sc.style)) o.chords.style = sc.style;
    if (hasId(VOICINGS, sc.voicing)) o.chords.voicing = sc.voicing;
    o.chords.prog = typeof sc.prog === 'string' ? sc.prog : '';
    if (sc.list && sc.list.length) {
      for (var i = 0; i < 8; i++) {
        var ch = normChord(sc.list[i] || sc.list[i % sc.list.length]);
        if (ch) {
          var h2 = sc.list[i] && normChord(sc.list[i].h2);
          if (h2) ch.h2 = h2;
          o.chords.list[i] = ch;
        }
      }
    }
    var sb = src.bass || {};
    if (hasId(BASS_INST, sb.inst)) o.bass.inst = sb.inst;
    if (hasId(BASS_STYLES, sb.style)) o.bass.style = sb.style;
    if (typeof sb.pat === 'string' && /^[r357oa.\-]{16}$/.test(sb.pat)) o.bass.pat = sb.pat;
    if (o.bass.style === 'eigen' && !o.bass.pat) o.bass.style = 'federnd';
    var sm = src.melody || {};
    if (hasId(MELODY_INST, sm.inst)) o.melody.inst = sm.inst;
    o.melody.octave = Math.round(clamp(sm.octave, -1, 1, 0));
    o.melody.length = [1, 2, 4].indexOf(sm.length) >= 0 ? sm.length : 2;
    o.melody.scale = sm.scale === 'full' ? 'full' : 'penta';
    o.melody.gen = typeof sm.gen === 'string' ? sm.gen : 'motiv';
    if (sm.notes && sm.notes.length) {
      for (var b = 0; b < 8; b++) {
        var bar = sm.notes[b];
        for (var s = 0; s < 16; s++) {
          var v = bar && bar[s];
          o.melody.notes[b][s] = (typeof v === 'number' && v >= 0 && v < MELODY_ROWS) ? Math.round(v) : -1;
        }
      }
    }
    var sfx = src.fx || {};
    Object.keys(o.fx).forEach(function (k) { o.fx[k] = Math.round(clamp(sfx[k], 0, 100, o.fx[k])); });
    if (src.v === undefined || src.v < 2) o.fx.echo = Math.round(clamp(sfx.echo, 0, 100, 0));
    var smx = src.mix || {};
    Object.keys(o.mix).forEach(function (k) { o.mix[k] = Math.round(clamp(smx[k], 0, 100, o.mix[k])); });
    var sa = src.atmo;
    if (sa && hasId(ATMOS, sa.type)) o.atmo = { type: sa.type, amount: Math.round(clamp(sa.amount, 0, 100, 50)) };
    else if (sfx.rain > 0) o.atmo = { type: 'regen', amount: Math.round(clamp(sfx.rain, 0, 100, 50)) }; // v1: Regenregler
    else if (src.v === undefined || src.v < 2) o.atmo = { type: 'keine', amount: 50 };
    var mu = src.mute || {};
    Object.keys(o.mute).forEach(function (k) { o.mute[k] = mu[k] === true; });
    if (sb.on === false) o.mute.bass = true; // v1
    var ma = src.macro || {};
    o.macro.dust = Math.round(clamp(ma.dust, 0, 100, 50));
    o.macro.space = Math.round(clamp(ma.space, 0, 100, 40));
    return o;
  }

  // ---------- Namen ----------
  function useFlats(P) {
    if (P.mode === 'dorian') return FLAT_MAJOR[(P.key + 10) % 12];
    return (P.mode === 'major' ? FLAT_MAJOR : FLAT_MINOR)[P.key];
  }
  function noteName(pc, flats) { pc = ((pc % 12) + 12) % 12; return (flats ? FLAT : SHARP)[pc]; }
  function modeName(m) { return (byId(MODES, m) || MODES[1]).name; }
  function keyName(P) { return noteName(P.key, useFlats(P)) + '-' + modeName(P.mode); }
  function chordRootPc(P, ch) { return (P.key + SCALE[P.mode][ch.d] + (ch.a || 0) + 12) % 12; }
  function chordName(P, ch) {
    var flats = ch.a ? ch.a < 0 : useFlats(P);
    return noteName(chordRootPc(P, ch), flats) + QUALITIES[ch.q].label;
  }
  function barName(P, ch) { return chordName(P, ch) + (ch.h2 ? ' / ' + chordName(P, ch.h2) : ''); }
  function romanOf(P, ch) {
    var minorish = (ch.q.charAt(0) === 'm' && ch.q.indexOf('maj') !== 0) || ch.q === 'dim7';
    var r = ROMAN[ch.d];
    return (ch.a < 0 ? '\u266d' : ch.a > 0 ? '\u266f' : '') + (minorish ? r.toLowerCase() : r);
  }

  // ---------- Stimmführung ----------
  function voiceChord(rootPc, q, prev, style) {
    var ups = QUALITIES[q].upper, best = null, bestCost = 1e9;
    var lo = 52, hi = 79, span = 16, center = 64;
    if (style === 'hoch') { lo = 64; hi = 91; center = 75; }
    if (style === 'weit') { lo = 50; hi = 84; span = 26; center = 66; }
    for (var inv = 0; inv < ups.length; inv++) {
      for (var base = lo - 6; base <= hi - 6; base++) {
        var notes = [], last = -1;
        for (var k = 0; k < ups.length; k++) {
          var n = rootPc + ups[(inv + k) % ups.length];
          while (n < base) n += 12;
          while (n <= last) n += 12;
          notes.push(n); last = n;
        }
        if (style === 'weit' && notes.length >= 3) { // Drop-2: zweitoberste Stimme eine Oktave tiefer
          var x = notes.splice(notes.length - 2, 1)[0] - 12;
          notes.unshift(x); notes.sort(function (a, b) { return a - b; });
        }
        if (notes[0] < lo || notes[notes.length - 1] > hi) continue;
        if (notes[notes.length - 1] - notes[0] > span) continue;
        var c = 0; notes.forEach(function (n2) { c += n2; }); c /= notes.length;
        var cost = Math.abs(c - center) * 0.6;
        if (prev) notes.forEach(function (n2) { var m = 99; prev.forEach(function (q2) { m = Math.min(m, Math.abs(n2 - q2)); }); cost += m; });
        if (cost < bestCost - 1e-9) { bestCost = cost; best = notes; }
      }
    }
    return best || ups.map(function (i) { return 60 + ((rootPc + i) % 12); });
  }

  function chordInfo(P, ch, prev) {
    var rootPc = chordRootPc(P, ch);
    var voicing = voiceChord(rootPc, ch.q, prev, P.chords.voicing);
    var lh = 48 + rootPc; if (lh > 56) lh -= 12;
    var bassRoot = 28 + rootPc; if (bassRoot < 33) bassRoot += 12;
    var tones = QUALITIES[ch.q].tones.map(function (i) { return (rootPc + i) % 12; });
    return { rootPc: rootPc, q: ch.q, voicing: voicing, lh: lh, bassRoot: bassRoot, tones: tones, key: rootPc + ':' + ch.q };
  }

  // Abgeleitete Daten: pro halbem Takt ein Akkord ("Slot")
  function derive(P) {
    var slots = [], prev = null;
    for (var b = 0; b < 8; b++) {
      var ch = P.chords.list[b], A = chordInfo(P, ch, prev);
      prev = A.voicing;
      var B = A;
      if (ch.h2) { B = chordInfo(P, ch.h2, prev); prev = B.voicing; }
      slots.push(A, B);
    }
    var n = P.bars * 2;
    for (var i = 0; i < 16; i++) slots[i].next = slots[(i + 1) % n];
    for (var j = 0; j < 16; j++) { // nächster *anderer* Akkord (für Bass-Annäherung und Haltedauer)
      var k = 1; while (k < n && slots[(j + k) % n].key === slots[j].key) k++;
      slots[j].nextOther = slots[(j + k) % n];
    }
    var bars = [];
    for (var bb = 0; bb < 8; bb++) bars.push(slots[bb * 2]);
    return { slots: slots, bars: bars, rows: melodyRows(P), scale: SCALE[P.mode] };
  }

  function melodyRows(P) {
    var sc = P.melody.scale === 'full' ? SCALE[P.mode] : PENTA[P.mode];
    var base = 60 + P.key; if (base > 65) base -= 12;
    base += 12 * P.melody.octave;
    var rows = [];
    for (var i = 0; i < MELODY_ROWS; i++) rows.push(base + sc[i % sc.length] + 12 * Math.floor(i / sc.length));
    return rows;
  }

  // ---------- Melodie-Generatoren ----------
  var MOTIFS = [[0, 3, 6, 10], [2, 4, 7, 11], [0, 6, 8, 12], [4, 7, 10], [0, 2, 3, 8, 11], [1, 4, 6, 9], [6, 8, 12], [0, 10], [3, 6, 8, 14], [0, 4, 6, 7, 12]];
  var LIVELY = [[0, 2, 3, 6, 8, 10, 11], [1, 3, 4, 7, 9, 12, 14], [0, 3, 4, 6, 10, 12, 13], [2, 3, 5, 8, 10, 14]];
  var SPARSE = [[0], [0, 8], [6], [0, 10], [4], [2, 12]];
  var BOSSA_R = [[0, 3, 6, 10, 12], [2, 6, 8, 11, 14], [0, 3, 8, 11], [3, 6, 10, 14]];

  function nearestTone(rows, chord, target) {
    var best = target, bd = 99;
    for (var r = 0; r < MELODY_ROWS; r++) {
      if (chord.tones.indexOf(rows[r] % 12) >= 0) { var dd = Math.abs(r - target); if (dd < bd) { bd = dd; best = r; } }
    }
    return best;
  }

  function randomMelody(P, rnd, gen) {
    rnd = rnd || Math.random;
    gen = gen || P.melody.gen || 'motiv';
    var D = derive(P), rows = D.rows, notes = emptyMelody();
    var cur = 3 + Math.floor(rnd() * 3);
    function place(bar, s, target, strong) {
      var chord = D.slots[(bar % P.bars) * 2 + (s >= 8 ? 1 : 0)];
      target = Math.max(0, Math.min(MELODY_ROWS - 1, target));
      if (strong) target = nearestTone(rows, chord, target);
      if (target > 7 && rnd() < 0.5) target -= 2;
      notes[bar][s] = target; cur = target;
    }
    if (gen === 'arpeggio') {
      var shape = pick([[0, 1, 2, 1], [0, 1, 2, 3], [2, 1, 0, 1], [0, 2, 1, 3]], rnd), stepEvery = pick([2, 2, 4], rnd);
      for (var bar = 0; bar < 8; bar++) {
        var chord = D.slots[(bar % P.bars) * 2], tonesRows = [];
        for (var r = 2; r < MELODY_ROWS && tonesRows.length < 4; r++) if (chord.tones.indexOf(rows[r] % 12) >= 0) tonesRows.push(r);
        var rest = bar % 4 === 3 && rnd() < 0.7 ? 8 : 16;
        for (var s = 0, k = 0; s < rest; s += stepEvery, k++) notes[bar][s] = tonesRows[shape[k % shape.length] % tonesRows.length] || 3;
      }
      return notes;
    }
    var pool = gen === 'lebhaft' ? LIVELY : gen === 'sparsam' ? SPARSE : gen === 'bossa' ? BOSSA_R : MOTIFS;
    var a = pick(pool, rnd), b = pick(pool, rnd);
    for (var br = 0; br < 8; br++) {
      if (gen === 'sparsam' && br % 2 === 1 && rnd() < 0.55) continue; // viel Luft
      var motif = br % 2 === 0 ? a : b;
      if (br % 4 === 3 && rnd() < 0.6) motif = motif.slice(0, Math.max(1, motif.length - 2));
      for (var q = 0; q < motif.length; q++) {
        var st = motif[q], step = pick(gen === 'sparsam' ? [-2, -1, 1, 2] : [-2, -1, -1, 0, 1, 1, 2], rnd);
        place(br, st, cur + step, st % 4 === 0 || q === 0);
      }
    }
    return notes;
  }

  function randomName(rnd) {
    var ADJ = ['Späte', 'Leise', 'Blaue', 'Warme', 'Müde', 'Stille', 'Goldene', 'Verregnete', 'Letzte', 'Kleine', 'Neblige', 'Weiche'];
    var NOUN = ['Stunde', 'Straßenbahn', 'Tasse', 'Laterne', 'Postkarte', 'Wolke', 'Nacht', 'Kassette', 'Brise', 'Dämmerung', 'Pause', 'Treppe', 'Küche', 'Allee', 'Insel', 'Uhr'];
    rnd = rnd || Math.random;
    return pick(ADJ, rnd) + ' ' + pick(NOUN, rnd);
  }


  // ---------- Grundmusiken ----------
  function songs() { return LK.SONGS || []; }
  function songsOf(styleId) { return songs().filter(function (s) { return s.style === styleId; }); }
  function drumSteps(def) {
    if (typeof def === 'string') { var pr = byId(DRUM_PRESETS, def); return pr ? copy(pr.steps) : null; }
    var o = {};
    DRUM_ROWS.forEach(function (r, i) { o[r.id] = p(def[i] || ''); });
    return o;
  }
  function setBass(P, def) {
    P.bass.inst = def[0];
    if (def[1].length === 16) { P.bass.style = 'eigen'; P.bass.pat = def[1]; }
    else { P.bass.style = def[1]; delete P.bass.pat; }
  }
  function setDrums(P, sg) {
    if (sg.drums === 'aus') { P.mute.drums = true; P.drums.pattern = 'sanft'; P.drums.steps = copy(byId(DRUM_PRESETS, 'sanft').steps); }
    else { P.mute.drums = false; P.drums.steps = drumSteps(sg.drums); P.drums.pattern = typeof sg.drums === 'string' ? sg.drums : 'song:' + sg.id; }
    P.drums.kit = sg.kit;
  }
  function fromSong(id) {
    var sg = LK.SONG_BY_ID && LK.SONG_BY_ID[id];
    if (!sg) return fromStyle(STYLES[0].id);
    var st = STYLE_BY_ID[sg.style], P = blankProject();
    P.style = sg.style; P.song_id = sg.id; P.name = sg.name;
    P.key = sg.key; P.mode = sg.mode; P.bpm = sg.bpm; P.swing = sg.swing; P.feel = sg.feel; P.bars = 8; P.song = 'song';
    P.chords.list = parseProg(sg.chords); P.chords.prog = sg.name;
    P.chords.inst = sg.inst; P.chords.style = sg.comp; P.chords.voicing = sg.voicing;
    setBass(P, sg.bass);
    setDrums(P, sg);
    P.drums.groove = Math.round((st.groove[0] + st.groove[1]) / 2);
    P.melody.inst = sg.mel[0]; P.melody.octave = sg.mel[1]; P.melody.length = sg.mel[2]; P.melody.scale = sg.mel[3];
    P.melody.gen = pick(st.melGen); P.melody.notes = melodyFrom(sg.mel[4]);
    P.atmo = { type: sg.atmo[0], amount: sg.atmo[1] || 20 };
    P.macro = { dust: sg.dust, space: sg.space };
    applyMacros(P);
    P.fx.pump = sg.pump;
    if (sg.mix) Object.keys(sg.mix).forEach(function (k) { P.mix[k] = sg.mix[k]; });
    return P;
  }

  // Welche Töne über einem Akkord auf betonten Zählzeiten gut klingen (Abstand zum Grundton)
  function allowedRel(q) {
    var t = QUALITIES[q].tones.map(function (x) { return x % 12; });
    var minor = (q.charAt(0) === 'm' && q.indexOf('maj') !== 0) || q === 'dim7';
    if (q !== '7b9' && q !== 'm7b5' && q !== 'dim7') t.push(2);
    if (minor && q !== 'm7b5') t.push(5);
    if (!minor) t.push(9);
    if (q === '7b9') t.push(1, 8);
    return t;
  }
  function noteOk(P, D, bar, s, row) {
    var sl = D.slots[(bar % P.bars) * 2 + (s >= 8 ? 1 : 0)];
    var rel = ((D.rows[row] - sl.rootPc) % 12 + 12) % 12;
    return allowedRel(sl.q).indexOf(rel) >= 0;
  }
  function noteLen(P, bar, s) {
    for (var k = 1; k <= 4; k++) { var ss = s + k, b = (bar + Math.floor(ss / 16)) % 8; if (P.melody.notes[b][ss % 16] >= 0) return k; }
    return Math.max(4, P.melody.length);
  }
  // betonte oder lange Töne, die nicht zum Akkord passen, auf den nächsten passenden Ton schieben
  function fitMelody(P) {
    var D = derive(P), moved = 0;
    for (var b = 0; b < 8; b++) {
      for (var s = 0; s < 16; s++) {
        var row = P.melody.notes[b][s];
        if (row < 0) continue;
        var strong = s % 4 === 0 || noteLen(P, b, s) >= 3;
        if (!strong || noteOk(P, D, b, s, row)) continue;
        for (var d = 1; d < MELODY_ROWS; d++) {
          if (row - d >= 0 && noteOk(P, D, b, s, row - d)) { P.melody.notes[b][s] = row - d; moved++; break; }
          if (row + d < MELODY_ROWS && noteOk(P, D, b, s, row + d)) { P.melody.notes[b][s] = row + d; moved++; break; }
        }
      }
    }
    return moved;
  }
  function melodyIssues(P) {
    var D = derive(P), out = [];
    for (var b = 0; b < 8; b++) for (var s = 0; s < 16; s++) {
      var row = P.melody.notes[b][s];
      if (row >= 0 && (s % 4 === 0 || noteLen(P, b, s) >= 3) && !noteOk(P, D, b, s, row)) out.push((b + 1) + ':' + (s + 1));
    }
    return out;
  }
  // Abwandlung einer Melodie: Motive verschieben, umspielen, Oktave wechseln – der Charakter bleibt
  function varyMelody(P, rnd) {
    var n = P.melody.notes, out = emptyMelody();
    var shift = pick([0, 1, -1, 2], rnd), swap = rnd() < 0.4;
    for (var b = 0; b < 8; b++) {
      var src = swap && b >= 4 ? n[b - 4] : swap && b < 4 ? n[b + 4] : n[b];
      for (var s = 0; s < 16; s++) {
        var r = src[s];
        if (r < 0) continue;
        var ns = s;
        if (s % 4 !== 0 && rnd() < 0.3) ns = Math.max(0, Math.min(15, s + pick([-1, 1], rnd)));
        var nr = Math.max(0, Math.min(MELODY_ROWS - 1, r + shift + (rnd() < 0.2 ? pick([-1, 1], rnd) : 0)));
        if (out[b][ns] < 0) out[b][ns] = nr;
        if (rnd() < 0.12 && s + 2 < 16 && src[s + 1] < 0 && src[s + 2] < 0) out[b][s + 2] = Math.max(0, Math.min(MELODY_ROWS - 1, nr + pick([-1, 1], rnd)));
      }
    }
    P.melody.notes = out;
    fitMelody(P);
  }

  // ---------- Klang-Makros ----------
  // "Lofi" (sauber ↔ staubig) und "Raum" (nah ↔ weit) steuern mehrere Effekte zugleich
  function applyMacros(P) {
    var d = P.macro.dust / 100, s = P.macro.space / 100, st = STYLE_BY_ID[P.style];
    var vinylMul = st && st.id === 'traum' ? 0.4 : 1;
    var dd = d * d; // bis zur Mitte klar und warm, darüber deutlich staubig
    P.fx.filter = Math.round(100 - (d * 0.35 + dd * 0.35) * 100);
    P.fx.wobble = Math.round(3 + dd * (st && st.id === 'retro' ? 60 : 38));
    P.fx.drive = Math.round(4 + d * 34);
    P.fx.vinyl = Math.round(d * 45 * vinylMul);
    P.fx.crush = 0;
    P.fx.reverb = Math.round(6 + s * 44);
    P.fx.echo = Math.round(s * 42);
    return P;
  }

  // ---------- Stil-Generatoren ----------
  function chooseProgression(P, st, rnd, avoid) {
    var list = st.prog[P.mode] || st.prog.minor || st.prog.major;
    var options = list.filter(function (pr) { return pr[0] !== avoid; });
    if (!options.length) options = list;
    var pr = pick(options, rnd), prog = parseProg(pr[1]);
    var longChords = st.long && rnd() < st.long;
    var out = [];
    if (longChords) { // jeder Akkord zwei Takte
      for (var i = 0; i < 8; i++) out.push(copy(prog[Math.floor(i / 2) % prog.length]));
    } else {
      for (var j = 0; j < 8; j++) out.push(copy(prog[j % prog.length]));
      if (rnd() < 0.5) { // zweite Hälfte variieren: andere Folge oder neuer Schluss
        var other = pick(list, rnd), op = parseProg(other[1]);
        out[6] = copy(op[2 % op.length]); out[7] = copy(op[3 % op.length]);
      }
      if (st.split && !out[3].h2 && rnd() < st.split) { // ii–V in einem Takt
        var target = out[4 % out.length];
        var v = { d: (target.d + 4) % 7, q: '7' };
        out[3] = { d: (target.d + 1) % 7, q: P.mode === 'major' ? 'm7' : 'm7b5', h2: v };
        out[7] = copy(out[3]);
      }
    }
    P.chords.list = out;
    P.chords.prog = pr[0];
    if (longChords) P.bars = 8;
  }

  function chooseDrums(P, st, rnd, avoid) {
    var pats = st.patterns.filter(function (id) { return id !== avoid; });
    if (!pats.length) pats = st.patterns;
    var id = pick(pats, rnd), base = copy(byId(DRUM_PRESETS, id).steps);
    if (id !== 'bossa' && id !== 'besen') { // kleine Abwandlungen, damit nichts nach Vorlage klingt
      [3, 7, 13, 14].forEach(function (s) { if (!base.kick[s] && rnd() < 0.15) base.kick[s] = 2; });
      [7, 10, 15].forEach(function (s) { if (!base.snare[s] && base.snare.indexOf(1) >= 0 && rnd() < 0.18) base.snare[s] = 2; });
      for (var s = 1; s < 16; s += 2) if (!base.hat[s] && base.hat.some(Boolean) && rnd() < 0.12) base.hat[s] = 2;
    }
    P.drums.steps = base;
    P.drums.pattern = id;
    P.drums.kit = pick(st.kits, rnd);
    P.drums.groove = range(st.groove, rnd);
  }

  function chooseBass(P, st, rnd) {
    var combos = [];
    st.bassInst.forEach(function (i) { st.bassStyle.forEach(function (s) { combos.push([i, s]); }); });
    var opts = combos.filter(function (c) { return c[0] !== P.bass.inst || c[1] !== P.bass.style; });
    var c = pick(opts.length ? opts : combos, rnd);
    P.bass.inst = c[0]; P.bass.style = c[1];
  }

  function chooseMelody(P, st, rnd, changeInst) {
    if (changeInst) {
      var insts = st.melInst.filter(function (i) { return i !== P.melody.inst; });
      P.melody.inst = pick(insts.length ? insts : st.melInst, rnd);
    }
    P.melody.gen = pick(st.melGen, rnd);
    P.melody.octave = P.melody.inst === 'musicbox' || P.melody.inst === 'kalimba' ? 1 : P.melody.inst === 'trumpet' ? 0 : 0;
    P.melody.length = P.melody.gen === 'sparsam' ? 4 : P.melody.gen === 'lebhaft' || P.melody.gen === 'arpeggio' ? 1 : pick([1, 2, 2], rnd);
    P.melody.scale = P.melody.gen === 'lebhaft' && rnd() < 0.4 ? 'full' : 'penta';
    P.melody.notes = randomMelody(P, rnd, P.melody.gen);
  }

  function chooseAtmo(P, st, rnd, next) {
    var list = st.atmo;
    if (next) {
      var all = ATMOS.map(function (a) { return a.id; }).filter(function (id) { return id !== 'keine'; });
      var pool = list.filter(function (id) { return id !== P.atmo.type && id !== 'keine'; });
      if (!pool.length) pool = all.filter(function (id) { return id !== P.atmo.type; });
      P.atmo.type = pick(pool, rnd);
    } else {
      P.atmo.type = pick(list, rnd);
    }
    P.atmo.amount = range(st.atmoAmt, rnd);
  }

  function fromStyle(styleId, rnd) {
    rnd = rnd || Math.random;
    var st = STYLE_BY_ID[styleId] || STYLES[0];
    var P = blankProject();
    P.style = st.id;
    P.name = randomName(rnd);
    P.mode = pick(st.modes, rnd);
    P.key = Math.floor(rnd() * 12);
    P.bpm = range(st.bpm, rnd);
    P.swing = range(st.swing, rnd);
    P.feel = st.feel;
    P.bars = pick(st.bars, rnd);
    P.song = 'song';
    chooseProgression(P, st, rnd);
    P.chords.inst = pick(st.chordInst, rnd);
    P.chords.style = pick(st.comp, rnd);
    if (P.chords.inst === 'pad' || P.chords.inst === 'synthpad') P.chords.style = P.chords.style === 'puls' ? 'puls' : 'halten';
    P.chords.voicing = pick(st.voicing, rnd);
    chooseBass(P, st, rnd);
    chooseDrums(P, st, rnd);
    P.mute.drums = !!(st.drumsOff && rnd() < st.drumsOff);
    P.melody.inst = pick(st.melInst, rnd);
    chooseMelody(P, st, rnd, false);
    chooseAtmo(P, st, rnd);
    P.macro.dust = range(st.dust, rnd);
    P.macro.space = range(st.space, rnd);
    applyMacros(P);
    P.fx.pump = range(st.pump, rnd);
    if (st.id === 'traum') { P.mix.chords = 80; P.mix.melody = 62; }
    if (st.id === 'bossa') P.mix.drums = 68;
    if (st.id === 'kopfnicker') { P.mix.drums = 88; P.mix.bass = 82; }
    return P;
  }

  // Eine Spur innerhalb der Stimmung austauschen ("Anders") – bevorzugt mit komponiertem Material
  function reroll(P, layer, rnd) {
    rnd = rnd || Math.random;
    var st = STYLE_BY_ID[P.style] || STYLES[0], pool = songsOf(st.id).filter(function (sg) { return sg.id !== P.song_id; });
    if (layer === 'drums') {
      var cur = JSON.stringify(P.drums.steps), opts = pool.filter(function (sg) { return sg.drums !== 'aus' && JSON.stringify(drumSteps(sg.drums)) !== cur; });
      if (opts.length && rnd() < 0.75) {
        var d = pick(opts, rnd); P.drums.steps = drumSteps(d.drums); P.drums.pattern = typeof d.drums === 'string' ? d.drums : 'song:' + d.id;
        if (rnd() < 0.5) P.drums.kit = d.kit;
      } else chooseDrums(P, st, rnd, P.drums.pattern);
    } else if (layer === 'chords') {
      var same = pool.filter(function (sg) { return sg.mode === P.mode && sg.chords !== P.chords.prog; });
      if (same.length && rnd() < 0.8) {
        var c = pick(same, rnd); P.chords.list = parseProg(c.chords); P.chords.prog = c.name;
        if (rnd() < 0.3) P.chords.style = c.comp;
      } else {
        var bars = P.bars; chooseProgression(P, st, rnd, P.chords.prog); P.bars = Math.max(bars, P.bars);
      }
      fitMelody(P);
    } else if (layer === 'bass') {
      var bo = pool.filter(function (sg) { return sg.bass[0] !== P.bass.inst || sg.bass[1] !== (P.bass.pat || P.bass.style); });
      if (bo.length && rnd() < 0.7) setBass(P, pick(bo, rnd).bass); else { delete P.bass.pat; chooseBass(P, st, rnd); }
    } else if (layer === 'melody') {
      var mo = pool.filter(function (sg) { return sg.mode === P.mode; }), r = rnd();
      if (mo.length && r < 0.45) {
        var m = pick(mo, rnd); P.melody.notes = melodyFrom(m.mel[4]); P.melody.scale = m.mel[3]; P.melody.length = m.mel[2];
        fitMelody(P);
      } else if (r < 0.85) varyMelody(P, rnd);
      else chooseMelody(P, st, rnd, false);
      if (rnd() < 0.3) {
        var insts = st.melInst.filter(function (i) { return i !== P.melody.inst; });
        if (insts.length) P.melody.inst = pick(insts, rnd);
      }
    } else if (layer === 'atmo') chooseAtmo(P, st, rnd, true);
    return P;
  }

  // nächste Grundmusik einer Stimmung (nie dieselbe wie gerade)
  function nextSong(styleId, currentId, rnd) {
    var list = songsOf(styleId).filter(function (sg) { return sg.id !== currentId; });
    return list.length ? pick(list, rnd || Math.random).id : null;
  }

  // Tonart-Farbe wechseln: Stufen bleiben, Klangfarben passen sich an
  function setMode(P, mode) {
    if (!SCALE[mode] || P.mode === mode) return P;
    P.mode = mode;
    P.chords.list.forEach(function (ch) {
      if (!ch.a) ch.q = DEFAULT_Q[mode][ch.d];
      if (ch.h2 && !ch.h2.a) ch.h2.q = DEFAULT_Q[mode][ch.h2.d] === 'm7b5' ? 'm7b5' : (ch.h2.q === '7' || ch.h2.q === '7b9' ? ch.h2.q : DEFAULT_Q[mode][ch.h2.d]);
    });
    fitMelody(P);
    return P;
  }

  function seeded(seed) {
    var s = seed >>> 0;
    return function () {
      s = (s + 0x6D2B79F5) >>> 0;
      var t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function melodyFrom(spec) {
    var m = emptyMelody();
    for (var b = 0; b < 8; b++) {
      var str = spec[b % spec.length];
      for (var s = 0; s < 16; s++) { var ch = str.charAt(s); m[b][s] = ch >= '0' && ch <= '9' ? ch.charCodeAt(0) - 48 : -1; }
    }
    return m;
  }

  // Startpunkte: drei Grundmusiken
  function templates() {
    return ['tropfen', 'kaffee3', 'schweben'].map(function (id) { return fromSong(id); });
  }

  LK.M = {
    SCALE: SCALE, PENTA: PENTA, MODES: MODES, QUALITIES: QUALITIES, QUALITY_ORDER: QUALITY_ORDER, DEFAULT_Q: DEFAULT_Q,
    PROGRESSIONS: PROGRESSIONS, DRUM_ROWS: DRUM_ROWS, DRUM_PRESETS: DRUM_PRESETS, KITS: KITS,
    CHORD_INST: CHORD_INST, CHORD_STYLES: CHORD_STYLES, VOICINGS: VOICINGS, BASS_INST: BASS_INST, BASS_STYLES: BASS_STYLES,
    MELODY_INST: MELODY_INST, MELODY_ROWS: MELODY_ROWS, ATMOS: ATMOS, ROMAN: ROMAN, STYLES: STYLES, STYLE_BY_ID: STYLE_BY_ID,
    blankProject: blankProject, normalize: normalize, copy: copy, emptyRow: emptyRow, emptyMelody: emptyMelody,
    noteName: noteName, keyName: keyName, modeName: modeName, chordName: chordName, barName: barName,
    chordRootPc: chordRootPc, romanOf: romanOf, useFlats: useFlats, derive: derive, melodyRows: melodyRows,
    voiceChord: voiceChord, parseProg: parseProg, sameChord: sameChord, byId: byId,
    fromStyle: fromStyle, reroll: reroll, setMode: setMode, applyMacros: applyMacros,
    fromSong: fromSong, songsOf: songsOf, nextSong: nextSong, fitMelody: fitMelody, melodyIssues: melodyIssues, varyMelody: varyMelody,
    randomProject: function (rnd) { var all = songs(); return all.length ? fromSong(pick(all, rnd).id) : fromStyle(pick(STYLES, rnd).id, rnd); },
    randomDrums: function (rnd) { var P = blankProject(); chooseDrums(P, STYLES[0], rnd || Math.random); return P.drums.steps; },
    randomMelody: randomMelody, randomName: randomName, seeded: seeded, templates: templates, pick: pick
  };
})(LK);
