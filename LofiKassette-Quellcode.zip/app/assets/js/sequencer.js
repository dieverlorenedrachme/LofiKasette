/* Lofi Kassette 2 – Sequencer: Song-Ablauf, Live-Wiedergabe, Vorhören, WAV-Export */
'use strict';
var LK = window.LK || (window.LK = {});

(function (LK) {
  var M = LK.M, S = LK.Sounds, Engine = LK.Engine, SR = S.SR, SB = LK.SampleBank;

  // benötigte Sample-Instrumente laden (Fehler: Ersatzklang)
  function prepare(P) {
    var ids = [P.chords.inst, P.melody.inst, P.bass.inst].filter(function (id) { return SB.isSampled(id); });
    return Promise.all(ids.map(function (id) { return SB.load(id).catch(function () { return null; }); }));
  }

  // ---------- Begleitmuster ----------
  var CHORD_HITS = {
    halten: [{ s: 0, len: 16, v: 1 }],
    synkope: [{ s: 0, len: 6, v: 1 }, { s: 10, len: 6, v: 0.8 }],
    zweimal: [{ s: 0, len: 8, v: 1 }, { s: 8, len: 8, v: 0.75 }],
    stakkato: [{ s: 0, len: 2, v: 1 }, { s: 6, len: 2, v: 0.7 }, { s: 8, len: 2, v: 0.9 }, { s: 14, len: 2, v: 0.65 }],
    arpeggio: [0, 2, 4, 6, 8, 10, 12, 14].map(function (s, i) { return { s: s, len: 4, v: i % 4 === 0 ? 0.95 : 0.75, arp: i }; }),
    bossa: [{ s: 0, len: 2, v: 0.95 }, { s: 3, len: 2, v: 0.7 }, { s: 6, len: 3, v: 0.8 }, { s: 10, len: 2, v: 0.75 }, { s: 12, len: 3, v: 0.85 }],
    puls: [0, 2, 4, 6, 8, 10, 12, 14].map(function (s, i) { return { s: s, len: 2, v: i % 2 ? 0.68 : 0.9 }; })
  };
  var HOLDING = { halten: true };
  var STRUM = { rhodes: 0.011, piano: 0.013, felt: 0.016, guitar: 0.024, harp: 0.03, pad: 0, synthpad: 0, strings: 0 };

  function isMinorQ(q) { return (q.charAt(0) === 'm' && q.indexOf('maj') !== 0) || q === 'dim7'; }
  function stepDur(P) { return 60 / P.bpm / 4; }
  // Swing: "16" verschiebt jede zweite Sechzehntel, "8" jede zweite Achtel (bei 60 % Triolen-Gefühl)
  function swingOff(P, g) {
    var sd = stepDur(P), sw = P.swing / 100;
    if (P.feel === '8') {
      var k = g % 4, f = Math.min(1, sw / 0.6) * (2 / 3);
      return (k === 2 ? f : k === 1 || k === 3 ? f * 0.5 : 0) * sd;
    }
    return g % 2 === 1 ? sd * sw * 0.55 : 0;
  }

  function slotIndex(bar, s) { return bar * 2 + (s >= 8 ? 1 : 0); }
  // Wie viele Schritte klingt der Akkord ab (bar, s) noch, bis ein anderer kommt?
  function stepsUntilChange(D, P, bar, s) {
    var n = P.bars * 2, idx = slotIndex(bar, s), cur = D.slots[idx], steps = (s >= 8 ? 16 : 8) - s;
    for (var k = 1; k < n; k++) { if (D.slots[(idx + k) % n].key !== cur.key) break; steps += 8; }
    return Math.min(steps, 64);
  }
  function prevSame(D, P, bar, s) {
    var n = P.bars * 2, idx = slotIndex(bar, s);
    return D.slots[(idx - 1 + n) % n].key === D.slots[idx].key;
  }

  var BASS_PAT = {
    grund: [[0, 16, 'r', 1]],
    federnd: [[0, 6, 'r', 1], [7, 2, 'r', 0.6], [10, 4, '5', 0.85], [14, 2, 'a', 0.7]],
    laufend: [[0, 4, 'r', 1], [4, 4, '3', 0.8], [8, 4, '5', 0.85], [12, 4, 'a', 0.75]],
    synkope: [[0, 3, 'r', 1], [3, 3, 'r', 0.7], [8, 2, '5', 0.75], [10, 5, 'r', 0.9]],
    bossa: [[0, 5, 'r', 1], [6, 2, '5', 0.75], [8, 5, 'r', 0.9], [14, 2, '5', 0.7]],
    achtel: [0, 2, 4, 6, 8, 10, 12, 14].map(function (s, i) { return [s, 2, i % 4 === 2 ? 'o' : 'r', i % 2 ? 0.65 : 0.85]; }),
    lang: [[0, 0, 'r', 1, 'tie']]
  };
  // Eigene Linie: r Grundton, 3 Terz, 5 Quinte, 7 Septime, o Oktave, a Annäherung, - halten, . Pause
  var patCache = {};
  function parseBass(str) {
    if (patCache[str]) return patCache[str];
    var out = [];
    for (var i = 0; i < 16; i++) {
      var ch = str.charAt(i);
      if ('r357oa'.indexOf(ch) < 0) continue;
      var len = 1; while (i + len < 16 && str.charAt(i + len) === '-') len++;
      out.push([i, len, ch, i % 4 === 0 ? 1 : 0.8]);
    }
    return (patCache[str] = out);
  }
  function bassNotesAt(P, D, bar, s) {
    var pat = P.bass.style === 'eigen' && P.bass.pat ? parseBass(P.bass.pat) : (BASS_PAT[P.bass.style] || BASS_PAT.federnd), out = [];
    var split = D.slots[bar * 2 + 1].key !== D.slots[bar * 2].key;
    var list = pat;
    if (split && (P.bass.style === 'grund' || P.bass.style === 'lang')) list = [[0, 8, 'r', 1], [8, 8, 'r', 0.9]];
    for (var i = 0; i < list.length; i++) {
      var e = list[i];
      if (e[0] !== s) continue;
      var sl = D.slots[slotIndex(bar, s)], root = sl.bassRoot, nx = sl.nextOther.bassRoot, n;
      if (e[2] === 'r') n = root;
      else if (e[2] === 'o') n = root + 12;
      else if (e[2] === '5') n = root + 7;
      else if (e[2] === '3') n = root + (sl.q === 'sus' ? 5 : isMinorQ(sl.q) ? 3 : 4);
      else if (e[2] === '7') n = root + (sl.q.indexOf('maj') === 0 ? 11 : sl.q === '6' || sl.q === 'm6' || sl.q === '69' ? 9 : 10);
      else n = nx === root ? root + 7 : nx + (nx > root ? -1 : 1);
      var len = e[4] === 'tie' ? stepsUntilChange(D, P, bar, s) : e[1];
      if (split && s < 8 && s + len > 8) len = 8 - s; // am Akkordwechsel enden
      out.push({ n: n, len: len, v: e[3], tie: e[4] === 'tie' });
    }
    return out;
  }

  function melodyDur(P, bar, s) {
    var max = P.melody.length, bars = P.bars;
    for (var k = 1; k <= max; k++) {
      var ss = s + k, b = (bar + Math.floor(ss / 16)) % bars;
      if (P.melody.notes[b][ss % 16] >= 0) return k;
    }
    return max;
  }

  // ---------- Song-Ablauf ----------
  var SEC = {
    intro: { name: 'Intro', flags: { drums: false, bass: false, melody: false }, fx: 'open' },
    a1: { name: 'Teil A', flags: { melody: false }, fx: 'normal' },
    a: { name: 'Teil A', flags: {}, fx: 'normal' },
    pause: { name: 'Pause', flags: { drums: 'light', melody: false }, fx: 'dip' },
    b: { name: 'Teil B', flags: { drums: 'plus', melody: 'up' }, fx: 'normal' },
    outro: { name: 'Outro', flags: { drums: 'light', melody: false }, fx: 'fade' },
    loop: { name: 'Schleife', flags: {}, fx: 'normal' }
  };
  var LIVE_SONG = ['intro', 'a1', 'a', 'pause', 'b', 'b'];
  function liveSection(P, loopIdx) {
    if (P.song === 'loop') return 'loop';
    if (loopIdx < LIVE_SONG.length) return LIVE_SONG[loopIdx];
    return LIVE_SONG[1 + (loopIdx - 1) % (LIVE_SONG.length - 1)];
  }
  function exportPlan(P, loops, songForm) {
    var main = [], i;
    if (!songForm) { for (i = 0; i < loops; i++) main.push('loop'); return main; }
    var first = ['a1', 'a', 'pause', 'b', 'b'], again = ['a', 'a', 'pause', 'b', 'b'];
    for (i = 0; i < loops; i++) main.push(i < first.length ? first[i] : again[(i - first.length) % again.length]);
    if (main[main.length - 1] === 'pause') main[main.length - 1] = 'b';
    return ['intro'].concat(main, ['outro']);
  }

  // plant alle Klänge eines 16tel-Schritts
  function scheduleStep(E, P, D, g, t, kind, secStart, secDur) {
    var sec = SEC[kind] || SEC.loop, flags = sec.flags;
    var loopSteps = P.bars * 16, bar = Math.floor(g / 16) % P.bars, s = g % 16, sd = stepDur(P), rnd = E.rnd;
    var rep = Math.floor(g / loopSteps), groove = P.drums.groove / 100, n = P.bars * 2;
    if (secStart && sec.fx !== 'fade') E.sectionFx(sec.fx, t, secDur || loopSteps * sd);

    if (!P.mute.drums && flags.drums !== false) {
      var fill = P.drums.fill && bar === P.bars - 1 && s >= 11 && flags.drums !== 'light';
      var hatActive = P.drums.steps.hat.some(Boolean);
      M.DRUM_ROWS.forEach(function (row) {
        var v = P.drums.steps[row.id][s];
        if (flags.drums === 'light' && (row.id === 'kick' || row.id === 'snare')) v = 0;
        if (fill) {
          if (row.id === 'snare' && !v && (s === 11 || s === 14)) v = 2;
          if (row.id === 'hat' && !v && s >= 12 && hatActive) v = 2;
          if (row.id === 'kick' && s >= 12) v = 0;
        }
        if (flags.drums === 'plus') {
          if (row.id === 'hat' && !v && hatActive && s % 2 === 1 && rnd() < 0.4) v = 2;
          if (row.id === 'kick' && !v && s === 14 && rnd() < 0.3) v = 2;
        }
        if (rep % 2 === 1 && !v && row.id === 'snare' && (s === 7 || s === 15) && P.drums.steps.snare.some(Boolean) && rnd() < 0.12) v = 2;
        if (!v) return;
        var vel = (v === 2 ? 0.42 : v === 3 ? 0.6 : 1) * (1 - groove * 0.22 * rnd());
        var jit = (rnd() - 0.5) * 0.014 * groove + (row.id === 'snare' || row.id === 'rim' ? 0.007 * groove : 0);
        var pan = { hat: 0.22, shaker: -0.28, rim: -0.15 }[row.id] || 0;
        E.drum(P.drums.kit, row.id, t + jit, vel, pan);
        if (v === 3) E.drum(P.drums.kit, row.id, t + jit + sd / 2, vel * 0.7, pan);
        if (row.id === 'kick' && v === 1) E.pumpAt(t);
      });
    }

    var idx = slotIndex(bar, s), sl = D.slots[idx];
    if (!P.mute.chords && flags.chords !== false) {
      var style = P.chords.style, inst = P.chords.inst, strum = STRUM[inst] || 0;
      var hits = CHORD_HITS[style].filter(function (h) { return h.s === s; });
      if (s === 8 && HOLDING[style] && !hits.length && sl.key !== D.slots[bar * 2].key) hits = [{ s: 8, len: 8, v: 0.9 }];
      hits.forEach(function (h) {
        var until = stepsUntilChange(D, P, bar, s), len = h.len;
        if (HOLDING[style]) {
          if (s === 0 && g > 0 && !secStart && prevSame(D, P, bar, s)) return; // Akkord klingt weiter
          len = until;
        } else len = Math.min(len, until);
        var dur = len * sd - 0.02, vel = h.v * (0.9 + (rnd() - 0.5) * 0.12);
        if (h.arp !== undefined) {
          var all = [sl.lh].concat(sl.voicing), seq = all.concat(all.slice(1, -1).reverse());
          E.voice('chords', inst, seq[h.arp % seq.length], t, dur, vel * 0.9);
          return;
        }
        if (P.mute.bass || !(inst === 'pad' || inst === 'synthpad' || inst === 'strings')) E.voice('chords', inst, sl.lh, t, dur, vel * 0.62);
        sl.voicing.forEach(function (nn, i) { E.voice('chords', inst, nn, t + (i + 1) * strum, dur - (i + 1) * strum, vel); });
      });
    }

    if (!P.mute.bass && flags.bass !== false) {
      bassNotesAt(P, D, bar, s).forEach(function (bn) {
        if (bn.tie && s === 0 && g > 0 && !secStart && prevSame(D, P, bar, s)) return;
        E.voice('bass', P.bass.inst, bn.n, t + 0.004, bn.len * sd - 0.02, bn.v);
      });
    }

    if (!P.mute.melody && flags.melody !== false) {
      var row = P.melody.notes[bar][s];
      if (row >= 0) {
        var k = melodyDur(P, bar, s), note = D.rows[row];
        if (flags.melody === 'up' && note + 12 <= 96) note += 12;
        E.voice('melody', P.melody.inst, note, t, k * sd - 0.03, 0.85 + (rnd() - 0.5) * 0.15);
      }
    }
  }

  // ---------- Live-Wiedergabe ----------
  var live = { ctx: null, E: null, timer: 0, playing: false, step: 0, next: 0, queue: [], P: null, D: null };

  function ensure() {
    if (!live.ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      live.ctx = new AC({ latencyHint: 'balanced' });
      live.E = new Engine(live.ctx, { live: true });
      if (live.P) live.E.apply(live.P);
    }
    if (live.ctx.state === 'suspended') live.ctx.resume();
    return live;
  }
  function resume() {
    if (live.ctx && live.ctx.state !== 'running' && live.ctx.state !== 'closed') {
      try { live.ctx.resume(); } catch (e) { /* nächster Versuch beim nächsten Antippen */ }
    }
  }
  function status() { return live.ctx ? { state: live.ctx.state, rate: live.ctx.sampleRate, time: live.ctx.currentTime } : null; }

  function setProject(P) {
    live.P = P; live.D = M.derive(P);
    if (live.E) live.E.apply(P);
    prepare(P);
  }

  function tick() {
    var ctx = live.ctx, P = live.P, ahead = ctx.currentTime + 0.16;
    while (live.next + swingOff(P, live.step) < ahead) {
      var t = live.next + swingOff(P, live.step), loopSteps = P.bars * 16;
      var kind = liveSection(P, Math.floor(live.step / loopSteps));
      scheduleStep(live.E, P, live.D, live.step, t, kind, live.step % loopSteps === 0);
      live.queue.push({ step: live.step, t: t, kind: kind });
      live.step++;
      live.next += stepDur(P);
    }
    if (live.queue.length > 64) live.queue.splice(0, live.queue.length - 64);
  }

  function play() {
    ensure();
    if (live.playing) return;
    live.playing = true; live.started = false;
    var token = live.token = (live.token || 0) + 1;
    function go() { if (live.playing && !live.started && live.token === token) startNow(); }
    var guard = setTimeout(go, 2500);
    prepare(live.P).then(function () { clearTimeout(guard); go(); });
  }
  function startNow() {
    live.started = true;
    live.E.apply(live.P);
    live.step = 0; live.queue = [];
    live.next = live.ctx.currentTime + 0.1;
    live.E.startAtmos(live.ctx.currentTime + 0.05, live.P);
    tick();
    live.timer = setInterval(tick, 25);
  }

  function stop() {
    if (!live.playing) return;
    live.playing = false;
    if (live.started) {
      clearInterval(live.timer);
      live.E.silence();
      live.E.stopAtmos(live.ctx.currentTime + 0.1);
    }
    live.started = false;
    live.queue = [];
  }

  function current() {
    if (!live.playing || !live.queue.length) return null;
    var now = live.ctx.currentTime - (live.ctx.outputLatency || live.ctx.baseLatency || 0), cur = null;
    for (var i = 0; i < live.queue.length; i++) { if (live.queue[i].t <= now) cur = live.queue[i]; else break; }
    return cur;
  }
  function position() { var c = current(); return c ? c.step : null; }
  function section() { var c = current(); return c ? SEC[c.kind].name : ''; }

  function previewNote(track, inst, m, dur) {
    ensure();
    live.E.voice(track, inst, m, live.ctx.currentTime + 0.02, dur || 0.5, 0.9);
  }
  function previewDrum(id) {
    ensure();
    live.E.drum(live.P.drums.kit, id, live.ctx.currentTime + 0.02, 1, 0);
  }
  function previewChord(barIdx, half) {
    ensure();
    var D = M.derive(live.P), B = D.slots[barIdx * 2 + (half ? 1 : 0)], t = live.ctx.currentTime + 0.03, inst = live.P.chords.inst;
    live.E.voice('chords', inst, B.lh, t, 1.2, 0.75);
    B.voicing.forEach(function (n, i) { live.E.voice('chords', inst, n, t + (i + 1) * 0.015, 1.2, 0.9); });
  }
  function preview(kind, arg) {
    if (!live.P) return;
    if (kind === 'drum') previewDrum(arg);
    else if (kind === 'chord') previewChord(arg || 0);
    else if (kind === 'melody') previewNote('melody', live.P.melody.inst, arg, 0.6);
    else if (kind === 'bass') previewNote('bass', live.P.bass.inst, arg, 0.6);
  }

  // ---------- Export ----------
  var TAIL = 2.5;
  function loopSeconds(P) { return P.bars * 16 * stepDur(P); }
  function exportDuration(P, loops, songForm) {
    return exportPlan(P, loops, songForm).length * loopSeconds(P) + (songForm ? TAIL : 0.02);
  }
  // Anzahl Durchläufe für eine gewünschte Länge in Minuten
  function loopsForMinutes(P, minutes, songForm) {
    var extra = songForm ? 2 * loopSeconds(P) + TAIL : 0;
    return Math.max(1, Math.round((minutes * 60 - extra) / loopSeconds(P)));
  }

  function render(P, opts) {
    return prepare(P).then(function () { return renderNow(P, opts); });
  }
  function renderNow(P, opts) {
    var loops = opts.loops, songForm = !!opts.songForm, onProgress = opts.onProgress;
    var D = M.derive(P), plan = exportPlan(P, loops, songForm), loopSteps = P.bars * 16, sd = stepDur(P);
    var totalSteps = plan.length * loopSteps, dur = exportDuration(P, loops, songForm);
    var ctx = new OfflineAudioContext(2, Math.ceil(dur * SR), SR);
    var E = new Engine(ctx, { seed: 20260922 });
    E.apply(P, 0);
    E.startAtmos(0, P);
    var gainTarget = Math.pow(P.mix.master / 100, 1.5) * 1.1;
    if (songForm) {
      E.final.gain.setValueAtTime(0, 0);
      E.final.gain.linearRampToValueAtTime(gainTarget, 1.2);
      var outroStart = (totalSteps - loopSteps) * sd;
      E.final.gain.setValueAtTime(gainTarget, outroStart);
      E.final.gain.linearRampToValueAtTime(0, dur - 0.05);
    }
    var g = 0;
    function upTo(tEnd) {
      while (g < totalSteps) {
        var t = g * sd + swingOff(P, g);
        if (t >= tEnd) break;
        var kind = plan[Math.floor(g / loopSteps)];
        scheduleStep(E, P, D, g, Math.max(0, t), kind, g % loopSteps === 0, loopSteps * sd);
        g++;
      }
    }
    var CH = 3;
    upTo(CH + 0.6);
    for (var tt = CH; tt < dur - 0.1; tt += CH) {
      (function (at) {
        ctx.suspend(at).then(function () {
          upTo(at + CH + 0.6);
          if (onProgress) onProgress(at / dur);
          ctx.resume();
        });
      })(tt);
    }
    return ctx.startRendering().then(function (buf) { E.dispose(); return buf; });
  }

  // WAV (16 Bit PCM, auf -1 dBFS normalisiert) als Byte-Quelle, die erst beim Lesen kodiert:
  // beim Speichern liegt so nie eine zweite, komplette Kopie des Tracks im Speicher.
  function wavSource(buf) {
    var ch = buf.numberOfChannels, n = buf.length, data = [], peak = 0, i, c;
    for (c = 0; c < ch; c++) data.push(buf.getChannelData(c));
    for (c = 0; c < ch; c++) {
      var d = data[c];
      for (i = 0; i < n; i++) { var v = d[i] < 0 ? -d[i] : d[i]; if (v > peak) peak = v; }
    }
    var gain = peak > 0 ? 0.891 / peak : 1;
    var fadeIn = Math.min(n, Math.floor(0.004 * buf.sampleRate)), fadeOut = Math.min(n, Math.floor(0.02 * buf.sampleRate));
    var fb = ch * 2, total = 44 + n * fb;
    var head = new Uint8Array(44), dv = new DataView(head.buffer);
    function str(o, s) { for (var k = 0; k < s.length; k++) head[o + k] = s.charCodeAt(k); }
    str(0, 'RIFF'); dv.setUint32(4, 36 + n * fb, true); str(8, 'WAVE'); str(12, 'fmt ');
    dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, ch, true);
    dv.setUint32(24, buf.sampleRate, true); dv.setUint32(28, buf.sampleRate * fb, true);
    dv.setUint16(32, fb, true); dv.setUint16(34, 16, true); str(36, 'data'); dv.setUint32(40, n * fb, true);
    function sample(f, cc) {
      var w = gain;
      if (f < fadeIn) w *= f / fadeIn;
      if (f >= n - fadeOut) w *= (n - 1 - f) / fadeOut;
      var x = data[cc][f] * w;
      x = x > 1 ? 1 : x < -1 ? -1 : x;
      return Math.round(x * 32767);
    }
    function subarray(a, b) {
      a = Math.max(0, a || 0); b = Math.min(total, b == null ? total : b);
      var out = new Uint8Array(Math.max(0, b - a)), o = 0, p = a;
      for (; p < b && p < 44; p++) out[o++] = head[p];
      if (p >= b) return out;
      var f0 = Math.floor((p - 44) / fb), f1 = Math.ceil((b - 44) / fb);
      var tmp = new Uint8Array((f1 - f0) * fb), tv = new DataView(tmp.buffer), q = 0;
      for (var f = f0; f < f1; f++) for (var cc = 0; cc < ch; cc++) { tv.setInt16(q, sample(f, cc), true); q += 2; }
      var st = (p - 44) - f0 * fb;
      out.set(tmp.subarray(st, st + (b - p)), o);
      return out;
    }
    return { length: total, peak: peak, subarray: subarray, materialize: function () { return subarray(0, total); } };
  }

  function encodeWav(buf) {
    var src = wavSource(buf);
    return { bytes: src.materialize(), peak: src.peak };
  }


  // Klänge vorab berechnen, damit der erste Druck auf Play nicht stockt
  function warmFor(P) {
    prepare(P);
    S.drum(P.drums.kit, 'kick'); M.DRUM_ROWS.forEach(function (r) { S.drum(P.drums.kit, r.id); });
    S.atmo(P.atmo.type); S.vinyl();
    if (live.ctx) S.ir(live.ctx.sampleRate);
  }
  function warm() {
    S.ir(SR); S.noise();
    if (live.P) warmFor(live.P);
  }

  LK.Audio = {
    update: setProject, setProject: setProject, preview: preview, warm: warm, warmFor: warmFor, resume: resume, status: status,
    play: function (P) { if (P) setProject(P); play(); }, stop: stop, isPlaying: function () { return live.playing; },
    position: position, section: section, ensure: ensure, SR: SR, mtof: S.mtof,
    previewNote: previewNote, previewDrum: previewDrum, previewChord: previewChord,
    scheduleStep: scheduleStep, stepDur: stepDur, swingOff: swingOff, liveSection: liveSection,
    render: render, encodeWav: encodeWav, wavSource: wavSource, exportDuration: exportDuration, exportPlan: exportPlan,
    loopsForMinutes: loopsForMinutes, prepare: prepare, ready: function () { return live.P ? prepare(live.P) : Promise.resolve(); }, loopSeconds: loopSeconds, CHORD_HITS: CHORD_HITS, SECTIONS: SEC,
    _cache: S._cache, _renderDrum: S._renderDrum
  };
})(LK);
