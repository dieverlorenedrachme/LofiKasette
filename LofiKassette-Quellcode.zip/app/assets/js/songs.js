/* Lofi Kassette – 40 handkomponierte Grundmusiken.
   Akkorde: Stufe:Klang je Takt ("ii:m7|V:7" = zwei Akkorde im Takt, "bVII" = erniedrigt).
   Melodie: je Takt 16 Zeichen, Ziffer = Zeile der Tonleiter (0 = Grundton), "." = Pause.
   Schlagzeug: Name eines Musters oder [Kick, Snare, Hi-Hat, Rim, Shaker]: x Schlag, o leise, r Wirbel.
   Bass: [Instrument, Spielweise] oder [Instrument, eigene Linie] mit r 3 5 7 o a (Grundton, Terz, Quinte,
   Septime, Oktave, Annäherung), "-" halten, "." Pause. */
'use strict';
var LK = window.LK || (window.LK = {});

(function (LK) {
  var SONGS = [];
  function S(id, style, name, o) { o.id = id; o.style = style; o.name = name; SONGS.push(o); }

  // ---------------- Regennacht ----------------
  S('tropfen', 'regennacht', 'Tropfen am Fenster', { key: 2, mode: 'minor', bpm: 70, swing: 30, feel: '16',
    chords: 'i:m9 VI:maj9 iv:m9 v:m7 i:m9 VI:maj9 iv:m9 V:7b9', inst: 'felt', comp: 'synkope', voicing: 'nah',
    bass: ['upright', 'federnd'], kit: 'weich', drums: ['x.........x.....', '....x.......x...', 'x.x.x.x.x.x.x.xo', '................', '................'],
    mel: ['flute', 0, 2, 'penta', ['..5..6.5...3....', '4.......3..1....', '..5..6.7...6....', '5.....4...3..2..',
      '..5..6.5...3....', '4...5...7.......', '6.5.3...2.......', '3.......2...3...']],
    atmo: ['regen', 22], dust: 48, space: 45, pump: 15 });
  S('nachtbus', 'regennacht', 'Nachtbus', { key: 9, mode: 'dorian', bpm: 74, swing: 26, feel: '16',
    chords: 'i:m9 i:m9 IV:9 IV:9 v:m7 VII:maj7 i:m11 IV:13', inst: 'rhodes', comp: 'halten', voicing: 'weit',
    bass: ['sub', 'lang'], kit: 'staub', drums: 'halbzeit',
    mel: ['vibes', 1, 4, 'penta', ['4.......3.......', '2...1.......0...', '3.......5.......', '6...5...3.......',
      '4.......3...2...', '2.......4...5...', '5.......6...8...', '7.......6..5....']],
    atmo: ['stadt', 15], dust: 40, space: 55, pump: 10 });
  S('laterne', 'regennacht', 'Laternenlicht', { key: 4, mode: 'minor', bpm: 66, swing: 22, feel: '16',
    chords: 'i:m9 iv:m9 VII:add9 III:maj7 VI:maj7 iv:m7 ii:m7b5 V:7', inst: 'piano', comp: 'arpeggio', voicing: 'nah',
    bass: ['sub', 'grund'], kit: 'weich', drums: 'minimal',
    mel: ['musicbox', 1, 2, 'penta', ['3.4.5...4.3.....', '2.......1.2.....', '0.2.3...2.......', '1.......3.......',
      '3.4.5...4.3.....', '2.......0.1.....', '2...0...2.......', '3.......2...3...']],
    atmo: ['regen', 18], dust: 42, space: 58, pump: 0 });
  S('strassen', 'regennacht', 'Nasse Straßen', { key: 0, mode: 'minor', bpm: 72, swing: 32, feel: '16',
    chords: 'i:m9 i:m9 VI:maj7 VI:maj7 iv:m9 iv:m9 V:7b9 V:7b9', inst: 'strings', comp: 'halten', voicing: 'weit',
    bass: ['upright', 'r-------5---o-a-'], kit: 'staub', drums: 'schlurfen',
    mel: ['harp', 0, 2, 'penta', ['5.4.3.1.3.......', '4...5...6.......', '6.5.3.5.6.......', '5...4...3.......',
      '7.6.5.3.2.......', '5...6...5.......', '3...2...3...8...', '8.......3.......']],
    atmo: ['regen', 20], dust: 45, space: 50, pump: 15 });
  S('schlaflos', 'regennacht', 'Schlaflos', { key: 5, mode: 'minor', bpm: 64, swing: 20, feel: '16',
    chords: 'i:m9 VI:maj9 III:maj7 VII:add9 i:m9 VI:maj9 iv:m9 V:sus', inst: 'felt', comp: 'halten', voicing: 'weit',
    bass: ['sub', 'lang'], kit: 'weich', drums: 'sanft', mix: { drums: 55 },
    mel: ['piano', 0, 4, 'penta', ['3.......1.......', '0.......1...3...', '4.......3.......', '2.......0.......',
      '5.......4...3...', '6.......5.......', '7...6...5.......', '3.......0.......']],
    atmo: ['keine', 0], dust: 35, space: 62, pump: 0 });

  // ---------------- Jazz-Café ----------------
  S('kaffee3', 'kaffee', 'Kaffee um drei', { key: 5, mode: 'major', bpm: 88, swing: 45, feel: '8',
    chords: 'ii:m9 V:9 I:maj9 VI:7 ii:m9 V:9 I:maj9 ii:m7|V:7', inst: 'rhodes', comp: 'synkope', voicing: 'nah',
    bass: ['upright', 'laufend'], kit: 'besen', drums: 'besen',
    mel: ['vibes', 0, 2, 'penta', ['2.4.5...4..2....', '..5.4...1.3.....', '2.4.5...7..5....', '4...2.....3.....',
      '2.4.5...4..2....', '..5.4...1.3.....', '7.6.5.4.2.......', '1...4...3...1...']],
    atmo: ['cafe', 18], dust: 40, space: 32, pump: 10 });
  S('bluenote', 'kaffee', 'Blue-Note-Ecke', { key: 10, mode: 'major', bpm: 92, swing: 55, feel: '8',
    chords: 'I:maj7 vi:m7 ii:m7 V:7 iii:m7 VI:7 ii:m9 V:13', inst: 'piano', comp: 'stakkato', voicing: 'nah',
    bass: ['upright', 'laufend'], kit: 'besen', drums: ['o...o...o...o...', '......o.......o.', 'x...x.x.x...x.x.', '....x.......x...', '................'],
    mel: ['trumpet', 0, 2, 'full', ['9...8.7.6.......', '4.......7..5....', '5.6.7.8.3.......', '6...4...1..6....',
      '9...8.6.4.......', '5.......2..4....', '3.5.7.8.9.......', '8.......6..4....']],
    atmo: ['keine', 0], dust: 38, space: 30, pump: 5 });
  S('espresso', 'kaffee', 'Espresso doppio', { key: 7, mode: 'dorian', bpm: 90, swing: 45, feel: '16',
    chords: 'i:m9 i:m9 IV:9 IV:9 i:m9 v:m7 VII:maj7 IV:13', inst: 'rhodes', comp: 'zweimal', voicing: 'nah',
    bass: ['upright', 'federnd'], kit: 'staub', drums: ['x......xx.......', '....x.......x...', 'x.xox.x.x.xox.x.', '...........o....', '................'],
    mel: ['flute', 1, 2, 'penta', ['..3.4.5...4.3...', '6.......5.......', '..3.5.6...5.3...', '7.......6...5...',
      '8.7.5...4.......', '3.......4...7...', '7...5...4.......', '6.......5..3....']],
    atmo: ['cafe', 15], dust: 45, space: 35, pump: 20 });
  S('regentag', 'kaffee', 'Regentag im Café', { key: 3, mode: 'major', bpm: 84, swing: 40, feel: '8',
    chords: 'I:maj9 IV:maj7 iii:m7 vi:m9 ii:m9 V:7b9 I:69 V:sus', inst: 'piano', comp: 'synkope', voicing: 'weit',
    bass: ['upright', 'laufend'], kit: 'staub', drums: 'jazzig',
    mel: ['guitar', 0, 2, 'penta', ['3.2.3...5...6...', '5.......4...2...', '1.2.3...6.......', '5...4...2.......',
      '4.5.6...7.......', '6...3.......1...', '2.3.4...5.......', '6.......3.......']],
    atmo: ['cafe', 20], dust: 42, space: 38, pump: 10 });
  S('mitternacht', 'kaffee', 'Mitternachtsjazz', { key: 0, mode: 'minor', bpm: 86, swing: 58, feel: '8',
    chords: 'i:m9 iv:m9 ii:m7b5 V:7b9 i:m9 VI:maj7 ii:m7b5|V:7b9 i:m6', inst: 'rhodes', comp: 'stakkato', voicing: 'weit',
    bass: ['upright', 'laufend'], kit: 'besen', drums: 'besen',
    mel: ['trumpet', 0, 2, 'full', ['4.......2.1.0...', '5.......4...7...', '5.3.1...5.......', '4.......5...3...',
      '7.8.9...8.7.....', '9.......7...4...', '5...3...3...1...', '2.......0.......']],
    atmo: ['keine', 0], dust: 44, space: 40, pump: 5 });

  // ---------------- Morgensonne ----------------
  S('ersterkaffee', 'sonntag', 'Erster Kaffee', { key: 7, mode: 'major', bpm: 92, swing: 28, feel: '16',
    chords: 'I:maj7 IV:maj9 vi:m9 V:add9 I:maj7 IV:maj9 ii:m7 V:sus', inst: 'piano', comp: 'synkope', voicing: 'nah',
    bass: ['upright', 'federnd'], kit: 'kassette', drums: 'boombap',
    mel: ['whistle', 1, 2, 'penta', ['5.6.7...8..7....', '9.......8...7...', '5.6.7...8..9....', '8.......6...3...',
      '5.6.7...8..7....', '9...8...7...5...', '6.......4...5...', '3.......5...6...']],
    atmo: ['voegel', 18], dust: 30, space: 35, pump: 20 });
  S('fahrrad', 'sonntag', 'Fahrradtour', { key: 2, mode: 'major', bpm: 96, swing: 20, feel: '16',
    chords: 'I:add9 iii:m7 IV:maj7 V:9 vi:m7 iii:m7 IV:maj7 V:sus', inst: 'guitar', comp: 'zweimal', voicing: 'nah',
    bass: ['upright', 'r--.r-5-r--.o-a-'], kit: 'kassette', drums: 'stolpern',
    mel: ['marimba', 0, 1, 'penta', ['5.3.2.3.5...6...', '7.....6.3.......', '4.3.4.5.7.......', '6.....4.3.......',
      '4.5.7.8.7.......', '6.....7.3.......', '5.4.3.4.5...7...', '6.......5.......']],
    atmo: ['voegel', 15], dust: 28, space: 30, pump: 25 });
  S('balkon', 'sonntag', 'Balkonblumen', { key: 9, mode: 'major', bpm: 90, swing: 30, feel: '16',
    chords: 'I:maj9 ii:m9 iii:m7 IV:maj7 I:maj9 vi:m9 ii:m7 iv:m6', inst: 'rhodes', comp: 'synkope', voicing: 'nah',
    bass: ['upright', 'federnd'], kit: 'staub', drums: 'schlurfen',
    mel: ['kalimba', 1, 2, 'penta', ['2.3.5...3.2.....', '1.......4...5...', '2.3.6...3.......', '4.......5...2...',
      '7.8.9...8.7.....', '5.......4...7...', '6...4...5...1...', '5.......6.......']],
    atmo: ['voegel', 20], dust: 36, space: 38, pump: 18 });
  S('broetchen', 'sonntag', 'Sonntagsbrötchen', { key: 0, mode: 'major', bpm: 88, swing: 25, feel: '16',
    chords: 'I:6 vi:m9 ii:m9 V:9 iii:m7 vi:m7 ii:m7 V:13', inst: 'piano', comp: 'stakkato', voicing: 'nah',
    bass: ['upright', 'r--.r-5.o--.a---'], kit: 'staub', drums: ['x......x..x.....', '....x.......x...', 'x.x.x.x.x.x.x.x.', '................', '..o...o...o...o.'],
    mel: ['vibes', 1, 2, 'full', ['4.5.4.2...0.....', '2.......4..6....', '5.3.1...0.......', '1...4...6..5....',
      '6.4.2...1.......', '0...2...4.......', '3.5.7...8.......', '9.......6..4....']],
    atmo: ['voegel', 12], dust: 32, space: 32, pump: 20 });
  S('wolkenlos', 'sonntag', 'Wolkenlos', { key: 4, mode: 'major', bpm: 94, swing: 15, feel: '16',
    chords: 'I:maj9 V:add9 vi:m7 IV:maj9 I:maj9 V:add9 IV:maj7 iv:m6', inst: 'harp', comp: 'arpeggio', voicing: 'nah',
    bass: ['upright', 'grund'], kit: 'weich', drums: 'sanft',
    mel: ['flute', 0, 4, 'penta', ['5.......6..7....', '8.......6...4...', '7.......5...4...', '4.......3...2...',
      '5...6...7...8...', '9.......8...6...', '7...5...4.......', '5.......1.......']],
    atmo: ['voegel', 15], dust: 25, space: 45, pump: 10 });

  // ---------------- Bossa am Meer ----------------
  S('strandbar', 'bossa', 'Strandbar', { key: 0, mode: 'major', bpm: 78, swing: 5, feel: '16',
    chords: 'I:maj7 II:7 ii:m7 V:7 I:maj7 II:7 ii:m7|V:7 I:6', inst: 'guitar', comp: 'bossa', voicing: 'nah',
    bass: ['upright', 'bossa'], kit: 'kiste', drums: 'bossa',
    mel: ['flute', 1, 2, 'full', ['4..2..2...4.2...', '1..5..5...1.0...', '3..1..1...3.1...', '4..6..6...4.3...',
      '4..2..2...4.2...', '5..7..7...5.1...', '3...1...4...6...', '7.......5.......']],
    atmo: ['meer', 20], dust: 30, space: 38, pump: 0 });
  S('saudade', 'bossa', 'Saudade', { key: 9, mode: 'minor', bpm: 74, swing: 0, feel: '16',
    chords: 'i:m7 iv:m7 ii:m7b5|V:7b9 i:m6 i:m7 iv:m9 VII:9 III:maj7', inst: 'guitar', comp: 'bossa', voicing: 'nah',
    bass: ['upright', 'bossa'], kit: 'kiste', drums: 'bossa',
    mel: ['whistle', 1, 2, 'full', ['4..2..0...2.4...', '5..3..3...5.7...', '8...5...4...5...', '4.......2...0...',
      '4..6..7...6.4...', '5..4..3...0.3...', '1..3..4...6.8...', '6.......4.......']],
    atmo: ['meer', 18], dust: 34, space: 40, pump: 0 });
  S('muschel', 'bossa', 'Muschelsammler', { key: 5, mode: 'major', bpm: 80, swing: 8, feel: '16',
    chords: 'I:maj9 IV:9 iii:m7 VI:7b9 ii:m9 V:13 I:6 V:7', inst: 'guitar', comp: 'bossa', voicing: 'nah',
    bass: ['upright', 'bossa'], kit: 'kiste', drums: 'bossa',
    mel: ['marimba', 0, 2, 'penta', ['2..3..4...3.2...', '4..3..0...3.4...', '6..7..3...2.3...', '4..2..3...4.....',
      '1..2..4...5.6...', '7..4..3...1.3...', '5..2..0...2.4...', '3.......1.......']],
    atmo: ['meer', 22], dust: 28, space: 36, pump: 0 });
  S('abendbrise', 'bossa', 'Abendbrise', { key: 2, mode: 'minor', bpm: 76, swing: 6, feel: '16',
    chords: 'i:m9 iv:m9 VII:9 III:maj7 VI:maj7 ii:m7b5 V:7b9 i:m6', inst: 'guitar', comp: 'bossa', voicing: 'nah',
    bass: ['upright', 'bossa'], kit: 'kiste', drums: 'bossa',
    mel: ['piano', 0, 2, 'full', ['4..2..0...2.4...', '5..4..3...0.3...', '6..8..7...6.1...', '8.......6...4...',
      '7..5..4...2.4...', '3..5..7...5.1...', '4..3..5...4.3...', '2.......0.......']],
    atmo: ['meer', 15], dust: 32, space: 42, pump: 0 });

  // ---------------- Traumwolke ----------------
  S('schweben', 'traum', 'Schweben', { key: 4, mode: 'major', bpm: 60, swing: 0, feel: '16',
    chords: 'I:maj7s11 I:maj7s11 V:add9 V:add9 vi:m9 vi:m9 IV:maj9 IV:maj9', inst: 'strings', comp: 'halten', voicing: 'weit',
    bass: ['sub', 'lang'], kit: 'weich', drums: 'aus',
    mel: ['musicbox', 1, 4, 'penta', ['7.......5.......', '4.......3.......', '6.......8.......', '9.......6.......',
      '7.......5.......', '4.......2.......', '4.......6.......', '5.......3.......']],
    atmo: ['meer', 18], dust: 22, space: 82, pump: 0, mix: { chords: 78, melody: 62 } });
  S('sternstaub', 'traum', 'Sternstaub', { key: 10, mode: 'major', bpm: 58, swing: 0, feel: '16',
    chords: 'IV:maj9 IV:maj9 I:maj7 I:maj7 IV:maj7s11 IV:maj7s11 V:sus V:sus', inst: 'synthpad', comp: 'halten', voicing: 'weit',
    bass: ['sub', 'lang'], kit: 'weich', drums: 'aus',
    mel: ['kalimba', 1, 4, 'penta', ['4...5...7.......', '8.......7.......', '7...5...3.......', '6.......5.......',
      '4...5...7.......', '9.......7.......', '8...6...5.......', '4.......3.......']],
    atmo: ['grillen', 22], dust: 25, space: 80, pump: 0, mix: { chords: 80, melody: 64 } });
  S('mondsee', 'traum', 'Mondsee', { key: 6, mode: 'minor', bpm: 62, swing: 0, feel: '16',
    chords: 'i:m9 i:m9 VI:maj7 VI:maj7 III:maj9 III:maj9 VII:add9 VII:add9', inst: 'strings', comp: 'halten', voicing: 'weit',
    bass: ['sub', 'lang'], kit: 'weich', drums: 'sanft', mix: { drums: 42, chords: 74 },
    mel: ['harp', 1, 2, 'penta', ['0.1.3.4.5.......', '6.5.4.3.........', '1.3.5.6.8.......', '9.8.6.5.........',
      '1.3.4.6.7.......', '8.6.4.3.........', '4.5.7.9.........', '7.5.4...........']],
    atmo: ['meer', 15], dust: 24, space: 76, pump: 0 });
  S('tiefschlaf', 'traum', 'Tiefschlaf', { key: 1, mode: 'major', bpm: 56, swing: 0, feel: '16',
    chords: 'I:maj9 I:maj9 vi:m9 vi:m9 IV:maj7 IV:maj7 V:sus V:sus', inst: 'felt', comp: 'halten', voicing: 'weit',
    bass: ['sub', 'lang'], kit: 'weich', drums: 'aus',
    mel: ['vibes', 0, 4, 'penta', ['5...............', '6.......7.......', '4...............', '5.......3.......',
      '4.......5.......', '7...............', '6.......5.......', '3...............']],
    atmo: ['regen', 14], dust: 26, space: 78, pump: 0, mix: { chords: 78, melody: 58 } });

  // ---------------- Retro-Synth ----------------
  S('neonlicht', 'retro', 'Neonlicht', { key: 9, mode: 'minor', bpm: 88, swing: 4, feel: '16',
    chords: 'i:m9 VI:maj7 III:maj7 VII:6 i:m9 VI:maj7 iv:m9 V:sus', inst: 'synthpad', comp: 'puls', voicing: 'nah',
    bass: ['synth', 'achtel'], kit: 'elektro', drums: ['x.......x.....x.', '....x.......x...', 'x.x.x.x.x.x.x.x.', '................', '..x...x...x...x.'],
    mel: ['soft', 0, 1, 'penta', ['8.8.7.5...4.5...', '6.......5...3...', '8.8.7.8...9.8...', '9.......7...4...',
      '8.8.7.5...4.5...', '6...5...6...8...', '7.......6...5...', '5.......3.......']],
    atmo: ['stadt', 15], dust: 58, space: 50, pump: 35 });
  S('nachtfahrt', 'retro', 'Nachtfahrt', { key: 6, mode: 'minor', bpm: 84, swing: 0, feel: '16',
    chords: 'i:m7 i:m7 VI:maj9 VI:maj9 VII:add9 VII:add9 iv:m9 V:sus', inst: 'synthpad', comp: 'halten', voicing: 'weit',
    bass: ['808', 'r---------r-o---'], kit: 'elektro', drums: 'halbzeit',
    mel: ['vox', 1, 1, 'penta', ['5..5..4...3.....', '1.......3.......', '5..5..6...8.....', '9.......8.......',
      '4..4..5...7.....', '9.......7.......', '7..6..5...3.....', '8.......5.......']],
    atmo: ['regen', 14], dust: 55, space: 60, pump: 30 });
  S('arcade', 'retro', 'Arcade', { key: 4, mode: 'minor', bpm: 92, swing: 0, feel: '16',
    chords: 'VI:maj7 VII:6 i:m9 i:m9 VI:maj7 VII:6 v:m7 v:m7', inst: 'synthpad', comp: 'halten', voicing: 'nah',
    bass: ['808', 'r-----r---5-o---'], kit: 'elektro', drums: ['x......x..x.....', '....x.......x...', 'x.x.x.x.x.xrx.x.', '................', '..............x.'],
    mel: ['soft', 0, 1, 'penta', ['0.1.3.5.3.1.0...', '4.2.3.4.8.4.3...', '0.1.3.4.5.4.3.1.', '5.......4.......',
      '0.1.3.5.3.1.0...', '4.2.3.4.8.4.3...', '3.4.7.8.7.4.3...', '8.......7.......']],
    atmo: ['keine', 0], dust: 52, space: 45, pump: 40 });
  S('skyline', 'retro', 'Skyline', { key: 0, mode: 'dorian', bpm: 86, swing: 12, feel: '16',
    chords: 'i:m9 i:m9 IV:9 IV:9 VII:maj7 VII:maj7 v:m7 IV:13', inst: 'rhodes', comp: 'puls', voicing: 'nah',
    bass: ['synth', 'achtel'], kit: 'elektro', drums: 'halbzeit',
    mel: ['trumpet', 0, 2, 'penta', ['5.......4.3.....', '1...3...4.......', '7.......6.5.....', '3...5...8.......',
      '4.......7.......', '5...4...2.......', '3...4...7.......', '7.......6.......']],
    atmo: ['stadt', 18], dust: 56, space: 55, pump: 30 });

  // ---------------- Kaminabend ----------------
  S('wolldecke', 'kamin', 'Wolldecke', { key: 7, mode: 'major', bpm: 72, swing: 35, feel: '8',
    chords: 'I:maj7 iii:m7 vi:m9 IV:maj7 I:maj7 iii:m7 ii:m7 V:sus', inst: 'guitar', comp: 'arpeggio', voicing: 'nah',
    bass: ['upright', 'grund'], kit: 'besen', drums: 'besen',
    mel: ['whistle', 1, 2, 'penta', ['3.......5..6....', '7.......6...3...', '4.......5...7...', '8.......7...4...',
      '3.......5..6....', '7...8...7...6...', '6.......4...5...', '3.......6.......']],
    atmo: ['kamin', 20], dust: 40, space: 38, pump: 0 });
  S('schneefall', 'kamin', 'Schneefall', { key: 4, mode: 'minor', bpm: 70, swing: 30, feel: '8',
    chords: 'i:m9 i:m9 iv:m9 iv:m9 VI:maj7 VII:6 i:m9 V:7b9', inst: 'felt', comp: 'halten', voicing: 'weit',
    bass: ['upright', 'grund'], kit: 'besen', drums: 'sanft',
    mel: ['flute', 0, 2, 'full', ['4.......2.1.0...', '1...2...4.......', '5.......4.3.0...', '3...5...7.......',
      '7.6.4...2.......', '3.......8...6...', '7...6...4.......', '4.......3.......']],
    atmo: ['kamin', 18], dust: 42, space: 45, pump: 0 });
  S('huette', 'kamin', 'Berghütte', { key: 2, mode: 'major', bpm: 74, swing: 40, feel: '8',
    chords: 'I:6 IV:maj7 ii:m9 V:9 I:6 vi:m7 ii:m7 V:13', inst: 'guitar', comp: 'zweimal', voicing: 'nah',
    bass: ['upright', 'laufend'], kit: 'besen', drums: ['x.......x.......', '....o.......o...', 'x...x.x.x...x.x.', '................', '................'],
    mel: ['piano', 0, 2, 'full', ['2.4.5...7.......', '5.......2...0...', '1.3.5...9.......', '8.......6...4...',
      '7.8.9...7.......', '5.......4...2...', '3.......1...3...', '6.......4.......']],
    atmo: ['kamin', 22], dust: 38, space: 36, pump: 0 });
  S('glut', 'kamin', 'Glut', { key: 9, mode: 'minor', bpm: 68, swing: 35, feel: '8',
    chords: 'i:m9 VI:maj7 ii:m7b5 V:7 i:m9 iv:m9 VII:7 III:maj7', inst: 'piano', comp: 'halten', voicing: 'nah',
    bass: ['upright', 'laufend'], kit: 'besen', drums: 'besen',
    mel: ['guitar', 1, 2, 'penta', ['3.4.5...3.......', '6.......5...3...', '7...5...2.......', '3.......7...8...',
      '8.9.8...6.......', '7.......6...5...', '4...7...4.......', '3.......1.......']],
    atmo: ['kamin', 15], dust: 44, space: 40, pump: 0 });

  // ---------------- Kopfnicker ----------------
  S('hinterhof', 'kopfnicker', 'Hinterhof', { key: 0, mode: 'minor', bpm: 88, swing: 50, feel: '16',
    chords: 'i:m9 iv:m9 i:m9 V:7b9 i:m9 iv:m9 VI:maj7 V:7b9', inst: 'rhodes', comp: 'synkope', voicing: 'nah',
    bass: ['808', 'synkope'], kit: 'staub', drums: 'kopfnicker',
    mel: ['vox', 0, 1, 'penta', ['5.5..6.5...3....', '6.......5..2....', '5.5..6.8...7....', '8.......7..3....',
      '5.5..6.5...3....', '7.......6..5....', '6.......3..5....', '3.......2.......']],
    atmo: ['stadt', 14], dust: 55, space: 30, pump: 40, mix: { drums: 88, bass: 80 } });
  S('beton', 'kopfnicker', 'Beton', { key: 7, mode: 'minor', bpm: 90, swing: 45, feel: '16',
    chords: 'i:m9 VI:maj7 ii:m7b5 V:7b9 i:m9 VI:maj7 iv:m9 V:7b9', inst: 'piano', comp: 'stakkato', voicing: 'nah',
    bass: ['upright', 'federnd'], kit: 'kassette', drums: 'stolpern',
    mel: ['trumpet', 1, 2, 'full', ['7.......9.8.7...', '4.......2..0....', '5...3...1.......', '4.......5..3....',
      '7...8...9.......', '6.......5...4...', '5...3...2.......', '4.......3.......']],
    atmo: ['keine', 0], dust: 52, space: 28, pump: 35, mix: { drums: 86 } });
  S('plattenkiste', 'kopfnicker', 'Plattenkiste', { key: 2, mode: 'dorian', bpm: 86, swing: 48, feel: '16',
    chords: 'i:m9 IV:9 i:m9 IV:9 v:m7 VII:maj7 i:m11 IV:13', inst: 'felt', comp: 'synkope', voicing: 'nah',
    bass: ['upright', 'r--.r-.5--.r-a-.'], kit: 'staub', drums: ['x.....x...x..x..', '....x.......x..o', 'x.x.x.x.x.x.x.x.', '...o..........o.', '................'],
    mel: ['flute', 0, 2, 'penta', ['3..4..5...3.....', '6.......5..3....', '5..6..7...5.....', '8.......7..5....',
      '8...7...4.......', '7.......4...5...', '5..6..7...8.....', '6.......2.......']],
    atmo: ['regen', 10], dust: 58, space: 32, pump: 35, mix: { drums: 86 } });
  S('kopfhoerer', 'kopfnicker', 'Kopfhörer', { key: 5, mode: 'minor', bpm: 92, swing: 40, feel: '16',
    chords: 'i:m9 VI:maj9 VII:6 i:m9 i:m9 VI:maj9 iv:m9 v:m7', inst: 'rhodes', comp: 'halten', voicing: 'nah',
    bass: ['808', 'synkope'], kit: 'kassette', drums: ['x.....x...x..x..', '....x.......x...', 'x.x.xrx.x.x.x.xr', '................', '................'],
    mel: ['vibes', 0, 2, 'penta', ['3.4.5...4.3.....', '1.......0...1...', '2.3.4...2.......', '5.......3.......',
      '6.5.3...5.6.....', '8.......6...5...', '7.......6...3...', '4.......3.......']],
    atmo: ['keine', 0], dust: 50, space: 34, pump: 40, mix: { drums: 88, bass: 80 } });
  S('ubahn', 'kopfnicker', 'U-Bahn', { key: 10, mode: 'minor', bpm: 84, swing: 45, feel: '16',
    chords: 'i:m9 i:m9 VI:maj7 VII:7 i:m9 i:m9 iv:m9 V:7b9', inst: 'strings', comp: 'stakkato', voicing: 'nah',
    bass: ['808', 'grund'], kit: 'staub', drums: 'kopfnicker',
    mel: ['piano', 1, 2, 'full', ['4...4...2..0....', '1.......2...4...', '5.......4...2...', '6.......5...1...',
      '7...7...6..4....', '9.......8...7...', '5.......3...4...', '4.......5...3...']],
    atmo: ['stadt', 18], dust: 54, space: 32, pump: 38, mix: { drums: 88 } });

  // ---------------- Lernzimmer ----------------
  S('schreibtisch', 'lernen', 'Schreibtisch', { key: 0, mode: 'major', bpm: 76, swing: 20, feel: '16',
    chords: 'I:maj7 I:maj7 IV:maj7 IV:maj7 vi:m9 vi:m9 V:sus V:sus', inst: 'felt', comp: 'halten', voicing: 'weit',
    bass: ['sub', 'grund'], kit: 'weich', drums: 'sanft',
    mel: ['kalimba', 1, 4, 'penta', ['2.......3.......', '5.......1.......', '4.......2.......', '0.......1...4...',
      '2.......3.......', '5.......6.......', '3.......5.......', '1.......4.......']],
    atmo: ['regen', 10], dust: 32, space: 45, pump: 10 });
  S('bibliothek', 'lernen', 'Bibliothek', { key: 9, mode: 'minor', bpm: 72, swing: 20, feel: '16',
    chords: 'i:m9 VI:maj7 iv:m9 v:m7 i:m9 VI:maj7 iv:m9 VII:add9', inst: 'rhodes', comp: 'arpeggio', voicing: 'nah',
    bass: ['upright', 'grund'], kit: 'weich', drums: 'minimal',
    mel: ['musicbox', 1, 4, 'penta', ['5.......3...4...', '6.......5.......', '7.......6...5...', '4.......3.......',
      '8.......6...5...', '8...7...5.......', '6.......5...2...', '4.......2.......']],
    atmo: ['keine', 0], dust: 34, space: 48, pump: 5 });
  S('fokus', 'lernen', 'Fokus', { key: 5, mode: 'major', bpm: 74, swing: 15, feel: '16',
    chords: 'I:maj9 I:maj9 vi:m9 vi:m9 IV:maj7 IV:maj7 V:add9 V:add9', inst: 'piano', comp: 'halten', voicing: 'weit',
    bass: ['sub', 'lang'], kit: 'weich', drums: 'sanft',
    mel: ['marimba', 0, 2, 'penta', ['2.3.4...3.......', '1.......2.......', '4.5.6...5.......', '3.......2.......',
      '2.3.4...6.......', '5.......4.......', '1.3.4...3.......', '6.......3.......']],
    atmo: ['kamin', 10], dust: 30, space: 44, pump: 10 });
  S('tee', 'lernen', 'Teepause', { key: 4, mode: 'minor', bpm: 70, swing: 20, feel: '16',
    chords: 'i:m7 VI:maj9 III:maj7 VII:6 i:m7 VI:maj9 iv:m9 i:m9', inst: 'harp', comp: 'arpeggio', voicing: 'nah',
    bass: ['upright', 'grund'], kit: 'weich', drums: 'minimal',
    mel: ['flute', 0, 4, 'penta', ['3.......4...5...', '6.......5...3...', '4.......3...2...', '2.......4.......',
      '5.......6...8...', '9.......8...6...', '7.......6...5...', '3.......0.......']],
    atmo: ['regen', 12], dust: 32, space: 46, pump: 5 });

  var BY_ID = {};
  SONGS.forEach(function (s) { BY_ID[s.id] = s; });
  LK.SONGS = SONGS;
  LK.SONG_BY_ID = BY_ID;
})(LK);
