/* Lofi Kassette 2 – vorberechnete Klänge: Drumkits, Gitarre, Hall, Vinyl, Umgebungen */
'use strict';
var LK = window.LK || (window.LK = {});

(function (LK) {
  var M = LK.M;
  var SR = 44100;

  function mtof(m) { return 440 * Math.pow(2, (m - 69) / 12); }
  function rng(seed) { return M.seeded(seed); }
  function Biquad(type, f, q) {
    var w = 2 * Math.PI * Math.min(f, SR * 0.45) / SR, cs = Math.cos(w), sn = Math.sin(w), a = sn / (2 * q);
    var b0, b1, b2, a0 = 1 + a, a1 = -2 * cs, a2 = 1 - a;
    if (type === 'lp') { b0 = (1 - cs) / 2; b1 = 1 - cs; b2 = b0; }
    else if (type === 'hp') { b0 = (1 + cs) / 2; b1 = -(1 + cs); b2 = b0; }
    else { b0 = a; b1 = 0; b2 = -a; } // bp
    this.b0 = b0 / a0; this.b1 = b1 / a0; this.b2 = b2 / a0; this.a1 = a1 / a0; this.a2 = a2 / a0;
    this.x1 = this.x2 = this.y1 = this.y2 = 0;
  }
  Biquad.prototype.run = function (x) {
    var y = this.b0 * x + this.b1 * this.x1 + this.b2 * this.x2 - this.a1 * this.y1 - this.a2 * this.y2;
    this.x2 = this.x1; this.x1 = x; this.y2 = this.y1; this.y1 = y;
    return y;
  };
  function normalizeArr(a, peak) {
    var m = 0; for (var i = 0; i < a.length; i++) { var v = Math.abs(a[i]); if (v > m) m = v; }
    if (m > 0) { var g = peak / m; for (var j = 0; j < a.length; j++) a[j] *= g; }
    return a;
  }
  // Umgebungen auf gleiche Lautheit bringen (RMS), Spitzen begrenzen
  function normalizeRms(chans, target) {
    var s = 0, n = 0, pk = 0;
    chans.forEach(function (a) { for (var i = 0; i < a.length; i++) { s += a[i] * a[i]; var v = Math.abs(a[i]); if (v > pk) pk = v; } n += a.length; });
    var g = s > 0 ? target / Math.sqrt(s / n) : 1;
    if (pk * g > 0.95) g = 0.95 / pk;
    chans.forEach(function (a) { for (var i = 0; i < a.length; i++) a[i] *= g; });
    return chans;
  }
  function toBuffer(chans, sr) {
    var b = new AudioBuffer({ length: chans[0].length, numberOfChannels: chans.length, sampleRate: sr || SR });
    for (var c = 0; c < chans.length; c++) b.getChannelData(c).set(chans[c]);
    return b;
  }
  function makeLoop(a, fade) { // Übergang Ende→Anfang überblenden
    var n = a.length - fade, out = new Float32Array(n);
    for (var i = 0; i < n; i++) out[i] = a[i];
    for (var k = 0; k < fade; k++) { var w = k / fade; out[k] = a[k] * w + a[n + k] * (1 - w); }
    return out;
  }
  function onePole(fc) { return 1 - Math.exp(-2 * Math.PI * fc / SR); }

  // ---------- Drumkits ----------
  var KITP = {
    staub: { kick: { f0: 118, f1: 46, pd: 0.045, dec: 0.40, click: 0.22, drive: 1.8 }, snare: { tone: 188, td: 0.07, nd: 0.17, bp: 1900, q: 0.8, mix: 0.72 },
      hat: { hp: 7200, dec: 0.045, metal: 0.35 }, rim: { f: 1650, dec: 0.032 }, shaker: { f: 5200, dec: 0.07 }, lp: 6800 },
    weich: { kick: { f0: 92, f1: 44, pd: 0.06, dec: 0.34, click: 0.08, drive: 1.2 }, snare: { tone: 170, td: 0.05, nd: 0.26, bp: 3200, q: 0.45, mix: 0.9 },
      hat: { hp: 6200, dec: 0.03, metal: 0.15 }, rim: { f: 1150, dec: 0.04 }, shaker: { f: 4200, dec: 0.09 }, lp: 5200 },
    kassette: { kick: { f0: 150, f1: 50, pd: 0.035, dec: 0.46, click: 0.3, drive: 2.6 }, snare: { tone: 205, td: 0.08, nd: 0.14, bp: 2300, q: 0.9, mix: 0.62 },
      hat: { hp: 8200, dec: 0.05, metal: 0.5 }, rim: { f: 1900, dec: 0.028 }, shaker: { f: 6000, dec: 0.06 }, lp: 9500 },
    kiste: { kick: { f0: 96, f1: 58, pd: 0.03, dec: 0.24, click: 0.35, drive: 2.0 }, snare: { tone: 240, td: 0.03, nd: 0.1, bp: 1500, q: 1.2, mix: 0.8, claps: true },
      hat: { hp: 5200, dec: 0.025, metal: 0.05 }, rim: { f: 900, dec: 0.05, wood: true }, shaker: { f: 3800, dec: 0.1 }, lp: 6000 },
    // Jazz-Besen: gewischte Snare, Ride-Becken statt Hi-Hat, Cross-Stick
    besen: { kick: { f0: 84, f1: 50, pd: 0.05, dec: 0.3, click: 0.04, drive: 1.1 }, snare: { brush: true, bp: 3400, q: 0.5, nd: 0.22 },
      hat: { ride: true, dec: 0.9 }, rim: { f: 1250, dec: 0.03, wood: true }, shaker: { f: 3000, dec: 0.05 }, lp: 8000,
      len: { hat: 1.3, snare: 0.6 } },
    // 808-Stil: langer Bass-Kick, Clap, knackige Hats, offene Hat auf der Shaker-Spur
    elektro: { kick: { f0: 165, f1: 48, pd: 0.07, dec: 0.85, click: 0.12, drive: 2.3 }, snare: { tone: 0, td: 0.03, nd: 0.16, bp: 1700, q: 0.9, mix: 1, claps: true },
      hat: { hp: 9000, dec: 0.026, metal: 0.6 }, rim: { f: 2300, dec: 0.022 }, shaker: { open: true, hp: 7000, dec: 0.3, metal: 0.5 }, lp: 13000,
      len: { kick: 1.3, shaker: 0.6 } }
  };
  var DRUM_LEN = { kick: 0.7, snare: 0.5, hat: 0.2, rim: 0.2, shaker: 0.3 };

  function metalHat(a, n, r, h, hpF) {
    var hh = new Biquad('hp', hpF, 0.7), hb = new Biquad('bp', 10000, 1.2);
    var fr = [205.3, 304.4, 369.6, 522.7, 540, 800], phs = [0, 0, 0, 0, 0, 0];
    for (var i = 0; i < n; i++) {
      var t = i / SR, met = 0;
      for (var k = 0; k < 6; k++) { phs[k] += fr[k] * 1.4 / SR; met += (phs[k] % 1) < 0.5 ? 1 : -1; }
      var sig = (r() * 2 - 1) * (1 - h.metal) + hb.run(met / 6) * h.metal * 3;
      a[i] = hh.run(sig) * Math.exp(-t / h.dec) * Math.min(1, t / 0.0007);
    }
  }

  function renderDrum(kitId, id) {
    var K = KITP[kitId] || KITP.staub, len = (K.len && K.len[id]) || DRUM_LEN[id];
    var n = Math.floor(len * SR), a = new Float32Array(n);
    var r = rng(kitId.length * 131 + id.length * 17 + 7);
    var i, t;
    if (id === 'kick') {
      var p = K.kick, ph = 0, clickLp = new Biquad('lp', 3200, 0.7);
      for (i = 0; i < n; i++) {
        t = i / SR;
        var f = p.f1 + (p.f0 - p.f1) * Math.exp(-t / p.pd);
        ph += 2 * Math.PI * f / SR;
        var env = Math.exp(-t / p.dec) * Math.min(1, t / 0.0015);
        var cl = clickLp.run(r() * 2 - 1) * Math.exp(-t / 0.004) * p.click;
        var x = Math.sin(ph) * env + cl;
        a[i] = Math.tanh(x * p.drive) / Math.tanh(p.drive);
      }
    } else if (id === 'snare' && K.snare.brush) { // Besenwischer: weicher Einsatz, langes Rauschen
      var bs = K.snare, bb = new Biquad('bp', bs.bp, bs.q), bh = new Biquad('hp', 700, 0.7);
      for (i = 0; i < n; i++) {
        t = i / SR;
        var be = t < 0.018 ? t / 0.018 : Math.exp(-(t - 0.018) / bs.nd);
        var grain = 0.7 + 0.3 * Math.sin(2 * Math.PI * 38 * t);
        a[i] = bh.run(bb.run(r() * 2 - 1)) * be * grain;
      }
    } else if (id === 'snare') {
      var s = K.snare, bp = new Biquad('bp', s.bp, s.q), hp = new Biquad('hp', 180, 0.7);
      for (i = 0; i < n; i++) {
        t = i / SR;
        var tone = s.tone ? (Math.sin(2 * Math.PI * s.tone * t) + 0.5 * Math.sin(2 * Math.PI * s.tone * 1.52 * t)) * Math.exp(-t / s.td) : 0;
        var ne = Math.exp(-t / s.nd);
        if (s.claps) {
          ne = 0;
          var offs = [0, 0.011, 0.023, 0.034];
          for (var q = 0; q < 4; q++) if (t >= offs[q]) ne += Math.exp(-(t - offs[q]) / (q === 3 ? s.nd : 0.006));
        }
        var nz = bp.run(r() * 2 - 1) * 2.2 * ne;
        a[i] = hp.run(tone * (1 - s.mix) + nz * s.mix) * Math.min(1, t / 0.0008);
      }
    } else if (id === 'hat' && K.hat.ride) { // Ride-Becken: metallische Teiltöne mit Glockenton
      var rh = new Biquad('hp', 2500, 0.7), fr2 = [1.0, 1.34, 1.87, 2.41, 2.96, 3.53], base = 470, rp = [0, 0, 0, 0, 0, 0];
      for (i = 0; i < n; i++) {
        t = i / SR;
        var mm = 0;
        for (var k2 = 0; k2 < 6; k2++) { rp[k2] += base * fr2[k2] * 3.1 / SR; mm += Math.sin(2 * Math.PI * rp[k2]) * (1 - k2 * 0.1); }
        var bell = Math.sin(2 * Math.PI * 3150 * t) * Math.exp(-t / 0.35) * 0.5;
        var wash = (r() * 2 - 1) * 0.35;
        a[i] = rh.run(mm * 0.25 + wash) * Math.exp(-t / K.hat.dec) * Math.min(1, t / 0.001) + bell;
      }
    } else if (id === 'hat') {
      metalHat(a, n, r, K.hat, K.hat.hp);
    } else if (id === 'shaker' && K.shaker.open) {
      metalHat(a, n, r, K.shaker, K.shaker.hp);
    } else if (id === 'rim') {
      var rm = K.rim, rhp = new Biquad('hp', 320, 0.7);
      for (i = 0; i < n; i++) {
        t = i / SR;
        var body = Math.sin(2 * Math.PI * rm.f * t) * Math.exp(-t / rm.dec) + 0.6 * Math.sin(2 * Math.PI * rm.f * (rm.wood ? 2.71 : 0.47) * t) * Math.exp(-t / (rm.dec * 1.4));
        a[i] = rhp.run(body + (r() * 2 - 1) * Math.exp(-t / 0.002) * 0.6);
      }
    } else { // shaker
      var sh = K.shaker, sb = new Biquad('bp', sh.f, 0.9), sp = new Biquad('hp', 2500, 0.7);
      for (i = 0; i < n; i++) {
        t = i / SR;
        var e = t < 0.012 ? t / 0.012 : Math.exp(-(t - 0.012) / sh.dec);
        a[i] = sp.run(sb.run(r() * 2 - 1)) * e;
      }
    }
    var lp = new Biquad('lp', K.lp, 0.6);
    for (i = 0; i < n; i++) a[i] = lp.run(a[i]);
    var fade = Math.floor(0.01 * SR);
    for (i = 0; i < fade; i++) a[n - 1 - i] *= i / fade;
    return toBuffer([normalizeArr(a, 0.9)]);
  }

  // ---------- Gitarre (Karplus-Strong) ----------
  function renderPluck(m) {
    var f = mtof(m), N = SR / f, L = Math.floor(N - 0.5), d = N - L - 0.5;
    if (d < 0.1) { L -= 1; d += 1; }
    var C = (1 - d) / (1 + d);
    var t60 = Math.max(1.1, Math.min(4.2, 4.6 - (m - 40) * 0.07));
    var rho = Math.pow(0.001, 1 / (f * t60));
    var len = Math.floor(SR * Math.min(3.2, t60 + 0.3)), out = new Float32Array(len);
    var buf = new Float32Array(L), r = rng(m * 977 + 3), lpv = 0, pick = Math.max(1, Math.floor(L * 0.14));
    var exc = new Float32Array(L), i;
    for (i = 0; i < L; i++) { lpv += 0.45 * ((r() * 2 - 1) - lpv); exc[i] = lpv; }
    for (i = 0; i < L; i++) buf[i] = exc[i] - (i >= pick ? exc[i - pick] : 0);
    var idx = 0, ax = 0, ay = 0, tone = 0;
    for (var n = 0; n < len; n++) {
      var a = buf[idx], b = buf[idx + 1 === L ? 0 : idx + 1];
      tone += 0.35 * (a - tone);
      out[n] = tone;
      var lpx = 0.5 * (a + b) * rho;
      var y = C * lpx + ax - C * ay; ax = lpx; ay = y;
      buf[idx] = y;
      idx = idx + 1 === L ? 0 : idx + 1;
    }
    var fade = Math.floor(0.05 * SR);
    for (i = 0; i < fade; i++) out[len - 1 - i] *= i / fade;
    return toBuffer([normalizeArr(out, 0.8)]);
  }

  // ---------- Atmosphäre ----------

  function renderVinyl() {
    var n = Math.floor(7.5 * SR), fade = Math.floor(0.5 * SR), chans = [];
    for (var c = 0; c < 2; c++) {
      var a = new Float32Array(n), r = rng(4711 + c * 99), hiss = new Biquad('lp', 5200, 0.5), rum = new Biquad('lp', 70, 0.7), i;
      // nur Knistern: kein Rauschteppich, kein Rumpeln
      hiss = rum = null; i = 0;
      var ev = rng(1234);
      for (var t = 0; t < n;) {
        t += Math.floor(-Math.log(1 - ev() * 0.999) / 22 * SR);
        if (t >= n - 200) break;
        var big = ev(), amp = big > 0.98 ? 0.3 : big > 0.85 ? 0.14 : 0.06 * (0.3 + r());
        var sign = r() < 0.5 ? -1 : 1, ring = 0.0004 + r() * 0.0008, side = c === 0 ? 1 : 0.7 + r() * 0.3;
        for (var k = 0; k < 160; k++) a[t + k] += sign * amp * Math.exp(-k / SR / ring) * (k % 2 ? -0.6 : 1) * side;
      }
      var hp = new Biquad('hp', 90, 0.7);
      for (i = 0; i < n; i++) a[i] = hp.run(a[i]);
      chans.push(makeLoop(a, fade));
    }
    return toBuffer(chans);
  }

  function renderRain() {
    var n = Math.floor(9.5 * SR), fade = Math.floor(0.8 * SR), chans = [];
    for (var c = 0; c < 2; c++) {
      var a = new Float32Array(n), r = rng(9001 + c * 37);
      var lp = new Biquad('lp', 6500, 0.5), hp = new Biquad('hp', 350, 0.5);
      var b0 = 0, b1 = 0, b2 = 0;
      for (var i = 0; i < n; i++) {
        var w = r() * 2 - 1;
        b0 = 0.99765 * b0 + w * 0.099; b1 = 0.963 * b1 + w * 0.2965; b2 = 0.57 * b2 + w * 1.0527;
        var pink = (b0 + b1 + b2 + w * 0.1848) * 0.11;
        var swell = 0.75 + 0.25 * Math.sin(2 * Math.PI * i / n * 3 + c);
        a[i] = hp.run(lp.run(pink)) * 0.5 * swell;
      }
      for (var d = 0; d < n * 45 / SR; d++) { // Tropfen
        var at = Math.floor(r() * (n - 2000)), fq = 1400 + r() * 3200, am = 0.015 + r() * 0.05, dc = 0.003 + r() * 0.01;
        for (var k = 0; k < 1500; k++) a[at + k] += Math.sin(2 * Math.PI * fq * (1 + k / 3000) * k / SR) * am * Math.exp(-k / SR / dc);
      }
      chans.push(makeLoop(a, fade));
    }
    return toBuffer(chans);
  }

  // Hall-Impuls: muss exakt die Abtastrate des AudioContext haben (ConvolverNode-Vorgabe).
  // Handys laufen meist mit 48 kHz, daher wird er pro Abtastrate berechnet.

  // ---------- Umgebungen (alle als nahtlose Stereo-Schleifen) ----------
  function renderCafe() {
    var n = Math.floor(10 * SR), fade = Math.floor(0.7 * SR), chans = [];
    for (var c = 0; c < 2; c++) {
      var a = new Float32Array(n), r = rng(5150 + c * 71), room = new Biquad('lp', 900, 0.5), i;
      for (i = 0; i < n; i++) a[i] = room.run(r() * 2 - 1) * 0.08;
      for (var v = 0; v < 5; v++) { // Stimmengewirr
        var f1 = new Biquad('bp', 380 + r() * 650, 1.3), f2 = new Biquad('bp', 1250 + r() * 900, 2.2);
        var rate = 3 + r() * 3, ph = r() * 6.28, gv = 0.35 + r() * 0.65, gate = 0, target = 1, next = 0;
        for (i = 0; i < n; i++) {
          if (i >= next) { target = target ? 0 : 1; next = i + Math.floor((target ? 1 + r() * 2.5 : 0.4 + r() * 2) * SR); }
          gate += (target - gate) * 0.0006;
          var syl = Math.sin(2 * Math.PI * rate * i / SR + ph); syl = syl > 0 ? syl * syl : 0;
          var x = r() * 2 - 1;
          a[i] += (f1.run(x) * 0.9 + f2.run(x) * 0.35) * syl * gate * gv;
        }
      }
      var clinks = Math.floor(n / SR * 0.5);
      for (var k = 0; k < clinks; k++) { // Tassen und Löffel
        var at = Math.floor(r() * (n - SR)), am = 0.03 + Math.pow(r(), 2) * 0.12, fq = 2400 + r() * 2200;
        for (var j = 0; j < SR * 0.25; j++) {
          var tt = j / SR;
          a[at + j] += am * Math.exp(-tt / 0.07) * (Math.sin(2 * Math.PI * fq * tt) + 0.6 * Math.sin(2 * Math.PI * fq * 1.62 * tt) + 0.3 * Math.sin(2 * Math.PI * fq * 2.47 * tt));
        }
      }
      chans.push(makeLoop(a, fade));
    }
    return toBuffer(normalizeRms(chans, 0.06));
  }

  function renderSea() {
    var period = 8, n = Math.floor(2 * period * SR), fade = Math.floor(1.0 * SR), chans = [];
    for (var c = 0; c < 2; c++) {
      var a = new Float32Array(n + fade), r = rng(3300 + c * 5), lpv = 0, pink = 0, foam = new Biquad('hp', 2500, 0.6);
      for (var i = 0; i < a.length; i++) {
        var t = i / SR + c * 0.4, ph = (t % period) / period;
        var env = ph < 0.3 ? Math.pow(Math.sin(ph / 0.3 * Math.PI / 2), 2) : Math.exp(-(ph - 0.3) * 4.2);
        env = 0.22 + 0.78 * env;
        var w = r() * 2 - 1;
        pink = pink * 0.97 + w * 0.03;
        lpv += onePole(250 + 2600 * env * env) * (w - lpv);
        a[i] = lpv * env * 0.9 + pink * 0.8 + foam.run(w) * env * env * 0.12;
      }
      chans.push(makeLoop(a, fade));
    }
    return toBuffer(normalizeRms(chans, 0.07));
  }

  function renderBirds() {
    var n = Math.floor(12 * SR), fade = Math.floor(0.6 * SR), chans = [new Float32Array(n), new Float32Array(n)];
    var r = rng(8080), wind = [new Biquad('lp', 700, 0.5), new Biquad('lp', 700, 0.5)];
    for (var c = 0; c < 2; c++) for (var i = 0; i < n; i++) chans[c][i] = wind[c].run(r() * 2 - 1) * 0.05 * (0.7 + 0.3 * Math.sin(2 * Math.PI * i / n * 2 + c));
    var birds = [];
    for (var b = 0; b < 4; b++) birds.push({ f: 2600 + r() * 2800, pan: r(), amp: 0.06 + r() * 0.16, trill: r() < 0.4, sweep: 0.7 + r() * 0.7 });
    for (var call = 0; call < 26; call++) {
      var bd = birds[Math.floor(r() * birds.length)], at = Math.floor(r() * (n - 2 * SR)), notes = 2 + Math.floor(r() * 5);
      for (var k = 0; k < notes; k++) {
        var dur = 0.04 + r() * 0.09, len = Math.floor(dur * SR), f0 = bd.f * (0.9 + r() * 0.2), f1 = f0 * bd.sweep, ph = 0;
        for (var j = 0; j < len; j++) {
          var x = j / len, f = f0 * Math.pow(f1 / f0, x) + (bd.trill ? 300 * Math.sin(2 * Math.PI * 32 * j / SR) : 0);
          ph += 2 * Math.PI * f / SR;
          var s = Math.sin(ph) * Math.sin(Math.PI * x) * bd.amp;
          chans[0][at + j] += s * (1 - bd.pan * 0.8); chans[1][at + j] += s * (0.2 + bd.pan * 0.8);
        }
        at += len + Math.floor((0.03 + r() * 0.06) * SR);
      }
    }
    return toBuffer(normalizeRms(chans.map(function (ch) { return makeLoop(ch, fade); }), 0.045));
  }

  function renderFire() {
    var n = Math.floor(10 * SR), fade = Math.floor(0.6 * SR), chans = [];
    for (var c = 0; c < 2; c++) {
      var a = new Float32Array(n), r = rng(6464 + c * 3), rum = new Biquad('lp', 160, 0.6), hs = new Biquad('bp', 1800, 0.7);
      var flick = 0.6, ft = 0.6, i;
      for (i = 0; i < n; i++) {
        if (i % 2205 === 0) ft = 0.45 + r() * 0.55;
        flick += (ft - flick) * 0.0005;
        var w = r() * 2 - 1;
        a[i] = rum.run(w) * 0.9 * flick + hs.run(w) * 0.05 * flick;
      }
      var cr = Math.floor(n / SR * 14);
      for (var k = 0; k < cr; k++) { // Knacken
        var at = Math.floor(r() * (n - 3000)), amp = Math.pow(r(), 3) * 0.7 + 0.03, lp = new Biquad('lp', 1500 + r() * 6000, 0.7), len = 40 + Math.floor(r() * 250);
        for (var j = 0; j < len; j++) a[at + j] += lp.run(r() * 2 - 1) * amp * Math.exp(-j / (len * 0.3));
        if (r() < 0.08) for (var q = 0; q < 1300; q++) a[at + q] += Math.sin(2 * Math.PI * 260 * q / SR) * amp * 0.6 * Math.exp(-q / 300);
      }
      chans.push(makeLoop(a, fade));
    }
    return toBuffer(normalizeRms(chans, 0.06));
  }

  function renderCrickets() {
    var n = Math.floor(10 * SR), fade = Math.floor(0.5 * SR), chans = [new Float32Array(n), new Float32Array(n)];
    var r = rng(4242), air = [new Biquad('lp', 500, 0.5), new Biquad('lp', 500, 0.5)];
    for (var c = 0; c < 2; c++) for (var i = 0; i < n; i++) chans[c][i] = air[c].run(r() * 2 - 1) * 0.04;
    for (var k = 0; k < 3; k++) {
      var f = 4300 + r() * 900, period = 0.55 + r() * 0.45, amp = 0.05 + r() * 0.07, pan = r(), off = r() * period;
      for (var t0 = off; t0 < n / SR - 0.2; t0 += period * (0.95 + r() * 0.1)) {
        for (var pz = 0; pz < 3; pz++) {
          var st = Math.floor((t0 + pz * 0.024) * SR), len = Math.floor(0.013 * SR);
          for (var j = 0; j < len; j++) {
            var s = Math.sin(2 * Math.PI * f * j / SR) * Math.sin(Math.PI * j / len) * amp;
            chans[0][st + j] += s * (1 - pan * 0.8); chans[1][st + j] += s * (0.2 + pan * 0.8);
          }
        }
      }
    }
    for (var m = 0; m < n; m++) { // entfernte Laubheuschrecke
      var v = Math.sin(2 * Math.PI * 6800 * m / SR) * (0.5 + 0.5 * Math.sin(2 * Math.PI * 38 * m / SR)) * 0.012;
      chans[0][m] += v * 0.6; chans[1][m] += v;
    }
    return toBuffer(normalizeRms(chans.map(function (ch) { return makeLoop(ch, fade); }), 0.04));
  }

  function renderCity() {
    var n = Math.floor(14 * SR), fade = Math.floor(1.0 * SR), chans = [new Float32Array(n), new Float32Array(n)];
    var r = rng(1717), hum = [0, 0];
    for (var i = 0; i < n; i++) {
      var sw = 0.75 + 0.25 * Math.sin(2 * Math.PI * i / n * 2);
      for (var c = 0; c < 2; c++) { hum[c] += onePole(140) * ((r() * 2 - 1) - hum[c]); chans[c][i] = hum[c] * 2.4 * sw; }
    }
    for (var k = 0; k < 3; k++) { // vorbeifahrende Autos
      var at = Math.floor((1 + k * 4.3 + r()) * SR), len = Math.floor(3.5 * SR), bp = new Biquad('bp', 500, 0.8), dir = r() < 0.5, amp = 0.25 + r() * 0.2;
      for (var j = 0; j < len && at + j < n; j++) {
        var x = j / len, env = Math.sin(Math.PI * x);
        if (j % 256 === 0) bp = Object.assign(new Biquad('bp', 380 + 600 * env, 0.8), { x1: bp.x1, x2: bp.x2, y1: bp.y1, y2: bp.y2 });
        var s = bp.run(r() * 2 - 1) * env * env * amp, pan = dir ? x : 1 - x;
        chans[0][at + j] += s * (1 - pan); chans[1][at + j] += s * pan;
      }
    }
    return toBuffer(normalizeRms(chans.map(function (ch) { return makeLoop(ch, fade); }), 0.05));
  }

  function renderIR(rate) {
    var n = Math.floor(2.8 * rate), pre = Math.floor(0.014 * rate), chans = [];
    for (var c = 0; c < 2; c++) {
      var a = new Float32Array(n), r = rng(77 + c), lpv = 0;
      for (var i = pre; i < n; i++) {
        var t = (i - pre) / rate;
        var damp = (0.9 - Math.min(0.82, t * 0.55)) * Math.min(1, SR / rate);
        lpv += damp * ((r() * 2 - 1) - lpv);
        a[i] = lpv * Math.exp(-t / 0.62) * (t < 0.02 ? t / 0.02 : 1);
      }
      chans.push(normalizeArr(a, 0.35));
    }
    return toBuffer(chans, rate);
  }

  function renderNoise() {
    var n = SR, a = new Float32Array(n), r = rng(55);
    for (var i = 0; i < n; i++) a[i] = r() * 2 - 1;
    return toBuffer([a]);
  }


  var cache = { drums: {}, pluck: {}, ir: {}, atmo: {}, vinyl: null, noise: null };
  var ATMO_RENDER = { regen: function () { return rainNormalized(); }, cafe: renderCafe, meer: renderSea, voegel: renderBirds, kamin: renderFire, grillen: renderCrickets, stadt: renderCity };
  function rainNormalized() {
    var b = renderRain(), chans = [b.getChannelData(0).slice(), b.getChannelData(1).slice()];
    return toBuffer(normalizeRms(chans, 0.06));
  }

  LK.Sounds = {
    SR: SR, mtof: mtof, KITS: KITP,
    drum: function (kit, id) { var k = kit + ':' + id; return cache.drums[k] || (cache.drums[k] = renderDrum(kit, id)); },
    pluck: function (m) { return cache.pluck[m] || (cache.pluck[m] = renderPluck(m)); },
    ir: function (rate) { rate = Math.round(rate); return cache.ir[rate] || (cache.ir[rate] = renderIR(rate)); },
    atmo: function (type) { return ATMO_RENDER[type] ? (cache.atmo[type] || (cache.atmo[type] = ATMO_RENDER[type]())) : null; },
    vinyl: function () { return cache.vinyl || (cache.vinyl = renderVinyl()); },
    noise: function () { return cache.noise || (cache.noise = renderNoise()); },
    _cache: cache, _renderDrum: renderDrum
  };
})(LK);
