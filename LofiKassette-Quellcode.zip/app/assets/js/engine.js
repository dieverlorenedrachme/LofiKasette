/* Lofi Kassette 2 – Audio-Graph und Instrumente (ein Engine-Objekt pro AudioContext) */
'use strict';
var LK = window.LK || (window.LK = {});

(function (LK) {
  var M = LK.M, S = LK.Sounds, mtof = S.mtof;

  function driveCurve(amount) {
    var k = 1 + amount * 1.8, n = 4096, curve = new Float32Array(n), off = 0.03 * amount, base = Math.tanh(k * off);
    for (var i = 0; i < n; i++) { var x = i / (n - 1) * 2 - 1; curve[i] = (Math.tanh(k * (x + off)) - base) / k; }
    return curve;
  }
  function crushCurve(bits) {
    var n = 8192, curve = new Float32Array(n), lv = Math.pow(2, bits - 1);
    for (var i = 0; i < n; i++) { var x = i / (n - 1) * 2 - 1; curve[i] = Math.round(x * lv) / lv; }
    return curve;
  }


  var TRACK_BASE = { drums: 1.0, chords: 0.5, melody: 0.5, bass: 0.85 };
  var TREM = { rhodes: [4.6, 0.22], vibes: [5.4, 0.34] };
  var ECHO_SEND = { drums: 0.02, chords: 0.1, melody: 0.42, bass: 0 };
  var TRACK_EQ = {
    drums: [],
    chords: [['highpass', 160, 0.7], ['peaking', 330, 0.9, -4.5]],
    melody: [['highpass', 220, 0.7], ['peaking', 3200, 0.9, 1.5]],
    bass: [['highpass', 34, 0.7], ['lowpass', 2200, 0.6]]
  };

  function Engine(ctx, opts) {
    opts = opts || {};
    var c = this.ctx = ctx;
    this.live = !!opts.live;
    this.rnd = opts.seed ? M.seeded(opts.seed) : Math.random;
    this.active = [];

    this.limiter = c.createDynamicsCompressor();
    this.limiter.threshold.value = -2; this.limiter.knee.value = 0; this.limiter.ratio.value = 20;
    this.limiter.attack.value = 0.003; this.limiter.release.value = 0.12;
    this.limiter.connect(c.destination);
    this.final = c.createGain(); this.final.connect(this.limiter);
    this.comp = c.createDynamicsCompressor();
    this.comp.threshold.value = -15; this.comp.knee.value = 12; this.comp.ratio.value = 2.2;
    this.comp.attack.value = 0.02; this.comp.release.value = 0.25;
    this.comp.connect(this.final);
    this.hp = c.createBiquadFilter(); this.hp.type = 'highpass'; this.hp.frequency.value = 32; this.hp.Q.value = 0.6;
    this.hp.connect(this.comp);
    this.wobble = c.createDelay(0.2); this.wobble.delayTime.value = 0.014; this.wobble.connect(this.hp);
    this.lfos = [];
    this.wow = this._lfo(0.52, this.wobble.delayTime);
    this.flutter = this._lfo(6.1, this.wobble.delayTime);
    this.drift = this._lfo(0.11, this.wobble.delayTime);
    this.tone = c.createBiquadFilter(); this.tone.type = 'highshelf'; this.tone.frequency.value = 6500; this.tone.connect(this.wobble);
    this.lp = c.createBiquadFilter(); this.lp.type = 'lowpass'; this.lp.Q.value = 0.5; this.lp.connect(this.tone);
    this.crush = c.createWaveShaper(); this.crush.connect(this.lp);
    this.drive = c.createWaveShaper(); this.drive.oversample = '4x'; this.drive.connect(this.crush);
    this.gate = c.createGain(); this.gate.connect(this.drive);
    this.music = c.createGain(); this.music.connect(this.gate);
    this.verb = c.createConvolver(); this.verb.normalize = false;
    try { this.verb.buffer = S.ir(c.sampleRate); } catch (e) { this.verbError = e; } // ohne Hall weiter statt zu verstummen
    this.verbIn = c.createBiquadFilter(); this.verbIn.type = 'highpass'; this.verbIn.frequency.value = 380; this.verbIn.Q.value = 0.6;
    var vlp = c.createBiquadFilter(); vlp.type = 'lowpass'; vlp.frequency.value = 6500; vlp.Q.value = 0.5;
    this.verbIn.connect(vlp); vlp.connect(this.verb);
    this.verbRet = c.createGain(); this.verb.connect(this.verbRet); this.verbRet.connect(this.music);

    // Band-Echo: punktierte Achtel, jede Wiederholung dumpfer
    this.echo = c.createDelay(2.5); this.echo.delayTime.value = 0.4;
    this.echoLp = c.createBiquadFilter(); this.echoLp.type = 'lowpass'; this.echoLp.frequency.value = 2600; this.echoLp.Q.value = 0.4;
    this.echoHp = c.createBiquadFilter(); this.echoHp.type = 'highpass'; this.echoHp.frequency.value = 420;
    this.echoFb = c.createGain(); this.echoFb.gain.value = 0.35;
    this.echoRet = c.createGain(); this.echoRet.gain.value = 0;
    this.echo.connect(this.echoLp); this.echoLp.connect(this.echoHp); this.echoHp.connect(this.echoFb); this.echoFb.connect(this.echo);
    this.echoHp.connect(this.echoRet); this.echoRet.connect(this.music);

    this.pump = c.createGain(); this.pump.connect(this.music);

    this.tracks = {};
    this._track('drums', this.music, 0, 0.08);
    this._track('chords', this.pump, -0.08, 0.35);
    this._track('melody', this.pump, 0.12, 0.5);
    this._track('bass', this.music, 0, 0);

    this.atmos = c.createGain(); this.atmos.connect(this.final);
    this.vinylG = c.createGain(); this.vinylG.connect(this.atmos);
    this.envG = c.createGain(); this.envG.connect(this.atmos);
    this.vinylSrc = null; this.envSrc = null; this.envType = null; this.atmosOn = false;

    this.piano = c.createPeriodicWave(new Float32Array([0, 1, 0.42, 0.2, 0.11, 0.06, 0.035, 0.02, 0.01]), new Float32Array(9));
    this.drivePrev = -1; this.crushPrev = -1; this.pumpAmt = 0; this.lpTarget = 4000;
  }

  Engine.prototype._lfo = function (freq, target) {
    var o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.frequency.value = freq; g.gain.value = 0; o.connect(g); g.connect(target); o.start();
    this.lfos.push(o);
    return g;
  };

  Engine.prototype._track = function (name, dest, pan, send) {
    var c = this.ctx, input = c.createGain(), bus = c.createGain(), p = c.createStereoPanner(), s = c.createGain(), e = c.createGain();
    p.pan.value = pan; s.gain.value = send; e.gain.value = ECHO_SEND[name];
    var eq = TRACK_EQ[name], head = input;
    eq.forEach(function (q) {
      var f = c.createBiquadFilter(); f.type = q[0]; f.frequency.value = q[1]; f.Q.value = q[2]; if (q[3]) f.gain.value = q[3];
      head.connect(f); head = f;
    });
    head.connect(bus); bus.connect(p); p.connect(dest); bus.connect(s); s.connect(this.verbIn); bus.connect(e); e.connect(this.echo);
    var tremO = c.createOscillator(), tremG = c.createGain(); tremG.gain.value = 0;
    tremO.connect(tremG); tremG.connect(input.gain); tremO.start();
    this.lfos.push(tremO);
    this.tracks[name] = { input: input, bus: bus, tremO: tremO, tremG: tremG };
  };

  Engine.prototype.setTrem = function (track, inst) {
    var T = this.tracks[track], tr = TREM[inst] || [5, 0], t = this.ctx.currentTime;
    T.tremO.frequency.setValueAtTime(tr[0], t);
    T.tremG.gain.setValueAtTime(tr[1] / 2, t);
    T.input.gain.setValueAtTime(1 - tr[1] / 2, t);
  };

  Engine.prototype.apply = function (P, at) {
    var t = at === undefined ? this.ctx.currentTime : at, smooth = this.live ? 0.05 : 0.001;
    function set(param, v) { if (at === undefined) param.setTargetAtTime(v, t, smooth); else param.setValueAtTime(v, t); }
    var mx = P.mix, fx = P.fx, self = this, mute = P.mute;
    ['drums', 'chords', 'melody', 'bass'].forEach(function (k) {
      set(self.tracks[k].bus.gain, mute[k] ? 0 : Math.pow(mx[k] / 100, 2) * TRACK_BASE[k]);
    });
    set(this.final.gain, Math.pow(mx.master / 100, 1.5) * 1.1);
    set(this.atmos.gain, Math.pow(mx.atmos / 100, 1.2));
    set(this.vinylG.gain, Math.pow(fx.vinyl / 100, 1.5) * 1.5);
    set(this.envG.gain, mute.atmo || P.atmo.type === 'keine' ? 0 : Math.pow(P.atmo.amount / 100, 1.5) * 0.8);
    var w = fx.wobble / 100;
    set(this.wow.gain, 0.0032 * w); set(this.flutter.gain, 0.00022 * w); set(this.drift.gain, 0.0014 * w);
    // Filter: 100 = offen (18 kHz), 0 = dumpf (2,5 kHz); dazu ein Höhenregal für Wärme
    this.lpTarget = 2500 * Math.pow(7.2, fx.filter / 100);
    set(this.lp.frequency, this.lpTarget);
    set(this.tone.gain, -1.5 - (1 - fx.filter / 100) * 5);
    set(this.verbRet.gain, fx.reverb / 100 * 1.05);
    var ec = fx.echo / 100;
    set(this.echoRet.gain, ec * 0.6);
    set(this.echoFb.gain, 0.18 + ec * 0.26);
    set(this.echo.delayTime, Math.min(2.4, 60 / P.bpm * 0.75));
    var dv = Math.round(fx.drive);
    if (dv !== this.drivePrev) { this.drive.curve = driveCurve(dv / 100); this.drivePrev = dv; }
    var cr = Math.round(fx.crush);
    if (cr !== this.crushPrev) { this.crush.curve = cr > 0 ? crushCurve(Math.round(12 - cr / 100 * 8)) : null; this.crushPrev = cr; }
    this.pumpAmt = fx.pump / 100;
    this.setTrem('chords', P.chords.inst);
    this.setTrem('melody', P.melody.inst);
    if (this.atmosOn && P.atmo.type !== this.envType) this._startEnv(P.atmo.type, this.ctx.currentTime + 0.02);
  };

  // Songteile: Filter öffnen (Intro), abdunkeln (Pause), ausblenden (Outro)
  Engine.prototype.sectionFx = function (kind, t, dur) {
    var f = this.lp.frequency, target = this.lpTarget;
    if (kind === 'open') {
      f.cancelScheduledValues(t); f.setValueAtTime(Math.min(target, 900), t); f.exponentialRampToValueAtTime(target, t + dur * 0.9);
    } else if (kind === 'dip') {
      f.cancelScheduledValues(t); f.setTargetAtTime(Math.max(1400, target * 0.22), t, 0.25);
    } else if (kind === 'fade') {
      var g = this.final.gain; g.cancelScheduledValues(t); g.setValueAtTime(g.value || Math.max(0.0001, g.defaultValue), t);
      g.linearRampToValueAtTime(0, t + dur);
    } else {
      f.cancelScheduledValues(t); f.setTargetAtTime(target, t, 0.15);
    }
  };

  Engine.prototype._startEnv = function (type, t) {
    if (this.envSrc) { try { this.envSrc.stop(t + 0.3); } catch (e) { /* schon gestoppt */ } this.envSrc = null; }
    this.envType = type;
    var buf = S.atmo(type);
    if (!buf) return;
    var s = this.ctx.createBufferSource(); s.buffer = buf; s.loop = true;
    var fg = this.ctx.createGain(); fg.gain.setValueAtTime(0, t); fg.gain.linearRampToValueAtTime(1, t + 0.6);
    s.connect(fg); fg.connect(this.envG); s.start(t, (this.rnd() * buf.duration * 0.8));
    this.envSrc = s;
  };

  Engine.prototype.startAtmos = function (t, P) {
    this.stopAtmos(t);
    var c = this.ctx;
    this.vinylSrc = c.createBufferSource(); this.vinylSrc.buffer = S.vinyl(); this.vinylSrc.loop = true;
    this.vinylSrc.connect(this.vinylG); this.vinylSrc.start(t);
    this.atmosOn = true;
    this._startEnv(P.atmo.type, t);
  };
  Engine.prototype.stopAtmos = function (t) {
    [this.vinylSrc, this.envSrc].forEach(function (s) { if (s) { try { s.stop(t); } catch (e) { /* schon gestoppt */ } } });
    this.vinylSrc = this.envSrc = null; this.envType = null; this.atmosOn = false;
  };

  Engine.prototype._keep = function (nodes, end) {
    if (!this.live) return;
    var now = this.ctx.currentTime;
    if (this.active.length > 300) this.active = this.active.filter(function (v) { return v.end > now; });
    this.active.push({ nodes: nodes, end: end });
  };

  Engine.prototype.silence = function () {
    var t = this.ctx.currentTime;
    this.gate.gain.cancelScheduledValues(t);
    this.gate.gain.setTargetAtTime(0, t, 0.025);
    this.gate.gain.setTargetAtTime(1, t + 0.3, 0.01);
    this.active.forEach(function (v) {
      if (v.end > t) v.nodes.forEach(function (n) { try { n.stop(t + 0.25); } catch (e) { /* ignorieren */ } });
    });
    this.active = [];
    this.pump.gain.cancelScheduledValues(t); this.pump.gain.setValueAtTime(1, t);
    this.lp.frequency.cancelScheduledValues(t); this.lp.frequency.setTargetAtTime(this.lpTarget, t, 0.05);
    this.echoRet.gain.cancelScheduledValues(t);
    var eg = this.echoRet.gain.value; this.echoRet.gain.setValueAtTime(0, t); this.echoRet.gain.setValueAtTime(eg, t + 0.35);
  };

  Engine.prototype.pumpAt = function (t) {
    if (!this.pumpAmt) return;
    var g = this.pump.gain;
    g.setTargetAtTime(1 - this.pumpAmt * 0.6, t, 0.012);
    g.setTargetAtTime(1, t + 0.06, 0.12);
  };

  var DRUM_LVL = { kick: 1.0, snare: 0.62, hat: 0.26, rim: 0.4, shaker: 0.22 };
  var KIT_LVL = { besen: { snare: 0.5, hat: 0.2 }, elektro: { kick: 1.05, snare: 0.55, shaker: 0.2 } };
  Engine.prototype.drum = function (kit, id, t, vel, pan) {
    var c = this.ctx, s = c.createBufferSource(), g = c.createGain();
    t = Math.max(t, 0);
    s.buffer = S.drum(kit, id);
    g.gain.value = ((KIT_LVL[kit] && KIT_LVL[kit][id]) || DRUM_LVL[id]) * vel;
    s.connect(g);
    if (pan) {
      var p = c.createStereoPanner(); p.pan.value = pan; g.connect(p); p.connect(this.tracks.drums.input);
    } else g.connect(this.tracks.drums.input);
    s.start(t);
    this._keep([s], t + s.buffer.duration);
  };

  function osc(c, type, f, t) { var o = c.createOscillator(); o.type = type; o.frequency.value = f; o.start(t); return o; }

  // Klangprofile der Sample-Instrumente: Pegel, Ausklang, Anschlagshelligkeit
  var SP = {
    piano: { gain: 0.66, rel: 0.22, bright: [2200, 15000] },
    felt: { gain: 0.69, rel: 0.3, bright: [1500, 7000] },
    rhodes: { gain: 0.65, rel: 0.2, bright: [1800, 12000] },
    guitar: { gain: 0.84, rel: 0.12, bright: [2500, 9000] },
    upright: { gain: 3.2, rel: 0.07 },
    harp: { gain: 0.73, rel: 0.5, bright: [2500, 12000] },
    vibes: { gain: 0.72, rel: 0.4 },
    marimba: { gain: 0.62, rel: 0.12 },
    musicbox: { gain: 0.63, rel: 0.6 },
    kalimba: { gain: 0.64, rel: 0.3 },
    strings: { gain: 0.3, rel: 0.5, attack: 0.09 }
  };
  // Ersatzklang, solange ein Sample-Instrument noch lädt
  var FALLBACK = { harp: 'guitar', marimba: 'kalimba', strings: 'pad' };
  var SB = LK.SampleBank;

  Engine.prototype.sampleVoice = function (track, inst, m, t, dur, vel) {
    var s = SB.pick(inst, m), pr = SP[inst];
    if (!s || !pr) return false;
    var c = this.ctx, src = c.createBufferSource(), amp = c.createGain(), g = amp.gain, head = src;
    t = Math.max(t, 0);
    var rate = Math.pow(2, (m - s.m) / 12) * (1 + (this.rnd() - 0.5) * 0.0016);
    src.buffer = s.buf; src.playbackRate.value = rate;
    if (s.loop) { src.loop = true; src.loopStart = s.loop[0]; src.loopEnd = s.loop[1]; }
    if (pr.bright) { // leiser Anschlag = weicher Klang
      var lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.Q.value = 0.4;
      lp.frequency.value = pr.bright[0] + (pr.bright[1] - pr.bright[0]) * vel * vel;
      src.connect(lp); head = lp;
    }
    head.connect(amp); amp.connect(this.tracks[track].input);
    var end = t + Math.max(0.05, dur), level = pr.gain * vel;
    g.setValueAtTime(0, t); g.linearRampToValueAtTime(level, t + (pr.attack || 0.002));
    g.setTargetAtTime(0, end, pr.rel);
    var stop = end + pr.rel * 6;
    if (!s.loop) stop = Math.min(stop, t + s.buf.duration / rate + 0.01);
    src.start(t); src.stop(Math.max(stop, t + 0.06));
    this._keep([src], stop);
    return true;
  };

  Engine.prototype.voice = function (track, inst, m, t, dur, vel) {
    if (SB && SB.isSampled(inst)) {
      if (SB.has(inst) && this.sampleVoice(track, inst, m, t, dur, vel)) return;
      SB.load(inst).catch(function () { /* Ersatzklang bleibt */ });
      inst = FALLBACK[inst] || inst;
    }
    var c = this.ctx, dest = this.tracks[track].input, f = mtof(m) * (1 + (this.rnd() - 0.5) * 0.002), self = this;
    t = Math.max(t, 0);
    var amp = c.createGain(), g = amp.gain, end = t + Math.max(0.05, dur), stop, nodes = [], o, o2, lp;
    amp.connect(dest);
    g.setValueAtTime(0, t);
    switch (inst) {
      case 'rhodes': {
        var peak = 0.2 * vel, dec = Math.max(0.6, 2.4 - (m - 48) * 0.035);
        o = osc(c, 'sine', f, t);
        var mod = osc(c, 'sine', f, t), mg = c.createGain(), idx = f * (0.6 + 1.3 * vel);
        mg.gain.setValueAtTime(idx, t); mg.gain.exponentialRampToValueAtTime(Math.max(1, idx * 0.1), t + 1.4);
        mod.connect(mg); mg.connect(o.frequency);
        var tine = osc(c, 'sine', f * 7.02, t), tg = c.createGain();
        tg.gain.setValueAtTime(0.25 * vel, t); tg.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
        tine.connect(tg); tg.connect(amp); o.connect(amp);
        g.linearRampToValueAtTime(peak, t + 0.006); g.setTargetAtTime(peak * 0.25, t + 0.006, dec);
        g.setTargetAtTime(0, end, 0.12); stop = end + 0.7; nodes = [o, mod, tine];
        break;
      }
      case 'piano': {
        var pk = 0.24 * vel, pd = Math.max(0.5, 2.2 - (m - 48) * 0.03);
        o = c.createOscillator(); o.setPeriodicWave(this.piano); o.frequency.value = f; o.start(t);
        o2 = c.createOscillator(); o2.setPeriodicWave(this.piano); o2.frequency.value = f * 1.0018; o2.start(t);
        lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.Q.value = 0.3;
        lp.frequency.setValueAtTime(Math.min(16000, f * 7), t); lp.frequency.setTargetAtTime(Math.min(8000, f * 1.8), t, 0.5);
        o.connect(lp); o2.connect(lp); lp.connect(amp);
        g.linearRampToValueAtTime(pk, t + 0.004); g.setTargetAtTime(0, t + 0.004, pd);
        g.setTargetAtTime(0, end, 0.18); stop = end + 0.9; nodes = [o, o2];
        break;
      }
      case 'pad': {
        o = osc(c, 'sawtooth', f * 0.996, t); o2 = osc(c, 'sawtooth', f * 1.004, t);
        var o3 = osc(c, 'triangle', f / 2, t), g3 = c.createGain();
        g3.gain.value = 0.5;
        lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1100; lp.Q.value = 0.4;
        o.connect(lp); o2.connect(lp); o3.connect(g3); g3.connect(lp); lp.connect(amp);
        g.linearRampToValueAtTime(0.116 * vel, t + 0.45); g.setTargetAtTime(0, end, 0.45);
        stop = end + 2.5; nodes = [o, o2, o3];
        break;
      }
      case 'guitar': {
        var x = c.createBufferSource(); x.buffer = S.pluck(Math.round(m)); x.connect(amp); x.start(t);
        g.setValueAtTime(0.38 * vel, t); g.setTargetAtTime(0, end, 0.09);
        stop = Math.min(end + 0.5, t + x.buffer.duration); nodes = [x];
        break;
      }
      case 'vibes': {
        o = osc(c, 'sine', f, t); o2 = osc(c, 'sine', f * 4, t);
        var og = c.createGain();
        og.gain.setValueAtTime(0.18, t); og.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
        o.connect(amp); o2.connect(og); og.connect(amp);
        g.linearRampToValueAtTime(0.2 * vel, t + 0.003); g.setTargetAtTime(0, t + 0.003, 1.1);
        g.setTargetAtTime(0, end + 0.35, 0.2); stop = end + 1.6; nodes = [o, o2];
        break;
      }
      case 'musicbox': {
        o = osc(c, 'sine', f, t); o2 = osc(c, 'sine', f * 3, t);
        var o4 = osc(c, 'sine', f * 5.41, t), mb2 = c.createGain(), mb3 = c.createGain();
        mb2.gain.setValueAtTime(0.28, t); mb2.gain.exponentialRampToValueAtTime(0.0001, t + 0.45);
        mb3.gain.setValueAtTime(0.12, t); mb3.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
        o.connect(amp); o2.connect(mb2); mb2.connect(amp); o4.connect(mb3); mb3.connect(amp);
        g.linearRampToValueAtTime(0.17 * vel, t + 0.002); g.setTargetAtTime(0, t + 0.002, 0.65);
        g.setTargetAtTime(0, end + 0.4, 0.2); stop = end + 1.4; nodes = [o, o2, o4];
        break;
      }
      case 'flute': {
        o = osc(c, 'sine', f, t); o2 = osc(c, 'triangle', f * 2, t);
        var fg = c.createGain(); fg.gain.value = 0.06;
        var vib = osc(c, 'sine', 5.1, t), vg = c.createGain();
        vg.gain.setValueAtTime(0, t); vg.gain.linearRampToValueAtTime(f * 0.005, t + 0.35);
        vib.connect(vg); vg.connect(o.frequency); vg.connect(o2.frequency);
        var br = c.createBufferSource(); br.buffer = S.noise(); br.loop = true;
        var bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = Math.min(9000, f * 2); bp.Q.value = 1.4;
        var bg = c.createGain(); bg.gain.setValueAtTime(0, t); bg.gain.linearRampToValueAtTime(0.05 * vel, t + 0.03);
        bg.gain.setTargetAtTime(0.004 * vel, t + 0.05, 0.08); // nur Anblasgeräusch, kein Dauerrauschen bg.gain.setTargetAtTime(0, end, 0.08);
        br.connect(bp); bp.connect(bg); bg.connect(amp); br.start(t, this.rnd() * 0.5);
        o.connect(amp); o2.connect(fg); fg.connect(amp);
        g.linearRampToValueAtTime(0.19 * vel, t + 0.07); g.setTargetAtTime(0.16 * vel, t + 0.07, 0.3);
        g.setTargetAtTime(0, end, 0.09); stop = end + 0.6; nodes = [o, o2, vib, br];
        break;
      }
      case 'soft': {
        o = osc(c, 'triangle', f * 0.997, t); o2 = osc(c, 'triangle', f * 1.003, t);
        lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2400; lp.Q.value = 0.7;
        o.connect(lp); o2.connect(lp); lp.connect(amp);
        g.linearRampToValueAtTime(0.16 * vel, t + 0.025); g.setTargetAtTime(0.11 * vel, t + 0.03, 0.4);
        g.setTargetAtTime(0, end, 0.12); stop = end + 0.8; nodes = [o, o2];
        break;
      }
      case 'sub': {
        o = osc(c, 'sine', f, t); o2 = osc(c, 'sine', f * 2, t);
        var sg = c.createGain(); sg.gain.value = 0.16;
        o.connect(amp); o2.connect(sg); sg.connect(amp);
        g.linearRampToValueAtTime(0.5 * vel, t + 0.012); g.setTargetAtTime(0.38 * vel, t + 0.02, 1.2);
        g.setTargetAtTime(0, end, 0.05); stop = end + 0.4; nodes = [o, o2];
        break;
      }
      case 'upright': {
        o = osc(c, 'triangle', f, t); o2 = osc(c, 'sine', f, t);
        lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.Q.value = 0.8;
        lp.frequency.setValueAtTime(f * 7, t); lp.frequency.setTargetAtTime(f * 2.2, t, 0.15);
        o.connect(lp); o2.connect(lp); lp.connect(amp);
        g.linearRampToValueAtTime(0.55 * vel, t + 0.005); g.setTargetAtTime(0.14 * vel, t + 0.01, 0.45);
        g.setTargetAtTime(0, end, 0.06); stop = end + 0.4; nodes = [o, o2];
        break;
      }
      case 'felt': { // Filzklavier: gedämpfter Anschlag, weiches Holzklopfen
        var fk = 0.3 * vel, fd = Math.max(0.7, 2.8 - (m - 48) * 0.03);
        o = c.createOscillator(); o.setPeriodicWave(this.piano); o.frequency.value = f; o.start(t);
        o2 = c.createOscillator(); o2.setPeriodicWave(this.piano); o2.frequency.value = f * 1.0012; o2.start(t);
        lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.Q.value = 0.2;
        lp.frequency.setValueAtTime(Math.min(3200, f * 2.2 + 260), t); lp.frequency.setTargetAtTime(Math.min(1900, f * 1.3 + 180), t, 0.35);
        o.connect(lp); o2.connect(lp); lp.connect(amp);
        var th = c.createBufferSource(); th.buffer = S.noise(); var thl = c.createBiquadFilter(); thl.type = 'lowpass'; thl.frequency.value = 700;
        var thg = c.createGain(); thg.gain.setValueAtTime(0.25 * vel, t); thg.gain.exponentialRampToValueAtTime(0.0001, t + 0.03);
        th.connect(thl); thl.connect(thg); thg.connect(amp); th.start(t, this.rnd() * 0.5); th.stop(t + 0.05);
        g.linearRampToValueAtTime(fk, t + 0.009); g.setTargetAtTime(0, t + 0.009, fd);
        g.setTargetAtTime(0, end, 0.25); stop = end + 1.1; nodes = [o, o2];
        break;
      }
      case 'synthpad': { // breite Synthfläche mit langsam wanderndem Filter
        o = osc(c, 'sawtooth', f * 0.994, t); o2 = osc(c, 'sawtooth', f * 1.006, t);
        var o5 = osc(c, 'sawtooth', f, t), sub = osc(c, 'triangle', f / 2, t), sg2 = c.createGain(); sg2.gain.value = 0.4;
        lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900; lp.Q.value = 1.1;
        var lfo = osc(c, 'sine', 0.13 + this.rnd() * 0.1, t), lg = c.createGain(); lg.gain.value = 420;
        lfo.connect(lg); lg.connect(lp.frequency);
        var pn = c.createStereoPanner(); pn.pan.value = (this.rnd() - 0.5) * 0.7;
        o.connect(lp); o2.connect(lp); o5.connect(lp); sub.connect(sg2); sg2.connect(lp); lp.connect(pn); pn.connect(amp);
        var sa = Math.min(0.7, Math.max(0.012, dur * 0.35)), sr = dur < 0.6 ? 0.1 : 0.55; // kurze Pulse: schneller Einsatz, kurzer Nachklang
        g.linearRampToValueAtTime(0.094 * vel, t + sa); g.setTargetAtTime(0, end, sr);
        stop = end + sr * 5; nodes = [o, o2, o5, sub, lfo];
        break;
      }
      case 'kalimba': { // gezupfte Metallzunge
        o = osc(c, 'sine', f, t);
        var km = osc(c, 'sine', f * 7, t), kmg = c.createGain();
        kmg.gain.setValueAtTime(f * 2.2 * vel, t); kmg.gain.exponentialRampToValueAtTime(1, t + 0.06);
        km.connect(kmg); kmg.connect(o.frequency);
        o2 = osc(c, 'sine', f * 5.4, t); var k2g = c.createGain();
        k2g.gain.setValueAtTime(0.12, t); k2g.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);
        o.connect(amp); o2.connect(k2g); k2g.connect(amp);
        g.linearRampToValueAtTime(0.26 * vel, t + 0.002); g.setTargetAtTime(0, t + 0.002, Math.max(0.25, 0.7 - (m - 60) * 0.01));
        g.setTargetAtTime(0, end + 0.3, 0.2); stop = Math.min(end + 1.4, t + 2.4); nodes = [o, km, o2];
        break;
      }
      case 'vox': { // gesungener Vokal ("uu", "aa", "oo"), wie ein Vocal-Chop
        var VOW = [[320, 800, 2300], [730, 1090, 2440], [480, 950, 2500], [400, 1650, 2600]], vw = VOW[Math.floor(this.rnd() * VOW.length)];
        o = c.createOscillator(); o.type = 'sawtooth';
        o.frequency.setValueAtTime(f * 0.965, t); o.frequency.setTargetAtTime(f, t, 0.035); o.start(t);
        var vv = osc(c, 'sine', 5.3, t), vvg = c.createGain(); vvg.gain.setValueAtTime(0, t); vvg.gain.linearRampToValueAtTime(f * 0.007, t + 0.3);
        vv.connect(vvg); vvg.connect(o.frequency);
        [[vw[0], 7, 1], [vw[1], 9, 0.55], [vw[2], 11, 0.3]].forEach(function (fm) {
          var bpf = c.createBiquadFilter(); bpf.type = 'bandpass'; bpf.frequency.value = fm[0]; bpf.Q.value = fm[1];
          var fg2 = c.createGain(); fg2.gain.value = fm[2]; o.connect(bpf); bpf.connect(fg2); fg2.connect(amp);
        });
        g.linearRampToValueAtTime(0.76 * vel, t + 0.05); g.setTargetAtTime(0.62 * vel, t + 0.06, 0.3);
        g.setTargetAtTime(0, end, 0.12); stop = end + 0.7; nodes = [o, vv];
        break;
      }
      case 'trumpet': { // gedämpfte Trompete (Harmon-Dämpfer)
        o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(f * 0.985, t); o.frequency.setTargetAtTime(f, t, 0.03); o.start(t);
        var tv = osc(c, 'sine', 5.6, t), tvg = c.createGain(); tvg.gain.setValueAtTime(0, t); tvg.gain.linearRampToValueAtTime(f * 0.006, t + 0.35);
        tv.connect(tvg); tvg.connect(o.frequency);
        lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.Q.value = 1.5;
        lp.frequency.setValueAtTime(f * 1.4, t); lp.frequency.linearRampToValueAtTime(f * 5, t + 0.06); lp.frequency.setTargetAtTime(f * 3.2, t + 0.06, 0.25);
        var mute = c.createBiquadFilter(); mute.type = 'peaking'; mute.frequency.value = 1650; mute.Q.value = 2.2; mute.gain.value = 9;
        var thp = c.createBiquadFilter(); thp.type = 'highpass'; thp.frequency.value = 420;
        o.connect(lp); lp.connect(mute); mute.connect(thp); thp.connect(amp);
        g.linearRampToValueAtTime(0.21 * vel, t + 0.04); g.setTargetAtTime(0.17 * vel, t + 0.05, 0.3);
        g.setTargetAtTime(0, end, 0.08); stop = end + 0.5; nodes = [o, tv];
        break;
      }
      case 'whistle': { // Pfeifen mit Luft und Vibrato
        o = c.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(f * 0.95, t); o.frequency.setTargetAtTime(f, t, 0.04); o.start(t);
        var wv = osc(c, 'sine', 6.1, t), wvg = c.createGain(); wvg.gain.setValueAtTime(0, t); wvg.gain.linearRampToValueAtTime(f * 0.012, t + 0.25);
        wv.connect(wvg); wvg.connect(o.frequency);
        var wn = c.createBufferSource(); wn.buffer = S.noise(); wn.loop = true;
        var wb = c.createBiquadFilter(); wb.type = 'bandpass'; wb.frequency.value = Math.min(9000, f); wb.Q.value = 5;
        var wg = c.createGain(); wg.gain.setValueAtTime(0.04 * vel, t); wg.gain.setTargetAtTime(0.012 * vel, t + 0.05, 0.1);
        wn.connect(wb); wb.connect(wg); wg.connect(amp); wn.start(t, this.rnd() * 0.5);
        o.connect(amp);
        g.linearRampToValueAtTime(0.2 * vel, t + 0.03); g.setTargetAtTime(0.17 * vel, t + 0.04, 0.4);
        g.setTargetAtTime(0, end, 0.07); stop = end + 0.4; nodes = [o, wv, wn];
        break;
      }
      case '808': { // tiefer Bass mit Tonhöhen-Rutsch; Obertöne, damit man ihn auch auf dem Handylautsprecher hört
        o = c.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(f * 1.6, t); o.frequency.exponentialRampToValueAtTime(f, t + 0.05); o.start(t);
        o2 = osc(c, 'sine', f * 2, t); var o6 = osc(c, 'sine', f * 3, t), h2g = c.createGain(), h3g = c.createGain();
        h2g.gain.value = 0.3; h3g.gain.value = 0.1;
        o.connect(amp); o2.connect(h2g); h2g.connect(amp); o6.connect(h3g); h3g.connect(amp);
        g.linearRampToValueAtTime(0.62 * vel, t + 0.004); g.setTargetAtTime(0.44 * vel, t + 0.02, 0.8);
        g.setTargetAtTime(0, end, 0.07); stop = end + 0.4; nodes = [o, o2, o6];
        break;
      }
      default: { // Synthbass
        o = osc(c, 'sawtooth', f, t); o2 = osc(c, 'sine', f, t);
        lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.Q.value = 3;
        lp.frequency.setValueAtTime(700, t); lp.frequency.setTargetAtTime(220, t, 0.16);
        var og2 = c.createGain(); og2.gain.value = 0.35;
        o.connect(og2); og2.connect(lp); o2.connect(lp); lp.connect(amp);
        g.linearRampToValueAtTime(0.5 * vel, t + 0.008); g.setTargetAtTime(0.36 * vel, t + 0.02, 0.5);
        g.setTargetAtTime(0, end, 0.06); stop = end + 0.4; nodes = [o, o2];
      }
    }
    nodes.forEach(function (n) { n.stop(stop); });
    this._keep(nodes, stop);
  };

  Engine.prototype.dispose = function () {
    var t = this.ctx.currentTime;
    this.stopAtmos(t);
    this.lfos.forEach(function (o) { try { o.stop(); } catch (e) { /* ignorieren */ } });
    try { this.limiter.disconnect(); } catch (e) { /* ignorieren */ }
  };

  LK.Engine = Engine;
})(LK);
