#!/usr/bin/env bash
# Lädt die offiziellen Android-Werkzeuge (einmalig, braucht Internet) – wie bei PixelGroove+.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p tools
curl -fL -o tools/ecj.jar https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.38.0/ecj-3.38.0.jar
curl -fL -o tools/buildtools.zip https://dl.google.com/android/repository/build-tools_r35_linux.zip
curl -fL -o tools/platform.zip https://dl.google.com/android/repository/platform-35_r02.zip
python3 - <<'PY'
import zipfile, pathlib
for name in ['buildtools', 'platform']:
    with zipfile.ZipFile('tools/' + name + '.zip') as z:
        z.extractall('tools/' + name)
for p in pathlib.Path('tools/buildtools/android-15').iterdir():
    if p.is_file() and '.' not in p.name:
        p.chmod(0o755)
PY
