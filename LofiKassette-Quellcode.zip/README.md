# Lofi Kassette 3.0

Eine Android-App, mit der du lokal und ohne Internet Lofi-Musik machst – auch ohne Vorkenntnisse:
Stimmung antippen, einzelne Spuren austauschen, Klang mit drei Reglern formen, fertig. Wer tüfteln
will, setzt im Feinschliff jede Note selbst. Fertige Tracks landen als WAV in `Musik/LofiKassette`
und tauchen damit in jeder Musik-App auf.

- Paket: `de.lofikassette.app`, Version 2.0 (versionCode 3)
- Android 10 oder neuer (minSdk 29), targetSdk 34, nur Hochformat
- Keine Berechtigungen, kein Internet, kein Konto, keine Werbung

## Installation auf dem OnePlus

1. `LofiKassette-3.0.apk` aufs Handy kopieren (oder direkt herunterladen).
2. Antippen. Beim ersten Mal fragt Android, ob die Datei-App „unbekannte Apps installieren“ darf – erlauben.
3. Play Protect kann warnen, weil die App nicht aus dem Play Store kommt: „Trotzdem installieren“.

Version 3.0 installiert sich direkt über 1.x und 2.0 (gleicher Schlüssel); gespeicherte Tracks bleiben
erhalten und werden automatisch ins neue Format übernommen.

## Bedienung

Drei Reiter: **Studio** für alle, **Feinschliff** für Tüftler, **Projekt** für Speichern und Dateien.

**Studio**

- **Stimmung**: neun Stile, jeder mit eigenem Tempo, Rhythmus, eigenen Instrumenten, Harmonien und
  Umgebungsgeräusch. Antippen lädt eine Grundmusik dieser Stimmung und spielt sie sofort ab.
- **Grundmusiken**: 40 handkomponierte Stücke (4–5 je Stimmung) mit eigener Melodie, Akkordfolge,
  eigenem Groove und eigener Basslinie. Sie erscheinen unter den Stimmungskarten zum direkten Antippen.

  | Stimmung | Charakter |
  |---|---|
  | Regennacht | langsam, Moll, Filzklavier, Spieluhr, Regen |
  | Jazz-Café | Achtel-Swing, E-Piano, laufender Kontrabass, Besen, gedämpfte Trompete, Café |
  | Morgensonne | hell, Dur, Pfeifen, Kalimba, Vögel |
  | Bossa am Meer | Bossa-Gitarre, Shaker und Cross-Stick, Flöte, Meeresrauschen |
  | Traumwolke | sehr langsam, meist ohne Beat, schwebende Flächen, lange Akkorde, viel Hall |
  | Retro-Synth | 80er-Synthflächen im Puls, Synthbass, 808-Drums, stark leierndes Band, Stadt |
  | Kaminabend | Gitarren-Arpeggios, Besen, Pfeifen, Kaminfeuer |
  | Kopfnicker | schwerer Boom-Bap, 808-Bass, Vocal-Chops („Stimme“), rau und staubig |
  | Lernzimmer | ruhig, gleichmäßig, lange Akkorde, sparsame Melodie |

- **Deine Spuren**: Beat, Akkorde, Bass, Melodie, Umgebung. **Anders** tauscht nur diese eine Spur
  aus – meist mit komponiertem Material anderer Grundmusiken derselben Stimmung oder einer Abwandlung;
  neue Akkorde passen die Melodie automatisch an, der Schalter blendet sie aus, Antippen der Zeile
  öffnet Instrumentwahl und Lautstärke.
- **Klang**: Tempo, **Lofi** (sauber ↔ staubig: steuert Filter, Band-Leiern, Sättigung, Vinyl und
  Bitcrusher gemeinsam), **Raum** (nah ↔ weit: Hall und Echo) und **Farbe** (Hell, Dunkel, Jazzig).
- **Ablauf**: *Ganzer Song* spielt Intro, Teil A, eine Pause und Teil B mit Variationen, *Schleife*
  wiederholt einfach. Das Kassettenetikett zeigt, welcher Teil gerade läuft.
- **Als Musik speichern**: Länge in Minuten wählen (ca. 1–5), optional mit Intro und Outro.
- **Neu würfeln** (oben) lädt eine andere Grundmusik der aktuellen Stimmung, **Rückgängig** (links)
  nimmt bis zu 40 Schritte zurück. Alles wird automatisch gespeichert.

**Feinschliff**

- **Beat**: 16er-Raster für Kick, Snare, Hi-Hat, Rim und Shaker (tippen = Schlag, zweimal = leise,
  dreimal = aus, wischen zeichnet). Elf Muster, sechs Kits (u. a. Besen und Elektro), Groove, Fill.
- **Akkorde**: ein oder zwei Akkorde pro Takt, Stufe, ♭-Stufen (z. B. ♭VII, ♭VI), 17 Klangfarben,
  über 30 fertige Folgen, sechs Instrumente, sieben Rhythmen, drei Lagen, Bass mit sieben Spielweisen.
- **Melodie**: Notenraster, zehn Instrumente, Lage, Notenlänge, Pentatonik oder ganze Tonleiter.
- **Klang**: Tempo, Swing auf Sechzehnteln oder Achteln, Grundton, Dur/Moll/Dorisch, 4 oder 8 Takte,
  Umgebung (Regen, Café, Meer, Vögel, Kaminfeuer, Sommernacht, Stadt), Vinyl, Filter, Band-Leiern,
  Sättigung, Bitcrusher, Hall, Echo, Pumpen und Mischpult.

Speicherorte: WAV-Dateien in `Musik/LofiKassette`, Projektdateien (`.lofi.json`) in `Download/LofiKassette`.
Beim Verlassen der App stoppt die Wiedergabe; während der Wiedergabe bleibt der Bildschirm an.

## Aufbau

```
app/
  AndroidManifest.xml            Manifest (keine Berechtigungen)
  src/de/lofikassette/app/       Android-Hülle in Java
    MainActivity.java            WebView, Speichern über MediaStore, Dateiauswahl, Zurück-Taste
    Bridge.java                  Verbindung Oberfläche <-> Android (prompt-Brücke, Dateiauswahl)
    BackCallback.java            Auswertung der Zurück-Taste
  res/                           Adaptives App-Icon (Kassette), inkl. einfarbiger Variante
  assets/                        Die eigentliche App, läuft komplett lokal
    index.html, css/app.css      Oberfläche
    css/font.css                 Schrift Lora Italic (eingebettet, SIL OFL, siehe licenses/)
    js/music.js                  Musiktheorie, Projektformat, Stil-Rezepte, Generatoren, Migration
    js/songs.js                  Die 40 Grundmusiken (Akkorde, Melodie, Groove, Bass, Klang)
    js/sounds.js                 Vorberechnete Klänge: Drumkits, Hall, Vinyl, Umgebungen
    js/samplebank.js             Lädt Instrumenten-Samples bei Bedarf und dekodiert sie
    js/samples/*.js              11 Sample-Instrumente (Opus, Base64), erzeugt von make_samples.py
    js/engine.js                 Audio-Graph, Spur-EQ, Sample-Stimmen und Synthesizer
    js/sequencer.js              Song-Ablauf, Live-Wiedergabe, Vorhören, WAV-Export
    js/ui.js                     Studio, Feinschliff, Projekt, Speichern, Rückgängig, Android-Brücke
test/                            Browser-Tests (Playwright), u. a. Audio-Pegel, UI, Android-Brücke
offline-build/                   Build-Werkzeuge ohne Android-SDK (siehe unten)
build.sh, setup-tools.sh         Offizieller Build mit den Android-Werkzeugen
lofikassette-development.p12     Signaturschlüssel (Passwort: android, Alias: lofikassette)
```

Alle Klänge sind selbst erzeugt, es gibt keine fremden Aufnahmen. Klavier, Filzklavier, Rhodes,
Nylongitarre, Kontrabass, Harfe, Vibraphon, Marimba, Spieluhr, Kalimba und Streicher werden vorab von
`offline-build/make_samples.py` aus physikalisch inspirierten Modellen berechnet (Saiten-Inharmonizität,
Hammer, Resonanzboden, Tonabnehmer, Karplus-Strong, Modalsynthese) und als Opus-Samples mitgeliefert;
Synthesizer, Flöte, Trompete, Stimme und Drums entstehen live bzw. beim Start. Die Java-Hülle stellt nur
die WebView bereit und schreibt Dateien über den MediaStore; dafür braucht Android ab Version 10 keine
Speicherberechtigung.

## Bauen

### Weg A: offizielle Android-Werkzeuge (empfohlen)

Wie bei PixelGroove+: Linux, JDK 17+, Python 3, curl.

```
./setup-tools.sh     # lädt einmalig build-tools 35, android.jar 35 und ecj
./build.sh           # -> deliverables/LofiKassette-2.0.apk, inkl. apksigner verify
```

### Weg B: ohne SDK und ohne Internet (so wurde die mitgelieferte APK gebaut)

In der Umgebung, in der die App entstanden ist, gab es weder Internet noch Android-SDK. Deshalb liegt
eine eigene, schlanke Werkzeugkette bei. Voraussetzungen: JDK 17+ und Python 3 mit `cryptography`
(für das Icon-Skript zusätzlich Pillow).

```
./offline-build/build-offline.sh
```

Was dabei passiert:

1. `javac` kompiliert die Java-Hülle gegen `offline-build/android-stubs` (nur die genutzten APIs).
2. `dexgen.py` übersetzt den Java-Bytecode in eine DEX-Datei (Format 035).
3. `dexcheck.py` liest die DEX-Datei unabhängig ein, prüft Struktur, Prüfsummen und Sortierregeln
   und verifiziert jeden Befehl mit einer Typprüfung nach dem Vorbild des ART-Verifiers.
4. `apkbuild.py` erzeugt Binär-Manifest, `resources.arsc`, ausgerichtetes ZIP und die
   APK-Signatur v2.
5. `apkcheck.py` prüft die fertige APK: ZIP-Struktur, Ausrichtung, Signatur (kryptografisch und per
   Inhalts-Digest), Manifest, Ressourcen und Assets.

Grenzen: `dexgen.py` ist bewusst klein und unterstützt nur einfache Java-Konstrukte (keine Lambdas,
kein `switch`, kein `synchronized`, keine `boolean[]`). Nicht unterstützte Konstrukte brechen mit einer
klaren Meldung ab. Für größere Änderungen an der Java-Hülle Weg A verwenden.

`offline-build/make_icons.py` erzeugt die Icon-Ebenen neu, `offline-build/make_samples.py` die
Instrumenten-Samples (braucht numpy, scipy und ffmpeg mit libopus; die fertigen Samples liegen bei,
für einen normalen Build ist das nicht nötig).

### Updates

Eine neue Version installiert sich nur über die alte, wenn sie mit **demselben Schlüssel** signiert ist
und einen höheren `versionCode` hat. Also `lofikassette-development.p12` aufbewahren und in
`app/AndroidManifest.xml` `versionCode`/`versionName` erhöhen. Der Schlüssel ist ein
Entwicklungsschlüssel mit bekanntem Passwort – für eine Veröffentlichung einen eigenen erzeugen.

## Tests

Die Tests laufen mit Playwright/Chromium gegen die Web-Oberfläche:

```
npm install playwright && npx playwright install chromium
node test/ui.js          # alle Ansichten ohne Fehler, Bildschirmfotos in shots/
node test/ui-test.js     # Ablauf wie ein neuer Nutzer (41 Prüfungen) inkl. Grundmusiken, Export, Migration
node test/songs-check.js # alle Grundmusiken: gültig, jeder betonte Melodieton passt zum Akkord
node test/clarity.js songs:0:8   # Rauschabstand, Grundrauschen, Höhen, Mulm (Gruppen à 8 Stücke)
node test/audio.js       # Live-Wiedergabe, Rendering aller Vorlagen und Zufallstracks, Pegel/NaN
node test/samplerate.js  # Live-Ton bei 44,1 / 48 / 96 kHz (Handys laufen meist mit 48 kHz)
node test/bridge.js      # simuliert die Java-Seite: Brücke, Zurück-Taste, WAV bytegenau, Projektdatei
node test/engine-test.js # Engine-Rendering der Vorlagen und Zufallstracks
node test/styles.js      # alle neun Stimmungen rendern und vermessen (Pegel, Helligkeit, Dichte)
node test/balance.js     # Pegel von Vinyl und allen Umgebungen im Verhältnis zur Musik
```

## Änderungen

- **3.0**: Klarer Klang und echte Vielfalt.
  - 40 handkomponierte Grundmusiken statt Zufallsmelodien; *Anders* schöpft aus diesem Material.
  - 11 neue Sample-Instrumente (Klavier, Filzklavier, Rhodes, Nylongitarre, Kontrabass, Harfe,
    Vibraphon, Marimba, Spieluhr, Kalimba, Streicher), auf unter 1 Cent genau gestimmt und im Pegel
    abgeglichen.
  - Deutlich weniger Rauschen: Vinyl nur noch als Knistern, leisere Umgebungen, Hall und Echo gefiltert;
    Rauschabstand im Mittel von 24 auf rund 46 dB.
  - Klarer Mix: EQ pro Spur gegen Mulm, linke Hand eine Oktave höher, sanftere Sättigung, kein
    Bitcrusher mehr über den Lofi-Regler, Filter bis zur Reglermitte offen.
  - Eigene Basslinien, Trommelwirbel, Melodien passen sich bei Akkord- und Farbwechsel automatisch an.
- **2.0**: Neu gedacht für Einsteiger und für mehr klangliche Vielfalt.
  - Neue Startseite *Studio*: Stimmung wählen, Spuren mit *Anders* austauschen, drei verständliche
    Regler, Song oder Schleife, Export in Minuten. Die bisherigen Editoren sind im *Feinschliff*.
  - Neun Stil-Rezepte statt eines gemeinsamen Zufallspools; jede Stimmung bringt eigene Instrumente,
    Rhythmen, Harmonien, Tempi, Effekte und Umgebungsgeräusche mit.
  - Neue Klänge: Filzklavier, Synthfläche, Kalimba, Stimme (Vocal-Chop), gedämpfte Trompete, Pfeifen,
    808-Bass, Drumkits *Besen* (Ride, gewischte Snare) und *Elektro* (808, Clap, offene Hi-Hat).
  - Sechs neue Umgebungen: Café, Meer, Vögel, Kaminfeuer, Sommernacht, Stadt; dazu Band-Echo.
  - Harmonie: zwei Akkorde pro Takt, ♭-Stufen, Dorisch, neue Klangfarben, Akkorde, die über mehrere
    Takte ausklingen, drei Lagen, neue Begleit- und Bassrhythmen (Bossa, Puls, Achtel, Lang).
  - Songs entwickeln sich: Intro, Teil A, Pause, Teil B, kleine Variationen bei jeder Wiederholung.
  - Alte Projekte werden automatisch übernommen (Regen → Umgebung, Bass-Schalter → Stummschaltung).
- **1.1**: Behebt fehlenden Ton auf Handys. Der Hall-Impuls wurde mit 44,1 kHz berechnet, Handys
  betreiben Audio aber meist mit 48 kHz; der Browser verweigert dann den Hall und die Engine startete
  nicht. Der Impuls wird jetzt passend zur Geräte-Abtastrate erzeugt. Zusätzlich zeigt die App
  Startprobleme als Hinweis an, statt stumm zu bleiben, und startet angehaltenes Audio beim nächsten
  Antippen neu.
- **1.0**: Erste Version.

## Lizenzen

Die eingebettete Schrift Lora Italic steht unter der SIL Open Font License 1.1
(`app/assets/licenses/OFL-Lora.txt`). Der übrige Code gehört dir.
