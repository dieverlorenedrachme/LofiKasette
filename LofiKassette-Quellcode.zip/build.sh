#!/usr/bin/env bash
# Offizieller Build mit aapt2, d8, zipalign und apksigner. Vorher einmal: ./setup-tools.sh
# (Ohne Internet/SDK geht es alternativ mit offline-build/build-offline.sh.)
set -euo pipefail
cd "$(dirname "$0")"
BT="${ANDROID_BUILD_TOOLS:-tools/buildtools/android-15}"
AJ="${ANDROID_JAR:-tools/platform/android-35/android.jar}"
ECJ="${ECJ_JAR:-tools/ecj.jar}"
OUT="deliverables/LofiKassette-3.0.apk"
chmod u+x "$BT/aapt2" "$BT/d8" "$BT/zipalign" "$BT/apksigner"
rm -rf build && mkdir -p build/classes build/dex deliverables

java -jar "$ECJ" -source 8 -target 8 -nowarn -proc:none -encoding UTF-8 -classpath "$AJ" -d build/classes app/src/de/lofikassette/app/*.java
"$BT/aapt2" compile --dir app/res -o build/resources.zip
"$BT/aapt2" link -o build/base.apk -I "$AJ" --manifest app/AndroidManifest.xml -A app/assets build/resources.zip
python3 - <<'PY'
import zipfile, pathlib
with zipfile.ZipFile('build/classes.jar', 'w') as z:
    for p in pathlib.Path('build/classes').rglob('*.class'):
        z.write(p, str(p.relative_to('build/classes')))
PY
"$BT/d8" --min-api 29 --lib "$AJ" --output build/dex build/classes.jar
python3 - <<'PY'
import zipfile
with zipfile.ZipFile('build/base.apk', 'a', zipfile.ZIP_DEFLATED) as z:
    z.write('build/dex/classes.dex', 'classes.dex')
PY
"$BT/zipalign" -f 4 build/base.apk build/aligned.apk
"$BT/apksigner" sign --ks lofikassette-development.p12 --ks-type PKCS12 --ks-key-alias lofikassette \
  --ks-pass pass:android --key-pass pass:android --out "$OUT" build/aligned.apk
"$BT/apksigner" verify --verbose "$OUT"
"$BT/aapt2" dump badging "$OUT"
