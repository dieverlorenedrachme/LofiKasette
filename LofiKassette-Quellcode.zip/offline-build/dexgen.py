#!/usr/bin/env python3
"""
dexgen – übersetzt Java-Class-Dateien in eine Android-DEX-Datei (Version 035),
ohne Android-SDK. Gedacht für kleine, einfache Klassen (wie die WebView-Hülle
dieser App). Nicht unterstützte Konstrukte (Lambdas, switch, synchronized,
mehrdimensionale Arrays, boolean[] ...) brechen mit einer klaren Meldung ab.

Registerlayout je Methode:  v0..v3 Hilfsregister | Operandenstapel | lokale Variablen | Parameter
"""
import hashlib
import struct
import sys
import zlib

from classfile import ClassFile, decode, parse_method_desc, kind_of, words

NS = 4  # Hilfsregister

ACC_PUBLIC, ACC_PRIVATE, ACC_STATIC, ACC_SYNCHRONIZED = 0x1, 0x2, 0x8, 0x20
ACC_NATIVE, ACC_ABSTRACT, ACC_CONSTRUCTOR = 0x100, 0x400, 0x10000


class DexError(Exception):
    pass


def cdesc(internal):
    """Interner Klassenname -> Typdeskriptor"""
    return internal if internal.startswith('[') else 'L' + internal + ';'


def shorty_char(t):
    return 'L' if t[0] in 'L[' else t[0]


def proto_key(desc):
    params, ret = parse_method_desc(desc)
    shorty = shorty_char(ret) + ''.join(shorty_char(p) for p in params)
    return (shorty, ret, tuple(params))


MOVE = {'n': (0x01, 0x02, 0x03), 'w': (0x04, 0x05, 0x06), 'o': (0x07, 0x08, 0x09)}
MOVE_RESULT = {'n': 0x0a, 'w': 0x0b, 'o': 0x0c}
RETURN = {'n': 0x0f, 'w': 0x10, 'o': 0x11}


def fam(kind):
    if kind in ('J', 'D'):
        return 'w'
    if kind in ('I', 'F'):
        return 'n'
    return 'o'


def field_variant(t):
    """Offset innerhalb der iget/sget-Familie"""
    c = t[0]
    return {'I': 0, 'F': 0, 'J': 1, 'D': 1, 'L': 2, '[': 2, 'Z': 3, 'B': 4, 'C': 5, 'S': 6}[c]


ARRAY_GET = {0x2e: (0x44, 'I'), 0x2f: (0x45, 'J'), 0x30: (0x44, 'F'), 0x31: (0x45, 'D'),
             0x32: (0x46, 'A'), 0x33: (0x48, 'I'), 0x34: (0x49, 'I'), 0x35: (0x4a, 'I')}
ARRAY_PUT = {0x4f: (0x4b, 'I'), 0x50: (0x4c, 'J'), 0x51: (0x4b, 'F'), 0x52: (0x4c, 'D'),
             0x53: (0x4d, 'A'), 0x54: (0x4f, 'I'), 0x55: (0x50, 'I'), 0x56: (0x51, 'I')}
# JVM-Binäroperation -> (Dalvik-Opcode 23x, Art)
BINOP = {}
for i, name in enumerate(['add', 'sub', 'mul', 'div', 'rem']):
    BINOP[0x60 + 4 * i] = (0x90 + i, 'I')
    BINOP[0x61 + 4 * i] = (0x9b + i, 'J')
    BINOP[0x62 + 4 * i] = (0xa6 + i, 'F')
    BINOP[0x63 + 4 * i] = (0xab + i, 'D')
BINOP.update({0x78: (0x98, 'I'), 0x7a: (0x99, 'I'), 0x7c: (0x9a, 'I'),
              0x7e: (0x95, 'I'), 0x80: (0x96, 'I'), 0x82: (0x97, 'I'),
              0x7f: (0xa0, 'J'), 0x81: (0xa1, 'J'), 0x83: (0xa2, 'J')})
LSHIFT = {0x79: 0xa3, 0x7b: 0xa4, 0x7d: 0xa5}
NEG = {0x74: (0x7b, 'I'), 0x75: (0x7d, 'J'), 0x76: (0x7f, 'F'), 0x77: (0x80, 'D')}
CONV = {0x85: (0x81, 'I', 'J'), 0x86: (0x82, 'I', 'F'), 0x87: (0x83, 'I', 'D'),
        0x88: (0x84, 'J', 'I'), 0x89: (0x85, 'J', 'F'), 0x8a: (0x86, 'J', 'D'),
        0x8b: (0x87, 'F', 'I'), 0x8c: (0x88, 'F', 'J'), 0x8d: (0x89, 'F', 'D'),
        0x8e: (0x8a, 'D', 'I'), 0x8f: (0x8b, 'D', 'J'), 0x90: (0x8c, 'D', 'F'),
        0x91: (0x8d, 'I', 'I'), 0x92: (0x8e, 'I', 'I'), 0x93: (0x8f, 'I', 'I')}
CMP = {0x94: (0x31, 'J'), 0x95: (0x2d, 'F'), 0x96: (0x2e, 'F'), 0x97: (0x2f, 'D'), 0x98: (0x30, 'D')}
IFZ = {0x99: 0x38, 0x9a: 0x39, 0x9b: 0x3a, 0x9c: 0x3b, 0x9d: 0x3c, 0x9e: 0x3d, 0xc6: 0x38, 0xc7: 0x39}
IFCMP = {0x9f: 0x32, 0xa0: 0x33, 0xa1: 0x34, 0xa2: 0x35, 0xa3: 0x36, 0xa4: 0x37, 0xa5: 0x32, 0xa6: 0x33}
NEWARRAY_T = {5: '[C', 6: '[F', 7: '[D', 8: '[B', 9: '[S', 10: '[I', 11: '[J'}

LOAD_KIND = {0x15: 'I', 0x16: 'J', 0x17: 'F', 0x18: 'D', 0x19: 'A'}
STORE_KIND = {0x36: 'I', 0x37: 'J', 0x38: 'F', 0x39: 'D', 0x3a: 'A'}
for k in range(4):
    for base, kd in ((0x1a, 'I'), (0x1e, 'J'), (0x22, 'F'), (0x26, 'D'), (0x2a, 'A')):
        LOAD_KIND[base + k] = kd
    for base, kd in ((0x3b, 'I'), (0x3f, 'J'), (0x43, 'F'), (0x47, 'D'), (0x4b, 'A')):
        STORE_KIND[base + k] = kd


def load_index(op, args):
    if op <= 0x19:
        return args[0]
    return (op - 0x1a) % 4


def store_index(op, args):
    if op <= 0x3a:
        return args[0]
    return (op - 0x3b) % 4


def push_kind(stack, k):
    stack.append(k)
    if k in ('J', 'D'):
        stack.append(k + '2')


def top_value(stack):
    """-> (Art, Anzahl Slots) des obersten Werts"""
    if stack[-1] in ('J2', 'D2'):
        return stack[-2], 2
    return stack[-1], 1


class MethodTranslator:
    def __init__(self, cf, m, pool):
        self.cf, self.m, self.pool = cf, m, pool
        self.code = m.code
        self.is_static = bool(m.access & ACC_STATIC)
        self.is_init = m.name == '<init>'
        params, self.ret = parse_method_desc(m.desc)
        self.ins = (0 if self.is_static else 1) + sum(words(p) for p in params)
        self.max_stack = self.code.max_stack
        self.max_locals = self.code.max_locals
        if self.max_locals < self.ins:
            raise DexError('max_locals < Parameter')
        self.regs = NS + self.max_stack + self.max_locals
        self.units = []
        self.refs = []      # (Position, Art, Schlüssel)
        self.fix = []       # (Befehlsadresse, Position, Breite, Ziel-pc)
        self.outs = 0
        self.where = '%s.%s%s' % (cf.name, m.name, m.desc)

    # ---- Register ----
    def sreg(self, i):
        return NS + i

    def lreg(self, j):
        base = NS + self.max_stack
        if j >= self.ins:
            return base + (j - self.ins)
        return base + (self.max_locals - self.ins) + j

    # ---- Ausgabe ----
    def emit(self, *u):
        for x in u:
            assert 0 <= x <= 0xFFFF, (x, self.where)
        self.units.extend(u)

    def mv(self, kind, dst, src):
        if dst == src:
            return
        ops = MOVE[fam(kind)]
        if dst < 16 and src < 16:
            self.emit(ops[0] | (dst << 8) | (src << 12))
        elif dst < 256:
            self.emit(ops[1] | (dst << 8), src)
        else:
            self.emit(ops[2], dst, src)

    def err(self, msg):
        raise DexError('%s: %s' % (self.where, msg))

    # ---- Stapelarten (Datenfluss) ----
    def analyze(self):
        insns = decode(self.code.code)
        self.insns = insns
        self.by_pc = {pc: i for i, (pc, _, _, _) in enumerate(insns)}
        states = {0: ((), not self.is_init)}
        work = [0]
        handler_pcs = set(h[2] for h in self.code.handlers)
        self.handler_pcs = handler_pcs

        def merge(pc, st):
            old = states.get(pc)
            if old is None:
                states[pc] = st
                work.append(pc)
            elif old != st:
                self.err('unterschiedliche Stapelzustände bei pc %d: %r / %r' % (pc, old, st))

        while work:
            pc = work.pop()
            idx = self.by_pc[pc]
            _, op, args, ln = insns[idx]
            stack, init = list(states[pc][0]), states[pc][1]
            for (s, e, h, t) in self.code.handlers:
                if s <= pc < e:
                    merge(h, (('A',), init))
            nxt, targets = self.step(pc, op, args, stack, init)
            for tpc, tst in targets:
                merge(tpc, tst)
            if nxt is not None:
                merge(pc + ln, nxt)
        self.states = states

    def step(self, pc, op, args, st, init):
        """Wendet einen Befehl auf den Stapel an. -> (Folgezustand, [(Ziel, Zustand)])"""
        cf = self.cf

        def pop(n):
            for _ in range(n):
                st.pop()

        def state():
            return (tuple(st), init)

        if op == 0x00:
            pass
        elif op == 0x01:
            st.append('A')
        elif 0x02 <= op <= 0x08 or op in (0x10, 0x11):
            st.append('I')
        elif op in (0x09, 0x0a):
            push_kind(st, 'J')
        elif 0x0b <= op <= 0x0d:
            st.append('F')
        elif op in (0x0e, 0x0f):
            push_kind(st, 'D')
        elif op in (0x12, 0x13, 0x14):
            e = cf.cp[args[0]]
            push_kind(st, {'Integer': 'I', 'Float': 'F', 'Long': 'J', 'Double': 'D', 'String': 'A', 'Class': 'A'}[e[0]])
        elif op in LOAD_KIND:
            k = LOAD_KIND[op]
            if k == 'A' and not init and load_index(op, args) == 0:
                st.append('U0')
            else:
                push_kind(st, k)
        elif op in STORE_KIND:
            pop(words(STORE_KIND[op].replace('A', 'L;')))
        elif op in ARRAY_GET:
            pop(2); push_kind(st, ARRAY_GET[op][1])
        elif op in ARRAY_PUT:
            pop(2 + (2 if ARRAY_PUT[op][1] in 'JD' else 1))
        elif op == 0x57:
            pop(1)
        elif op == 0x58:
            pop(2)
        elif op == 0x59:
            st.append(st[-1])
        elif op == 0x5a:
            a, b = st[-2], st[-1]; st[-2:] = [b, a, b]
        elif op == 0x5c:
            st.extend(st[-2:])
        elif op == 0x5f:
            st[-2], st[-1] = st[-1], st[-2]
        elif op in BINOP:
            k = BINOP[op][1]; n = 2 if k in 'JD' else 1
            pop(2 * n); push_kind(st, k)
        elif op in LSHIFT:
            pop(3); push_kind(st, 'J')
        elif op in NEG:
            pass
        elif op == 0x84:
            pass
        elif op in CONV:
            _, a, b = CONV[op]
            pop(2 if a in 'JD' else 1); push_kind(st, b)
        elif op in CMP:
            k = CMP[op][1]; pop(4 if k in 'JD' else 2); st.append('I')
        elif op in IFZ:
            pop(1); return state(), [(args[0], state())]
        elif op in IFCMP:
            pop(2); return state(), [(args[0], state())]
        elif op in (0xa7, 0xc8):
            return None, [(args[0], state())]
        elif 0xac <= op <= 0xb1:
            return None, []
        elif op in (0xb2, 0xb3, 0xb4, 0xb5):
            _, cls, name, desc = cf.member(args[0])
            if op == 0xb2:
                push_kind(st, kind_of(desc))
            elif op == 0xb3:
                pop(words(desc))
            elif op == 0xb4:
                pop(1); push_kind(st, kind_of(desc))
            else:
                pop(words(desc) + 1)
        elif 0xb6 <= op <= 0xb9:
            _, cls, name, desc = cf.member(args[0])
            params, ret = parse_method_desc(desc)
            nw = sum(words(p) for p in params) + (0 if op == 0xb8 else 1)
            recv = st[len(st) - nw] if op != 0xb8 else None
            pop(nw)
            if op == 0xb7 and name == '<init>':
                if recv == 'U0':
                    init = True
                    st[:] = ['A' if x == 'U0' else x for x in st]
                elif recv and recv.startswith('N'):
                    st[:] = ['A' if x == recv else x for x in st]
                else:
                    self.err('Konstruktoraufruf auf unerwartetem Wert %r' % recv)
            k = kind_of(ret)
            if k:
                push_kind(st, k)
        elif op == 0xbb:
            st.append('N%d' % pc)
        elif op in (0xbc, 0xbd):
            pop(1); st.append('A')
        elif op == 0xbe:
            pop(1); st.append('I')
        elif op == 0xbf:
            return None, []
        elif op == 0xc0:
            pass
        elif op == 0xc1:
            pop(1); st.append('I')
        else:
            self.err('Opcode 0x%02x wird nicht unterstützt' % op)
        return state(), []

    # ---- Übersetzung ----
    def translate(self):
        self.analyze()
        self.addr = {}
        for (pc, op, args, ln) in self.insns:
            if pc not in self.states:
                continue  # unerreichbar
            self.addr[pc] = len(self.units)
            st = list(self.states[pc][0])
            if pc in self.handler_pcs:
                if st != ['A']:
                    self.err('Handler mit unerwartetem Stapel')
                self.emit(0x0d | (self.sreg(0) << 8))  # move-exception
            nxt = None
            idx = self.by_pc[pc]
            if idx + 1 < len(self.insns):
                nxt = self.insns[idx + 1]
            self.one(pc, op, args, st, nxt)
        # Adressen für unerreichbare / End-pcs auffüllen
        end = len(self.units)
        all_pcs = [p for (p, _, _, _) in self.insns] + [len(self.code.code)]
        fill = end
        for p in reversed(all_pcs):
            if p in self.addr:
                fill = self.addr[p]
            else:
                self.addr[p] = fill
        for (iaddr, pos, width, tpc) in self.fix:
            off = self.addr[tpc] - iaddr
            if width == 16:
                if not -32768 <= off <= 32767:
                    self.err('Sprung zu weit')
                self.units[pos] = off & 0xFFFF
            else:
                self.units[pos] = off & 0xFFFF
                self.units[pos + 1] = (off >> 16) & 0xFFFF
        self.tries = self.build_tries()

    def one(self, pc, op, args, st, nxt):
        s = len(st)
        scratch = [0]
        post = []

        def take(kind):
            if kind in ('J', 'D'):
                if scratch[0] % 2:
                    scratch[0] += 1
                r = scratch[0]; scratch[0] += 2
            else:
                r = scratch[0]; scratch[0] += 1
            if scratch[0] > NS:
                self.err('zu wenige Hilfsregister')
            return r

        def R(reg, kind, bits):
            if reg < (1 << bits):
                return reg
            t = take(kind); self.mv(kind, t, reg); return t

        def W(reg, kind, bits):
            if reg < (1 << bits):
                return reg
            t = take(kind); post.append((kind, reg, t)); return t

        def flush():
            for (kind, reg, t) in post:
                self.mv(kind, reg, t)

        def const32(dst_slot, val, kind):
            d = W(self.sreg(dst_slot), kind, 8)
            val &= 0xFFFFFFFF
            sv = val - (1 << 32) if val & 0x80000000 else val
            if -8 <= sv <= 7 and d < 16:
                self.emit(0x12 | (d << 8) | ((sv & 0xF) << 12))
            elif -32768 <= sv <= 32767:
                self.emit(0x13 | (d << 8), sv & 0xFFFF)
            elif val & 0xFFFF == 0:
                self.emit(0x15 | (d << 8), val >> 16)
            else:
                self.emit(0x14 | (d << 8), val & 0xFFFF, val >> 16)
            flush()

        def const64(dst_slot, val, kind):
            d = W(self.sreg(dst_slot), kind, 8)
            val &= 0xFFFFFFFFFFFFFFFF
            sv = val - (1 << 64) if val >> 63 else val
            if -32768 <= sv <= 32767:
                self.emit(0x16 | (d << 8), sv & 0xFFFF)
            elif -(1 << 31) <= sv < (1 << 31):
                self.emit(0x17 | (d << 8), sv & 0xFFFF, (sv >> 16) & 0xFFFF)
            elif val & 0xFFFFFFFFFFFF == 0:
                self.emit(0x19 | (d << 8), val >> 48)
            else:
                self.emit(0x18 | (d << 8), val & 0xFFFF, (val >> 16) & 0xFFFF, (val >> 32) & 0xFFFF, (val >> 48) & 0xFFFF)
            flush()

        def branch16(first_unit, *more):
            iaddr = len(self.units)
            self.emit(first_unit, *more)
            return iaddr

        def check_plain(i):
            k = st[i]
            if k == 'U0' or k.startswith('N'):
                self.err('nicht initialisiertes Objekt wird verwendet (pc %d)' % pc)

        cf = self.cf
        if op == 0x00:
            return
        if op == 0x01:
            return const32(s, 0, 'A')
        if 0x02 <= op <= 0x08:
            return const32(s, op - 0x03, 'I')
        if op in (0x10, 0x11):
            return const32(s, args[0], 'I')
        if op in (0x09, 0x0a):
            return const64(s, op - 0x09, 'J')
        if 0x0b <= op <= 0x0d:
            return const32(s, struct.unpack('<I', struct.pack('<f', float(op - 0x0b)))[0], 'F')
        if op in (0x0e, 0x0f):
            return const64(s, struct.unpack('<Q', struct.pack('<d', float(op - 0x0e)))[0], 'D')
        if op in (0x12, 0x13, 0x14):
            e = cf.cp[args[0]]
            if e[0] == 'Integer':
                return const32(s, e[1], 'I')
            if e[0] == 'Float':
                return const32(s, e[1], 'F')
            if e[0] == 'Long':
                return const64(s, e[1], 'J')
            if e[0] == 'Double':
                return const64(s, e[1], 'D')
            d = W(self.sreg(s), 'A', 8)
            if e[0] == 'String':
                self.emit(0x1a | (d << 8), 0)
                self.refs.append((len(self.units) - 1, 'string', cf.utf8(e[1])))
            else:
                self.emit(0x1c | (d << 8), 0)
                self.refs.append((len(self.units) - 1, 'type', cdesc(cf.class_name(args[0]))))
            return flush()
        if op in LOAD_KIND:
            k, n = LOAD_KIND[op], load_index(op, args)
            if k == 'A' and not self.states[pc][1] and n == 0:
                return  # "this" vor dem Superkonstruktor: bleibt in p0
            return self.mv(k, self.sreg(s), self.lreg(n))
        if op in STORE_KIND:
            k, n = STORE_KIND[op], store_index(op, args)
            sz = 2 if k in 'JD' else 1
            check_plain(s - sz)
            return self.mv(k, self.lreg(n), self.sreg(s - sz))
        if op in ARRAY_GET:
            dop, k = ARRAY_GET[op]
            if op == 0x33:
                pass  # baload: nur byte[] erlaubt (boolean[] wird beim Anlegen abgelehnt)
            arr, ix = self.sreg(s - 2), self.sreg(s - 1)
            a, i = R(arr, 'A', 8), R(ix, 'I', 8)
            d = W(self.sreg(s - 2), k, 8)
            self.emit(dop | (d << 8), a | (i << 8))
            return flush()
        if op in ARRAY_PUT:
            dop, k = ARRAY_PUT[op]
            vs = 2 if k in 'JD' else 1
            arr, ix, val = self.sreg(s - 2 - vs), self.sreg(s - 1 - vs), self.sreg(s - vs)
            v, a, i = R(val, k, 8), R(arr, 'A', 8), R(ix, 'I', 8)
            self.emit(dop | (v << 8), a | (i << 8))
            return
        if op in (0x57, 0x58):
            return
        if op == 0x59:
            k = st[-1]
            if k.startswith('N'):
                if st.count(k) != 1:
                    self.err('dup auf neuem Objekt unerwartet')
                return  # new-instance liegt bereits im oberen Slot
            if k == 'U0':
                self.err('dup auf nicht initialisiertem this')
            return self.mv(k, self.sreg(s), self.sreg(s - 1))
        if op == 0x5a:
            b, a = st[-1], st[-2]
            check_plain(s - 1); check_plain(s - 2)
            self.mv(b, self.sreg(s), self.sreg(s - 1))
            self.mv(a, self.sreg(s - 1), self.sreg(s - 2))
            self.mv(b, self.sreg(s - 2), self.sreg(s))
            return
        if op == 0x5c:
            if st[-1] in ('J2', 'D2'):
                return self.mv(st[-2], self.sreg(s), self.sreg(s - 2))
            check_plain(s - 1); check_plain(s - 2)
            self.mv(st[-2], self.sreg(s), self.sreg(s - 2))
            self.mv(st[-1], self.sreg(s + 1), self.sreg(s - 1))
            return
        if op == 0x5f:
            check_plain(s - 1); check_plain(s - 2)
            t = take(st[-1])
            self.mv(st[-1], t, self.sreg(s - 1))
            self.mv(st[-2], self.sreg(s - 1), self.sreg(s - 2))
            self.mv(st[-1], self.sreg(s - 2), t)
            return
        if op in BINOP:
            dop, k = BINOP[op]
            n = 2 if k in 'JD' else 1
            A_, B_ = self.sreg(s - 2 * n), self.sreg(s - n)
            a, b = R(A_, k, 8), R(B_, k, 8)
            d = W(A_, k, 8)
            self.emit(dop | (d << 8), a | (b << 8))
            return flush()
        if op in LSHIFT:
            A_, B_ = self.sreg(s - 3), self.sreg(s - 1)
            a, b = R(A_, 'J', 8), R(B_, 'I', 8)
            d = W(A_, 'J', 8)
            self.emit(LSHIFT[op] | (d << 8), a | (b << 8))
            return flush()
        if op in NEG:
            dop, k = NEG[op]
            sz = 2 if k in 'JD' else 1
            r = self.sreg(s - sz)
            a = R(r, k, 4)
            d = W(r, k, 4)
            self.emit(dop | (d << 8) | (a << 12))
            return flush()
        if op == 0x84:
            reg, c = self.lreg(args[0]), args[1]
            if reg < 256 and -128 <= c <= 127:
                self.emit(0xd8 | (reg << 8), reg | ((c & 0xFF) << 8))
            else:
                r = R(reg, 'I', 4)
                self.emit(0xd0 | (r << 8) | (r << 12), c & 0xFFFF)
                self.mv('I', reg, r)
            return
        if op in CONV:
            dop, ka, kb = CONV[op]
            sz = 2 if ka in 'JD' else 1
            r = self.sreg(s - sz)
            a = R(r, ka, 4)
            d = W(r, kb, 4)
            self.emit(dop | (d << 8) | (a << 12))
            return flush()
        if op in CMP:
            dop, k = CMP[op]
            n = 2 if k in 'JD' else 1
            A_, B_ = self.sreg(s - 2 * n), self.sreg(s - n)
            a, b = R(A_, k, 8), R(B_, k, 8)
            d = W(A_, 'I', 8)
            self.emit(dop | (d << 8), a | (b << 8))
            return flush()
        if op in IFZ:
            check_plain(s - 1)
            a = R(self.sreg(s - 1), st[-1], 8)
            iaddr = branch16(IFZ[op] | (a << 8), 0)
            self.fix.append((iaddr, iaddr + 1, 16, args[0]))
            return
        if op in IFCMP:
            check_plain(s - 1); check_plain(s - 2)
            a = R(self.sreg(s - 2), st[-2], 4)
            b = R(self.sreg(s - 1), st[-1], 4)
            iaddr = branch16(IFCMP[op] | (a << 8) | (b << 12), 0)
            self.fix.append((iaddr, iaddr + 1, 16, args[0]))
            return
        if op in (0xa7, 0xc8):
            iaddr = len(self.units)
            self.emit(0x2a, 0, 0)
            self.fix.append((iaddr, iaddr + 1, 32, args[0]))
            return
        if op == 0xb1:
            if self.ret != 'V':
                self.err('return ohne Wert')
            return self.emit(0x0e)
        if 0xac <= op <= 0xb0:
            k, sz = top_value(st)
            check_plain(s - sz)
            a = R(self.sreg(s - sz), k, 8)
            return self.emit(RETURN[fam(k)] | (a << 8))
        if op in (0xb2, 0xb3):
            _, cls, name, desc = cf.member(args[0])
            k = kind_of(desc)
            self.pool_type_check(desc)
            key = (cdesc(cls), name, desc)
            if op == 0xb2:
                d = W(self.sreg(s), k, 8)
                self.emit(0x60 + field_variant(desc) | (d << 8), 0)
            else:
                check_plain(s - words(desc))
                a = R(self.sreg(s - words(desc)), k, 8)
                self.emit(0x67 + field_variant(desc) | (a << 8), 0)
            self.refs.append((len(self.units) - 1, 'field', key))
            return flush()
        if op in (0xb4, 0xb5):
            _, cls, name, desc = cf.member(args[0])
            k = kind_of(desc)
            self.pool_type_check(desc)
            key = (cdesc(cls), name, desc)
            if op == 0xb4:
                check_plain(s - 1)
                o = R(self.sreg(s - 1), 'A', 4)
                d = W(self.sreg(s - 1), k, 4)
                self.emit(0x52 + field_variant(desc) | (d << 8) | (o << 12), 0)
            else:
                vs = words(desc)
                check_plain(s - vs)
                if st[s - vs - 1] == 'U0':
                    o = self.lreg(0)
                    if o >= 16:
                        self.err('iput auf this vor super() mit hohem Register')
                else:
                    check_plain(s - vs - 1)
                    o = R(self.sreg(s - vs - 1), 'A', 4)
                v = R(self.sreg(s - vs), k, 4)
                self.emit(0x59 + field_variant(desc) | (v << 8) | (o << 12), 0)
            self.refs.append((len(self.units) - 1, 'field', key))
            return flush()
        if 0xb6 <= op <= 0xb9:
            tag, cls, name, desc = cf.member(args[0])
            params, ret = parse_method_desc(desc)
            for t in params + [ret]:
                self.pool_type_check(t)
            nw = sum(words(p) for p in params) + (0 if op == 0xb8 else 1)
            start = s - nw
            recv = st[start] if op != 0xb8 else None
            for i in range(start + (0 if op == 0xb8 else 1), s):
                check_plain(i)
            if op == 0xb6:
                dop = 0x74
            elif op == 0xb8:
                dop = 0x77
            elif op == 0xb9:
                dop = 0x78
            else:
                if name == '<init>' or (cls == cf.name and self.is_private(name, desc)):
                    dop = 0x76
                else:
                    dop = 0x75
            if name == '<init>' and op != 0xb7:
                self.err('Konstruktor nicht über invokespecial')
            if recv == 'U0':
                if name != '<init>' or nw != 1:
                    self.err('this vor super() nur für super()/this() ohne Argumente unterstützt')
                first = self.lreg(0)
            else:
                if recv is not None and recv.startswith('N') and name != '<init>':
                    self.err('Methode auf nicht initialisiertem Objekt')
                first = self.sreg(start) if nw else 0
            if nw > 255:
                self.err('zu viele Argumente')
            self.outs = max(self.outs, nw)
            key = (cdesc(cls), name, desc)
            self.emit(dop | (nw << 8), 0, first)
            self.refs.append((len(self.units) - 2, 'method', key))
            if name == '<init>' and recv and recv.startswith('N'):
                if start - 1 < 0 or st[start - 1] != recv:
                    self.err('new ohne dup-Kopie')
                self.mv('A', self.sreg(start - 1), self.sreg(start))
            k = kind_of(ret)
            if k:
                d = W(self.sreg(start), k, 8)
                self.emit(MOVE_RESULT[fam(k)] | (d << 8))
                flush()
            return
        if op == 0xbb:
            if not nxt or nxt[1] != 0x59:
                self.err('new ohne direkt folgendes dup')
            d = W(self.sreg(s + 1), 'A', 8)
            self.emit(0x22 | (d << 8), 0)
            self.refs.append((len(self.units) - 1, 'type', cdesc(cf.class_name(args[0]))))
            return flush()
        if op in (0xbc, 0xbd):
            if op == 0xbc:
                if args[0] == 4:
                    self.err('boolean[] wird nicht unterstützt (bitte byte[] verwenden)')
                t = NEWARRAY_T[args[0]]
            else:
                t = '[' + cdesc(cf.class_name(args[0]))
            self.pool_type_check(t)
            n = R(self.sreg(s - 1), 'I', 4)
            d = W(self.sreg(s - 1), 'A', 4)
            self.emit(0x23 | (d << 8) | (n << 12), 0)
            self.refs.append((len(self.units) - 1, 'type', t))
            return flush()
        if op == 0xbe:
            check_plain(s - 1)
            a = R(self.sreg(s - 1), 'A', 4)
            d = W(self.sreg(s - 1), 'I', 4)
            self.emit(0x21 | (d << 8) | (a << 12))
            return flush()
        if op == 0xbf:
            check_plain(s - 1)
            a = R(self.sreg(s - 1), 'A', 8)
            return self.emit(0x27 | (a << 8))
        if op == 0xc0:
            check_plain(s - 1)
            reg = self.sreg(s - 1)
            a = R(reg, 'A', 8)
            self.emit(0x1f | (a << 8), 0)
            self.refs.append((len(self.units) - 1, 'type', cdesc(cf.class_name(args[0]))))
            if a != reg:
                self.mv('A', reg, a)
            return
        if op == 0xc1:
            check_plain(s - 1)
            a = R(self.sreg(s - 1), 'A', 4)
            d = W(self.sreg(s - 1), 'I', 4)
            self.emit(0x20 | (d << 8) | (a << 12), 0)
            self.refs.append((len(self.units) - 1, 'type', cdesc(cf.class_name(args[0]))))
            return flush()
        self.err('Opcode 0x%02x wird nicht unterstützt' % op)

    def pool_type_check(self, t):
        if '[Z' in t:
            self.err('boolean[] wird nicht unterstützt (bitte byte[] verwenden)')

    def is_private(self, name, desc):
        for m in self.cf.methods:
            if m.name == name and m.desc == desc:
                return bool(m.access & ACC_PRIVATE)
        return False

    def build_tries(self):
        """Überlappende JVM-Bereiche -> sortierte, disjunkte Dalvik-try-Bereiche"""
        entries = []
        for (s, e, h, t) in self.code.handlers:
            ds, de = self.addr[s], self.addr[e]
            if h not in self.addr or h not in self.states:
                continue
            entries.append((ds, de, self.addr[h], cdesc(t) if t else None))
        if not entries:
            return []
        cuts = sorted(set([x[0] for x in entries] + [x[1] for x in entries]))
        out = []
        for a, b in zip(cuts, cuts[1:]):
            hs, seen, catch_all = [], set(), None
            for (ds, de, ha, t) in entries:
                if ds <= a and b <= de:
                    if t is None:
                        catch_all = ha
                        break
                    if t not in seen:
                        seen.add(t); hs.append((t, ha))
            if not hs and catch_all is None:
                continue
            key = (tuple(hs), catch_all)
            if out and out[-1][1] == a and out[-1][2] == key:
                out[-1][1] = b
            else:
                out.append([a, b, key])
        res = []
        for a, b, key in out:
            while b - a > 0xFFFF:
                res.append((a, a + 0xFFFF, key)); a += 0xFFFF
            res.append((a, b, key))
        return res


# ---------------- DEX-Schreiber ----------------

def uleb(v):
    out = bytearray()
    while True:
        b = v & 0x7F
        v >>= 7
        if v:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def sleb(v):
    out = bytearray()
    while True:
        b = v & 0x7F
        v >>= 7
        if (v == 0 and not b & 0x40) or (v == -1 and b & 0x40):
            out.append(b)
            return bytes(out)
        out.append(b | 0x80)


def mutf8_encode(s):
    out = bytearray()
    for ch in s:
        u = ord(ch)
        if u > 0xFFFF:
            raise DexError('Zeichen außerhalb BMP')
        if u != 0 and u < 0x80:
            out.append(u)
        elif u < 0x800:
            out += bytes([0xC0 | (u >> 6), 0x80 | (u & 0x3F)])
        else:
            out += bytes([0xE0 | (u >> 12), 0x80 | ((u >> 6) & 0x3F), 0x80 | (u & 0x3F)])
    return bytes(out)


def sort_key_str(s):
    return s.encode('utf-16-be', 'surrogatepass')


class DexWriter:
    def __init__(self):
        self.classes = []

    def add_class(self, cf):
        methods = []
        for m in cf.methods:
            if m.access & ACC_SYNCHRONIZED:
                raise DexError('%s.%s: synchronized wird nicht unterstützt' % (cf.name, m.name))
            tr = None
            if m.code is not None:
                tr = MethodTranslator(cf, m, None)
                tr.translate()
            methods.append((m, tr))
        self.classes.append((cf, methods))

    def build(self):
        strings, types, protos, fields, meths = set(), set(), set(), set(), set()

        def T(t):
            types.add(t); strings.add(t)

        def P(desc):
            pk = proto_key(desc)
            protos.add(pk); strings.add(pk[0]); T(pk[1])
            for p in pk[2]:
                T(p)
            return pk

        for cf, methods in self.classes:
            T(cdesc(cf.name))
            if cf.super:
                T(cdesc(cf.super))
            for i in cf.interfaces:
                T(cdesc(i))
            for f in cf.fields:
                fields.add((cdesc(cf.name), f.name, f.desc)); strings.add(f.name); T(f.desc)
            for m, tr in methods:
                meths.add((cdesc(cf.name), m.name, P(m.desc))); strings.add(m.name)
                if tr:
                    for (_, kind, key) in tr.refs:
                        if kind == 'string':
                            strings.add(key)
                        elif kind == 'type':
                            T(key)
                        elif kind == 'field':
                            fields.add(key); T(key[0]); strings.add(key[1]); T(key[2])
                        elif kind == 'method':
                            meths.add((key[0], key[1], P(key[2]))); T(key[0]); strings.add(key[1])
                    for (_, _, (hs, _)) in tr.tries:
                        for t, _ in hs:
                            T(t)

        s_list = sorted(strings, key=sort_key_str)
        s_idx = {s: i for i, s in enumerate(s_list)}
        t_list = sorted(types, key=lambda t: s_idx[t])
        t_idx = {t: i for i, t in enumerate(t_list)}
        p_list = sorted(protos, key=lambda p: (t_idx[p[1]], [t_idx[x] for x in p[2]]))
        p_idx = {p: i for i, p in enumerate(p_list)}
        f_list = sorted(fields, key=lambda f: (t_idx[f[0]], s_idx[f[1]], t_idx[f[2]]))
        f_idx = {f: i for i, f in enumerate(f_list)}
        m_list = sorted(meths, key=lambda m: (t_idx[m[0]], s_idx[m[1]], p_idx[m[2]]))
        m_idx = {m: i for i, m in enumerate(m_list)}
        for tbl in (s_list, t_list, p_list, f_list, m_list):
            if len(tbl) > 0xFFFF:
                raise DexError('Pool zu groß')

        # Klassen: Oberklassen zuerst
        defined = {cdesc(cf.name): (cf, ms) for cf, ms in self.classes}
        order, done = [], set()

        def visit(d):
            if d in done or d not in defined:
                return
            cf, _ = defined[d]
            if cf.super:
                visit(cdesc(cf.super))
            for i in cf.interfaces:
                visit(cdesc(i))
            done.add(d); order.append(defined[d])
        for cf, _ in self.classes:
            visit(cdesc(cf.name))

        # Layout
        HDR = 0x70
        off = HDR
        sid_off = off; off += 4 * len(s_list)
        tid_off = off; off += 4 * len(t_list)
        pid_off = off; off += 12 * len(p_list)
        fid_off = off; off += 8 * len(f_list)
        mid_off = off; off += 8 * len(m_list)
        cdef_off = off; off += 32 * len(order)
        data_off = off

        data = bytearray()

        def align4():
            while (data_off + len(data)) % 4:
                data.append(0)

        # Code-Items
        code_off = {}
        code_count = 0
        code_start = None
        for cf, methods in order:
            for m, tr in methods:
                if not tr:
                    continue
                align4()
                if code_start is None:
                    code_start = data_off + len(data)
                code_off[(cf.name, m.name, m.desc)] = data_off + len(data)
                units = list(tr.units)
                for (pos, kind, key) in tr.refs:
                    if kind == 'string':
                        units[pos] = s_idx[key]
                    elif kind == 'type':
                        units[pos] = t_idx[key]
                    elif kind == 'field':
                        units[pos] = f_idx[key]
                    else:
                        units[pos] = m_idx[(key[0], key[1], proto_key(key[2]))]
                data += struct.pack('<HHHHII', tr.regs, tr.ins, tr.outs, len(tr.tries), 0, len(units))
                data += struct.pack('<%dH' % len(units), *units)
                if tr.tries:
                    if len(units) % 2:
                        data += b'\0\0'
                    handlers, h_off, hb = [], {}, bytearray()
                    for (_, _, key) in tr.tries:
                        if key not in h_off:
                            handlers.append(key)
                    body = bytearray()
                    for key in handlers:
                        h_off[key] = len(body)
                        hs, catch_all = key
                        body += sleb(-len(hs) if catch_all is not None else len(hs))
                        for t, a in hs:
                            body += uleb(t_idx[t]) + uleb(a)
                        if catch_all is not None:
                            body += uleb(catch_all)
                    head = uleb(len(handlers))
                    for (a, b, key) in tr.tries:
                        data += struct.pack('<IHH', a, b - a, len(head) + h_off[key])
                    data += head + body
                code_count += 1

        # Typlisten
        align4()
        tl_off, tl_start, tl_count = {}, None, 0

        def typelist(lst):
            nonlocal tl_start, tl_count
            lst = tuple(lst)
            if not lst:
                return 0
            if lst in tl_off:
                return tl_off[lst]
            align4()
            if tl_start is None:
                tl_start = data_off + len(data)
            tl_off[lst] = data_off + len(data)
            data.extend(struct.pack('<I', len(lst)) + struct.pack('<%dH' % len(lst), *[t_idx[t] for t in lst]))
            tl_count += 1
            return tl_off[lst]
        proto_params_off = [typelist(p[2]) for p in p_list]
        iface_off = {cf.name: typelist([cdesc(i) for i in cf.interfaces]) for cf, _ in order}

        # Zeichenketten
        sd_start = data_off + len(data)
        sd_off = []
        for s in s_list:
            sd_off.append(data_off + len(data))
            data.extend(uleb(len(s)) + mutf8_encode(s) + b'\0')

        # Klassendaten
        cd_start = data_off + len(data)
        cd_off = {}
        for cf, methods in order:
            cd_off[cf.name] = data_off + len(data)
            sf = sorted([f for f in cf.fields if f.access & ACC_STATIC], key=lambda f: f_idx[(cdesc(cf.name), f.name, f.desc)])
            inf = sorted([f for f in cf.fields if not f.access & ACC_STATIC], key=lambda f: f_idx[(cdesc(cf.name), f.name, f.desc)])
            dm, vm = [], []
            for m, tr in methods:
                acc = m.access & 0x1DFF
                if m.name in ('<init>', '<clinit>'):
                    acc |= ACC_CONSTRUCTOR
                mi = m_idx[(cdesc(cf.name), m.name, proto_key(m.desc))]
                co = code_off.get((cf.name, m.name, m.desc), 0)
                if (m.access & (ACC_STATIC | ACC_PRIVATE)) or m.name in ('<init>', '<clinit>'):
                    dm.append((mi, acc, co))
                else:
                    vm.append((mi, acc, co))
            dm.sort(); vm.sort()
            data.extend(uleb(len(sf)) + uleb(len(inf)) + uleb(len(dm)) + uleb(len(vm)))
            for lst in (sf, inf):
                prev = 0
                for f in lst:
                    fi = f_idx[(cdesc(cf.name), f.name, f.desc)]
                    data.extend(uleb(fi - prev) + uleb(f.access & 0x50DF)); prev = fi
            for lst in (dm, vm):
                prev = 0
                for (mi, acc, co) in lst:
                    data.extend(uleb(mi - prev) + uleb(acc) + uleb(co)); prev = mi

        # Map
        align4()
        map_off = data_off + len(data)
        items = [(0x0000, 1, 0)]
        if s_list: items.append((0x0001, len(s_list), sid_off))
        if t_list: items.append((0x0002, len(t_list), tid_off))
        if p_list: items.append((0x0003, len(p_list), pid_off))
        if f_list: items.append((0x0004, len(f_list), fid_off))
        if m_list: items.append((0x0005, len(m_list), mid_off))
        if order: items.append((0x0006, len(order), cdef_off))
        if code_count: items.append((0x2001, code_count, code_start))
        if tl_count: items.append((0x1001, tl_count, tl_start))
        if s_list: items.append((0x2002, len(s_list), sd_start))
        if order: items.append((0x2000, len(order), cd_start))
        items.append((0x1000, 1, map_off))
        items.sort(key=lambda x: x[2])
        data.extend(struct.pack('<I', len(items)))
        for (tp, cnt, o) in items:
            data.extend(struct.pack('<HHII', tp, 0, cnt, o))

        # Kopf und ID-Bereiche
        ids = bytearray()
        for o in sd_off:
            ids += struct.pack('<I', o)
        for t in t_list:
            ids += struct.pack('<I', s_idx[t])
        for p, po in zip(p_list, proto_params_off):
            ids += struct.pack('<III', s_idx[p[0]], t_idx[p[1]], po)
        for f in f_list:
            ids += struct.pack('<HHI', t_idx[f[0]], t_idx[f[2]], s_idx[f[1]])
        for m in m_list:
            ids += struct.pack('<HHI', t_idx[m[0]], p_idx[m[2]], s_idx[m[1]])
        NO = 0xFFFFFFFF
        for cf, _ in order:
            ids += struct.pack('<IIIIIIII', t_idx[cdesc(cf.name)], cf.access & 0x7611,
                               t_idx[cdesc(cf.super)] if cf.super else NO, iface_off[cf.name],
                               NO, 0, cd_off[cf.name], 0)
        assert HDR + len(ids) == data_off
        file_size = data_off + len(data)

        def cnt_off(n, o):
            return (n, o if n else 0)
        hdr = bytearray(b'dex\n035\0') + bytes(4 + 20)
        hdr += struct.pack('<IIIII', file_size, HDR, 0x12345678, 0, 0)
        hdr += struct.pack('<I', map_off)
        for n, o in (cnt_off(len(s_list), sid_off), cnt_off(len(t_list), tid_off), cnt_off(len(p_list), pid_off),
                     cnt_off(len(f_list), fid_off), cnt_off(len(m_list), mid_off), cnt_off(len(order), cdef_off)):
            hdr += struct.pack('<II', n, o)
        hdr += struct.pack('<II', len(data), data_off)
        assert len(hdr) == HDR
        out = bytearray(hdr + ids + data)
        out[12:32] = hashlib.sha1(bytes(out[32:])).digest()
        out[8:12] = struct.pack('<I', zlib.adler32(bytes(out[12:])) & 0xFFFFFFFF)
        return bytes(out)


def main(argv):
    if len(argv) < 3:
        print('Aufruf: dexgen.py ausgabe.dex Klasse.class ...')
        return 2
    w = DexWriter()
    for p in argv[2:]:
        with open(p, 'rb') as f:
            w.add_class(ClassFile(f.read()))
    dex = w.build()
    with open(argv[1], 'wb') as f:
        f.write(dex)
    print('%s: %d Bytes, %d Klassen' % (argv[1], len(dex), len(w.classes)))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
