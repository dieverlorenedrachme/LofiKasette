"""Liest Java-Class-Dateien (Konstantenpool, Felder, Methoden, Bytecode)."""
import struct


def mutf8_decode(b):
    """Modified UTF-8 -> Python-String aus UTF-16-Codeeinheiten (Surrogate bleiben einzeln)."""
    units, i = [], 0
    while i < len(b):
        c = b[i]
        if c < 0x80:
            units.append(c); i += 1
        elif c & 0xE0 == 0xC0:
            units.append(((c & 0x1F) << 6) | (b[i + 1] & 0x3F)); i += 2
        elif c & 0xF0 == 0xE0:
            units.append(((c & 0x0F) << 12) | ((b[i + 1] & 0x3F) << 6) | (b[i + 2] & 0x3F)); i += 3
        else:
            raise ValueError('ungültiges MUTF-8')
    return ''.join(chr(u) for u in units)


def parse_method_desc(desc):
    """'(ILjava/lang/String;)V' -> (['I', 'Ljava/lang/String;'], 'V')"""
    assert desc[0] == '('
    params, i = [], 1
    while desc[i] != ')':
        j = i
        while desc[j] == '[':
            j += 1
        if desc[j] == 'L':
            j = desc.index(';', j)
        params.append(desc[i:j + 1])
        i = j + 1
    return params, desc[i + 1:]


def kind_of(t):
    """Typdeskriptor -> Stack-Art: I, F, J, D, A oder None (void)."""
    c = t[0]
    if c in 'ZBCSI':
        return 'I'
    if c in 'FJD':
        return c
    if c in 'L[':
        return 'A'
    if c == 'V':
        return None
    raise ValueError(t)


def words(t):
    return 2 if t[0] in 'JD' else (0 if t == 'V' else 1)


class Code:
    def __init__(self, max_stack, max_locals, code, handlers):
        self.max_stack = max_stack
        self.max_locals = max_locals
        self.code = code
        self.handlers = handlers  # [(start_pc, end_pc, handler_pc, catch_type or None)]


class Method:
    def __init__(self, access, name, desc, code):
        self.access, self.name, self.desc, self.code = access, name, desc, code


class Field:
    def __init__(self, access, name, desc):
        self.access, self.name, self.desc = access, name, desc


class ClassFile:
    def __init__(self, data):
        self.data = data
        r = Reader(data)
        if r.u4() != 0xCAFEBABE:
            raise ValueError('keine Class-Datei')
        self.minor, self.major = r.u2(), r.u2()
        n = r.u2()
        cp = [None] * n
        i = 1
        while i < n:
            tag = r.u1()
            if tag == 1:
                ln = r.u2(); cp[i] = ('Utf8', mutf8_decode(r.bytes(ln)))
            elif tag == 3:
                cp[i] = ('Integer', struct.unpack('>i', r.bytes(4))[0])
            elif tag == 4:
                cp[i] = ('Float', struct.unpack('>I', r.bytes(4))[0])  # Rohbits
            elif tag == 5:
                cp[i] = ('Long', struct.unpack('>q', r.bytes(8))[0]); i += 1
            elif tag == 6:
                cp[i] = ('Double', struct.unpack('>Q', r.bytes(8))[0]); i += 1  # Rohbits
            elif tag == 7:
                cp[i] = ('Class', r.u2())
            elif tag == 8:
                cp[i] = ('String', r.u2())
            elif tag in (9, 10, 11):
                cp[i] = ({9: 'Fieldref', 10: 'Methodref', 11: 'InterfaceMethodref'}[tag], r.u2(), r.u2())
            elif tag == 12:
                cp[i] = ('NameAndType', r.u2(), r.u2())
            elif tag in (15, 16, 17, 18, 19, 20):
                raise ValueError('nicht unterstützter Konstantenpool-Eintrag %d (Lambda/invokedynamic?)' % tag)
            else:
                raise ValueError('unbekannter Konstantenpool-Tag %d' % tag)
            i += 1
        self.cp = cp
        self.access = r.u2()
        self.name = self.class_name(r.u2())
        sup = r.u2()
        self.super = self.class_name(sup) if sup else None
        self.interfaces = [self.class_name(r.u2()) for _ in range(r.u2())]
        self.fields = []
        for _ in range(r.u2()):
            acc, nm, ds = r.u2(), self.utf8(r.u2()), self.utf8(r.u2())
            for _ in range(r.u2()):
                r.u2(); r.bytes(r.u4())
            self.fields.append(Field(acc, nm, ds))
        self.methods = []
        for _ in range(r.u2()):
            acc, nm, ds = r.u2(), self.utf8(r.u2()), self.utf8(r.u2())
            code = None
            for _ in range(r.u2()):
                an, ln = self.utf8(r.u2()), r.u4()
                body = r.bytes(ln)
                if an == 'Code':
                    code = self.parse_code(body)
            self.methods.append(Method(acc, nm, ds, code))

    def utf8(self, i):
        e = self.cp[i]
        assert e[0] == 'Utf8'
        return e[1]

    def class_name(self, i):
        e = self.cp[i]
        assert e[0] == 'Class'
        return self.utf8(e[1])

    def member(self, i):
        """Field-/Methodref -> (Art, Klasse, Name, Deskriptor)"""
        e = self.cp[i]
        nt = self.cp[e[2]]
        return e[0], self.class_name(e[1]), self.utf8(nt[1]), self.utf8(nt[2])

    def parse_code(self, body):
        r = Reader(body)
        ms, ml = r.u2(), r.u2()
        code = r.bytes(r.u4())
        handlers = []
        for _ in range(r.u2()):
            s, e, h, t = r.u2(), r.u2(), r.u2(), r.u2()
            handlers.append((s, e, h, self.class_name(t) if t else None))
        return Code(ms, ml, code, handlers)


class Reader:
    def __init__(self, data):
        self.d, self.p = data, 0

    def u1(self):
        v = self.d[self.p]; self.p += 1; return v

    def u2(self):
        v = struct.unpack_from('>H', self.d, self.p)[0]; self.p += 2; return v

    def u4(self):
        v = struct.unpack_from('>I', self.d, self.p)[0]; self.p += 4; return v

    def bytes(self, n):
        v = self.d[self.p:self.p + n]; self.p += n; return v


# ---------------- Bytecode-Dekodierung ----------------

def decode(code):
    """-> Liste von (pc, opcode, operanden, länge)"""
    out, pc, n = [], 0, len(code)

    def s1(p): return struct.unpack_from('>b', code, p)[0]
    def u2(p): return struct.unpack_from('>H', code, p)[0]
    def s2(p): return struct.unpack_from('>h', code, p)[0]
    def s4(p): return struct.unpack_from('>i', code, p)[0]

    while pc < n:
        op = code[pc]
        if op == 0x10:
            args, ln = (s1(pc + 1),), 2
        elif op == 0x11:
            args, ln = (s2(pc + 1),), 3
        elif op == 0x12:
            args, ln = (code[pc + 1],), 2
        elif op in (0x13, 0x14):
            args, ln = (u2(pc + 1),), 3
        elif 0x15 <= op <= 0x19 or 0x36 <= op <= 0x3a or op == 0xa9:
            args, ln = (code[pc + 1],), 2
        elif op == 0x84:
            args, ln = (code[pc + 1], s1(pc + 2)), 3
        elif 0x99 <= op <= 0xa8 or op in (0xc6, 0xc7):
            args, ln = (pc + s2(pc + 1),), 3
        elif op in (0xc8, 0xc9):
            args, ln = (pc + s4(pc + 1),), 5
        elif 0xb2 <= op <= 0xb8 or op in (0xbb, 0xbd, 0xc0, 0xc1):
            args, ln = (u2(pc + 1),), 3
        elif op == 0xb9:
            args, ln = (u2(pc + 1), code[pc + 3]), 5
        elif op == 0xba:
            args, ln = (u2(pc + 1),), 5
        elif op == 0xbc:
            args, ln = (code[pc + 1],), 2
        elif op == 0xc5:
            args, ln = (u2(pc + 1), code[pc + 3]), 4
        elif op == 0xc4:  # wide
            op2 = code[pc + 1]
            if op2 == 0x84:
                args, ln = (u2(pc + 2), s2(pc + 4)), 6
            else:
                args, ln = (u2(pc + 2),), 4
            out.append((pc, op2, args, ln))
            pc += ln
            continue
        elif op == 0xaa:  # tableswitch
            p = (pc + 4) & ~3
            default, low, high = s4(p), s4(p + 4), s4(p + 8)
            targets = [pc + s4(p + 12 + 4 * k) for k in range(high - low + 1)]
            args, ln = (pc + default, low, targets), p + 12 + 4 * (high - low + 1) - pc
        elif op == 0xab:  # lookupswitch
            p = (pc + 4) & ~3
            default, npairs = s4(p), s4(p + 4)
            pairs = [(s4(p + 8 + 8 * k), pc + s4(p + 12 + 8 * k)) for k in range(npairs)]
            args, ln = (pc + default, pairs), p + 8 + 8 * npairs - pc
        else:
            args, ln = (), 1
        out.append((pc, op, args, ln))
        pc += ln
    return out
