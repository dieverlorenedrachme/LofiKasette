#!/usr/bin/env python3
"""Lofi Kassette – erzeugt die Instrumenten-Samples der App.

Alle Klänge entstehen hier aus physikalisch inspirierten Modellen (keine fremden Aufnahmen):
  Klavier/Filzklavier  additive Synthese mit Saiten-Inharmonizität, 3 Saiten, Hammer, Resonanzboden
  Rhodes               Stimmzunge + nichtlinearer Tonabnehmer ("Bark" bei hartem Anschlag)
  Gitarre, Kontrabass, Harfe   Karplus-Strong mit Allpass-Feinstimmung, Zupfposition, Korpus
  Vibraphon, Marimba, Spieluhr, Kalimba   Modalsynthese mit den Teiltonverhältnissen der Klangkörper
  Streicher            Ensemble aus 7 Stimmen mit Vibrato, Korpus-Formanten, nahtlose Schleife

Ausgabe: app/assets/js/samples/<id>.js (Opus in Ogg, Base64), wird von der App bei Bedarf geladen.
Benötigt: numpy, scipy, ffmpeg mit libopus.  Aufruf: python3 offline-build/make_samples.py [id ...]
"""
import base64, json, os, subprocess, sys, tempfile
import numpy as np
from scipy import signal as sg

SR = 48000
OUT = os.path.join(os.path.dirname(__file__), '..', 'app', 'assets', 'js', 'samples')
GAP = 0.12  # Stille zwischen den Tönen in der Sammeldatei


def mtof(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def rng(seed):
    return np.random.default_rng(seed)


def attack(n, ms):
    k = max(1, int(ms * SR / 1000))
    e = np.ones(n)
    e[:k] = 0.5 - 0.5 * np.cos(np.linspace(0, np.pi, k))
    return e


def fade_out(x, ms=60):
    k = min(len(x), int(ms * SR / 1000))
    x[-k:] *= np.cos(np.linspace(0, np.pi / 2, k)) ** 2
    return x


def body_ir(modes, length, seed, direct=1.0):
    """Resonanzkörper als Summe gedämpfter Eigenschwingungen: (Frequenz, Bandbreite Hz, Amplitude)."""
    t = np.arange(int(length * SR)) / SR
    r = rng(seed)
    ir = np.zeros_like(t)
    ir[0] = direct
    for f, bw, a in modes:
        ir += a * np.exp(-np.pi * bw * t) * np.sin(2 * np.pi * f * t + r.uniform(0, 0.3))
    return ir


def random_modes(seed, n, lo, hi, bw, amp, tilt=0.6):
    r = rng(seed)
    fs = np.exp(r.uniform(np.log(lo), np.log(hi), n))
    return [(f, r.uniform(*bw), amp * r.uniform(0.3, 1.0) * (lo / f) ** tilt) for f in fs]


def convolve_body(x, ir, wet):
    y = sg.fftconvolve(x, ir)[:len(x)]
    y *= np.sqrt(np.mean(x ** 2) / (np.mean(y ** 2) + 1e-20))
    return x * (1 - wet) + y * wet


def lowpass(x, f, order=2):
    b, a = sg.butter(order, min(f, SR * 0.45) / (SR / 2), 'low')
    return sg.lfilter(b, a, x)


def highpass(x, f, order=2):
    b, a = sg.butter(order, f / (SR / 2), 'high')
    return sg.lfilter(b, a, x)


def peak(x, f, gain_db, q):
    A = 10 ** (gain_db / 40)
    w = 2 * np.pi * f / SR
    al = np.sin(w) / (2 * q)
    b = [1 + al * A, -2 * np.cos(w), 1 - al * A]
    a = [1 + al / A, -2 * np.cos(w), 1 - al / A]
    return sg.lfilter(b, a, x)


# ---------------------------------------------------------------- Klavier
SOUNDBOARD = body_ir(random_modes(11, 46, 70, 4200, (8, 35), 0.5), 0.35, 12)


def piano(m, felt=False):
    f0 = mtof(m)
    dur = float(np.clip(5.2 - (m - 40) * 0.055, 1.8, 5.0)) * (1.15 if felt else 1.0)
    n = int(dur * SR)
    t = np.arange(n) / SR
    r = rng(1000 + m + (500 if felt else 0))
    B = 7e-5 * 2 ** ((m - 60) / 18) + (2.5e-4 if m < 40 else 0)
    tau = float(np.clip(0.75 * (261.6 / f0) ** 0.62, 0.12, 3.5))
    p = 2.3 if felt else 1.25
    roll = 1900.0 if felt else 8500.0
    x0 = 1 / 7.3
    y = np.zeros(n)
    strings = 1 if m < 34 else 2 if m < 46 else 3
    det = [0.0, 0.85, -0.7][:strings]
    kmax = int(min(64, 17500 / f0))
    for k in range(1, kmax + 1):
        fk = k * f0 * np.sqrt(1 + B * k * k)
        if fk > 17500:
            break
        a = abs(np.sin(np.pi * k * x0)) / k ** p * np.exp(-fk / roll)
        if a < 1e-5:
            continue
        tk = tau / (1 + (fk / 1300) ** 1.25)
        env = 0.68 * np.exp(-t / tk) + 0.32 * np.exp(-t / (tk * 4.2))
        part = np.zeros(n)
        for d in det:
            part += np.sin(2 * np.pi * fk * 2 ** (d * r.uniform(0.6, 1.3) / 1200) * t + r.uniform(0, 2 * np.pi))
        y += a * env * part / strings
    y *= attack(n, 1.2 if not felt else 3.5)
    # Hammer: kurzer Filzanschlag und dumpfes Klopfen des Resonanzbodens
    k = int(0.012 * SR)
    ham = r.standard_normal(k) * np.exp(-np.arange(k) / (0.0025 * SR))
    ham = lowpass(ham, 1100 if felt else 2600)
    thump = np.zeros(n)
    thump[:k] = ham * (0.09 if felt else 0.04)
    tt = t[:int(0.15 * SR)]
    knock = sum(np.sin(2 * np.pi * fq * tt) * np.exp(-tt / 0.035) for fq in (95, 150, 230)) / 3
    thump[:len(knock)] += knock * (0.05 if felt else 0.025)
    if felt:  # Mechanik-Geräusch des Filzklaviers
        k2 = int(0.05 * SR)
        mech = lowpass(highpass(r.standard_normal(k2), 350), 1600) * np.exp(-np.arange(k2) / (0.012 * SR))
        thump[:k2] += mech * 0.03
    y = y / (np.max(np.abs(y)) + 1e-9) + thump * 2
    y = convolve_body(y, SOUNDBOARD, 0.32)
    if felt:
        y = lowpass(y, 3200)
    return fade_out(y, 80)


# ---------------------------------------------------------------- Rhodes
def rhodes(m):
    f0 = mtof(m)
    dur = float(np.clip(4.6 - (m - 40) * 0.05, 1.6, 4.4))
    n = int(dur * SR)
    t = np.arange(n) / SR
    r = rng(2000 + m)
    tau = float(np.clip(1.6 * (261.6 / f0) ** 0.55, 0.45, 3.2))
    x = np.sin(2 * np.pi * f0 * t) * np.exp(-t / tau)
    x += 0.07 * np.sin(2 * np.pi * 2 * f0 * t + 0.4) * np.exp(-t / (tau * 0.45))
    bell = 6.76 if m < 60 else 5.9
    x += 0.32 * np.sin(2 * np.pi * f0 * bell * t) * np.exp(-t / (0.045 if m < 72 else 0.03))
    x *= attack(n, 0.8)
    drive = 1.15 if m < 55 else 0.95
    u = x * drive
    y = u + 0.42 * u ** 2 - 0.12 * u ** 3        # asymmetrischer Tonabnehmer: Obertöne je nach Lautstärke
    y = highpass(y, 28)
    y = lowpass(y, 9000)
    k = int(0.004 * SR)
    y[:k] += lowpass(r.standard_normal(k), 3000) * np.exp(-np.arange(k) / (0.001 * SR)) * 0.03
    return fade_out(y, 80)


# ---------------------------------------------------------------- gezupfte Saiten
def ks(f0, dur, t60, excite, seed):
    """Karplus-Strong mit Allpass-Feinstimmung: y = x + g*avg(y[n-L]) über Allpass."""
    n = int(dur * SR)
    N = SR / f0
    L = int(N - 0.5 - 0.15)
    d = N - 0.5 - L
    c = (1 - d) / (1 + d)
    g = 0.001 ** (1 / (f0 * t60))
    a = np.zeros(L + 3)
    a[0] = 1
    a[1] += c
    a[L] -= g * 0.5 * c
    a[L + 1] -= g * (0.5 + 0.5 * c)
    a[L + 2] -= g * 0.5
    x = np.zeros(n)
    e = excite(L, rng(seed))
    x[:len(e)] = e
    return sg.lfilter([1, c], a, x)


def pluck_exc(beta, lp_hz, noise):
    """Zupfform: Dreiecks-Auslenkung mit Spitze an der Zupfposition (Obertöne ~1/k²) plus etwas Fingergeräusch."""
    def make(L, r):
        x = np.arange(L) / L
        e = np.where(x < beta, x / beta, (1 - x) / (1 - beta))
        e = e - np.mean(e)
        nz = lowpass(r.uniform(-1, 1, L), lp_hz, 2)
        e = e + noise * nz / (np.max(np.abs(nz)) + 1e-9)
        return e - np.mean(e)
    return make


GUITAR_BODY = body_ir([(98, 12, 0.9), (205, 18, 0.7), (390, 25, 0.45), (560, 30, 0.35), (820, 40, 0.25), (1150, 55, 0.2)]
                      + random_modes(31, 12, 1300, 3500, (60, 150), 0.04), 0.25, 32)
BASS_BODY = body_ir([(62, 8, 1.0), (118, 12, 0.8), (190, 20, 0.5), (300, 30, 0.3), (520, 45, 0.2)], 0.3, 33)
HARP_BODY = body_ir(random_modes(34, 24, 120, 3000, (20, 60), 0.4), 0.3, 35)


def guitar(m):
    f0 = mtof(m)
    t60 = float(np.clip(3.4 * (196 / f0) ** 0.5, 0.9, 4.0))
    dur = min(3.8, t60 * 1.1)
    y = ks(f0, dur, t60, pluck_exc(0.17, 2200, 0.12), 3000 + m)
    y = convolve_body(y, GUITAR_BODY, 0.45)
    y = lowpass(highpass(y, 70), 5200)
    return fade_out(y * attack(len(y), 1.0), 60)


def upright(m):
    f0 = mtof(m)
    t60 = float(np.clip(1.9 * (55 / f0) ** 0.3, 1.0, 2.2))
    y = ks(f0, 2.6, t60, pluck_exc(0.2, 1400, 0.1), 4000 + m)
    y = convolve_body(y, BASS_BODY, 0.5)
    r = rng(4100 + m)
    k = int(0.02 * SR)
    y[:k] += lowpass(r.standard_normal(k), 1500) * np.exp(-np.arange(k) / (0.004 * SR)) * 0.02 * np.max(np.abs(y))
    y = lowpass(highpass(y, 30), 3000)
    return fade_out(y * attack(len(y), 2.0), 60)


def harp(m):
    f0 = mtof(m)
    t60 = float(np.clip(5.5 * (130 / f0) ** 0.55, 1.3, 6.0))
    dur = min(4.2, t60 * 0.9)
    y = ks(f0, dur, t60, pluck_exc(0.35, 3500, 0.08), 5000 + m)
    y = convolve_body(y, HARP_BODY, 0.35)
    y = lowpass(highpass(y, 60), 7000)
    return fade_out(y * attack(len(y), 1.5), 80)


# ---------------------------------------------------------------- Klangstäbe, Zungen
def modal(m, ratios, amps, tau0, taus, dur, seed, mallet_hz, mallet_amp, detune=0.0):
    f0 = mtof(m)
    n = int(dur * SR)
    t = np.arange(n) / SR
    r = rng(seed)
    y = np.zeros(n)
    for ra, a, tf in zip(ratios, amps, taus):
        f = f0 * ra
        if f > 19000:
            continue
        y += a * np.sin(2 * np.pi * f * t + r.uniform(0, 1)) * np.exp(-t / (tau0 * tf))
    if detune:
        y += 0.18 * np.sin(2 * np.pi * f0 * 2 ** (detune / 1200) * t) * np.exp(-t / (tau0 * 0.8))
    y *= attack(n, 0.7)
    k = int(0.01 * SR)
    y[:k] += lowpass(r.standard_normal(k), mallet_hz) * np.exp(-np.arange(k) / (0.0015 * SR)) * mallet_amp
    return y


def vibes(m):
    f0 = mtof(m)
    tau = float(np.clip(1.4 * (261.6 / f0) ** 0.35, 0.6, 2.2))
    y = modal(m, [1, 3.98, 9.9], [1, 0.1, 0.025], tau, [1, 0.3, 0.1], min(3.6, tau * 3.2), 6000 + m, 2500, 0.05)
    return fade_out(lowpass(y, 9000), 80)


def marimba(m):
    f0 = mtof(m)
    tau = float(np.clip(0.55 * (220 / f0) ** 0.6, 0.12, 1.1))
    y = modal(m, [1, 3.93, 9.2], [1, 0.22, 0.05], tau, [1, 0.25, 0.08], min(2.5, tau * 4 + 0.2), 7000 + m, 1400, 0.12)
    y += np.sin(2 * np.pi * f0 * np.arange(len(y)) / SR) * np.exp(-np.arange(len(y)) / SR / (tau * 1.5)) * 0.25  # Resonanzrohr
    return fade_out(y, 60)


def musicbox(m):
    f0 = mtof(m)
    tau = float(np.clip(0.9 * (523 / f0) ** 0.3, 0.45, 1.4))
    y = modal(m, [1, 6.27, 17.55], [1, 0.22, 0.05], tau, [1, 0.18, 0.05], min(2.8, tau * 3.5), 8000 + m, 5000, 0.08, detune=4.0)
    return fade_out(highpass(y, 180), 60)


KALIMBA_BOX = body_ir([(240, 20, 0.9), (520, 35, 0.4), (910, 50, 0.3)], 0.2, 36)


def kalimba(m):
    f0 = mtof(m)
    tau = float(np.clip(0.7 * (392 / f0) ** 0.3, 0.4, 1.2))
    y = modal(m, [1, 5.7, 12.4], [1, 0.14, 0.03], tau, [1, 0.12, 0.04], min(2.6, tau * 3.5), 9000 + m, 1800, 0.1)
    y = convolve_body(y, KALIMBA_BOX, 0.3)
    return fade_out(highpass(y, 120), 60)


# ---------------------------------------------------------------- Streicher (Schleife)
def strings(m):
    f0 = mtof(m)
    dur = 4.6
    n = int(dur * SR)
    t = np.arange(n) / SR
    r = rng(10000 + m)
    y = np.zeros(n)
    kmax = int(min(40, 9000 / f0))
    spread = np.linspace(-8, 8, 7) + r.uniform(-1, 1, 7)
    spread -= spread.mean()
    for v in range(7):
        cents = spread[v]
        vib_rate = r.uniform(4.6, 5.8)
        vib = 0.0022 * np.minimum(1, t / 0.6) * np.sin(2 * np.pi * vib_rate * t + r.uniform(0, 6))
        drift = 0.0008 * np.sin(2 * np.pi * r.uniform(0.1, 0.3) * t + r.uniform(0, 6))
        fi = f0 * 2 ** (cents / 1200) * (1 + vib + drift)
        ph = 2 * np.pi * np.cumsum(fi) / SR + r.uniform(0, 6)
        for k in range(1, kmax + 1):
            y += np.sin(k * ph) / k * np.exp(-k * f0 / 7000)
    y = highpass(y, 90)
    y = peak(y, 280, 4, 1.2)
    y = peak(y, 1050, 3, 1.4)
    y = peak(y, 2900, 2, 1.8)
    y = lowpass(y, 6500)
    y *= np.minimum(1, t / 0.28) ** 1.5
    # nahtlose Schleife 1,4 s … 4,4 s
    l0, l1, x = int(1.4 * SR), int(4.4 * SR), int(0.5 * SR)
    w = np.sin(np.linspace(0, np.pi / 2, x)) ** 2
    y[l1 - x:l1] = y[l1 - x:l1] * (1 - w) + y[l0 - x:l0] * w
    y = y[:l1]
    return y, (1.4, 4.4)


INSTRUMENTS = {
    # id: (Funktion, Töne, Schleife?)
    'piano': (lambda m: piano(m), range(36, 97, 3), False),
    'felt': (lambda m: piano(m, felt=True), range(36, 91, 3), False),
    'rhodes': (rhodes, range(36, 91, 3), False),
    'guitar': (guitar, range(40, 86, 3), False),
    'upright': (upright, range(28, 62, 3), False),
    'harp': (harp, range(40, 97, 3), False),
    'vibes': (vibes, range(53, 92, 3), False),
    'marimba': (marimba, range(48, 92, 3), False),
    'musicbox': (musicbox, range(60, 100, 3), False),
    'kalimba': (kalimba, range(55, 93, 3), False),
    'strings': (strings, range(43, 88, 3), True),
}


def encode(inst):
    fn, notes, looped = INSTRUMENTS[inst]
    parts, meta = [], []
    pos = 0.0
    for m in notes:
        res = fn(m)
        y, loop = (res if looped else (res, None))
        y = np.asarray(y, dtype=np.float64)
        # gleiche Anfangslautheit (erste 0,3 s), Spitzen ≤ 0,95
        rms = np.sqrt(np.mean(y[:int(0.3 * SR)] ** 2)) + 1e-9
        y *= 0.2 / rms
        pk = np.max(np.abs(y))
        if pk > 0.95:
            y *= 0.95 / pk
        if not loop:  # Ausklang ab -55 dB abschneiden (im Mix unhörbar, spart Platz)
            w = int(0.02 * SR)
            env = np.sqrt(np.convolve(y ** 2, np.ones(w) / w, 'same'))
            above = np.nonzero(env > env.max() * 10 ** (-55 / 20))[0]
            end = min(len(y), int(above[-1]) + w) if len(above) else len(y)
            y = fade_out(y[:max(end, int(0.3 * SR))].copy(), 40)
        meta.append({'m': m, 's': round(pos, 5), 'l': round(len(y) / SR, 5), **({'loop': loop} if loop else {})})
        parts.append(y)
        parts.append(np.zeros(int(GAP * SR)))
        pos += len(y) / SR + GAP
    audio = np.concatenate(parts).astype(np.float32)
    with tempfile.TemporaryDirectory() as d:
        raw, ogg = os.path.join(d, 'a.raw'), os.path.join(d, 'a.ogg')
        audio.tofile(raw)
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'f32le', '-ar', str(SR), '-ac', '1', '-i', raw,
                        '-c:a', 'libopus', '-b:a', '80k', '-application', 'audio', '-frame_duration', '20', ogg], check=True)
        data = open(ogg, 'rb').read()
    os.makedirs(OUT, exist_ok=True)
    js = ('/* Lofi Kassette – Instrumenten-Samples "%s", erzeugt von offline-build/make_samples.py */\n'
          "LK.SampleBank.add('%s', %s, '%s');\n") % (inst, inst, json.dumps({'rate': SR, 'notes': meta}, separators=(',', ':')),
                                                        base64.b64encode(data).decode())
    open(os.path.join(OUT, inst + '.js'), 'w').write(js)
    return len(data), len(meta), audio


if __name__ == '__main__':
    todo = sys.argv[1:] or list(INSTRUMENTS)
    total = 0
    for inst in todo:
        size, count, _ = encode(inst)
        total += size
        print('%-9s %2d Töne  %6.0f KB' % (inst, count, size / 1024))
    print('gesamt %.2f MB' % (total / 1048576))
