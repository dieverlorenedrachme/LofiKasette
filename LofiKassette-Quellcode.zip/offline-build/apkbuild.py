#!/usr/bin/env python3
"""
apkbuild – baut eine installierbare, signierte APK ohne Android-SDK:
  * AndroidManifest.xml und Icon-XML im Android-Binär-XML-Format
  * resources.arsc mit den Icon-Ressourcen
  * ZIP mit 4-Byte-Ausrichtung unkomprimierter Einträge (wie zipalign)
  * APK Signature Scheme v2 (RSA 2048 / SHA-256) mit einem PKCS#12-Schlüssel
"""
import hashlib
import os
import struct
import sys
import zlib

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.serialization import pkcs12

ANDROID_NS = 'http://schemas.android.com/apk/res/android'
# Öffentliche, eingefrorene Attribut-IDs des Android-Frameworks (android.R.attr)
ATTR = {
    'label': 0x01010001, 'icon': 0x01010002, 'name': 0x01010003, 'exported': 0x01010010,
    'screenOrientation': 0x0101001e, 'configChanges': 0x0101001f, 'drawable': 0x01010199,
    'minSdkVersion': 0x0101020c, 'versionCode': 0x0101021b, 'versionName': 0x0101021c,
    'targetSdkVersion': 0x01010270, 'allowBackup': 0x01010280,
}
T_REF, T_STRING, T_DEC, T_HEX, T_BOOL = 0x01, 0x03, 0x10, 0x11, 0x12


# ---------------- Stringpools ----------------

def string_pool(strings, utf8):
    """ResStringPool-Chunk"""
    data, offs = bytearray(), []
    for s in strings:
        offs.append(len(data))
        if utf8:
            b = s.encode('utf-8')
            for n in (len(s), len(b)):
                data += bytes([n]) if n < 0x80 else bytes([0x80 | (n >> 8), n & 0xFF])
            data += b + b'\0'
        else:
            u = s.encode('utf-16-le')
            n = len(u) // 2
            data += struct.pack('<H', n) if n < 0x8000 else struct.pack('<HH', 0x8000 | (n >> 16), n & 0xFFFF)
            data += u + b'\0\0'
    while len(data) % 4:
        data += b'\0'
    hdr = 28
    strings_start = hdr + 4 * len(strings)
    size = strings_start + len(data)
    out = struct.pack('<HHIIIIII', 0x0001, hdr, size, len(strings), 0, 0x100 if utf8 else 0, strings_start, 0)
    out += b''.join(struct.pack('<I', o) for o in offs) + data
    return out


# ---------------- Binär-XML ----------------

class Elem:
    def __init__(self, tag, attrs=None, children=None):
        self.tag, self.attrs, self.children = tag, attrs or [], children or []


def axml(root):
    """attrs: Liste (ns, name, typ, wert) mit ns in (None, 'android')"""
    # Attributnamen mit Ressourcen-ID zuerst (Reihenfolge = Ressourcen-Map)
    res_names = []
    def walk(e):
        for (ns, name, t, v) in e.attrs:
            if ns == 'android' and name not in res_names:
                res_names.append(name)
        for c in e.children:
            walk(c)
    walk(root)
    res_names.sort(key=lambda n: ATTR[n])
    strings = list(res_names)
    def S(s):
        if s not in strings:
            strings.append(s)
        return strings.index(s)
    S('android'); S(ANDROID_NS)
    def collect(e):
        S(e.tag)
        for (ns, name, t, v) in e.attrs:
            if ns is None:
                S(name)
            if t == T_STRING:
                S(v)
        for c in e.children:
            collect(c)
    collect(root)

    body = bytearray()
    line = [1]
    def node(tp, extra):
        chunk = struct.pack('<HHI', tp, 16, 16 + len(extra)) + struct.pack('<II', line[0], 0xFFFFFFFF) + extra
        line[0] += 1
        return chunk
    body += node(0x0100, struct.pack('<II', S('android'), S(ANDROID_NS)))
    def emit(e):
        attrs = []
        for (ns, name, t, v) in e.attrs:
            nsi = S(ANDROID_NS) if ns == 'android' else 0xFFFFFFFF
            key = (0, ATTR[name]) if ns == 'android' else (1, name)
            if t == T_STRING:
                raw, data = S(v), S(v)
            else:
                raw, data = 0xFFFFFFFF, v & 0xFFFFFFFF
            attrs.append((key, struct.pack('<IIIHBBI', nsi, S(name), raw, 8, 0, t, data)))
        attrs.sort(key=lambda a: a[0])  # nach Ressourcen-ID sortiert (vom Framework vorausgesetzt)
        ext = struct.pack('<IIHHHHHH', 0xFFFFFFFF, S(e.tag), 20, 20, len(attrs), 0, 0, 0) + b''.join(a[1] for a in attrs)
        body.extend(node(0x0102, ext))
        for c in e.children:
            emit(c)
        body.extend(node(0x0103, struct.pack('<II', 0xFFFFFFFF, S(e.tag))))
    emit(root)
    body += node(0x0101, struct.pack('<II', S('android'), S(ANDROID_NS)))
    pool = string_pool(strings, utf8=False)
    resmap = struct.pack('<HHI', 0x0180, 8, 8 + 4 * len(res_names)) + b''.join(struct.pack('<I', ATTR[n]) for n in res_names)
    total = 8 + len(pool) + len(resmap) + len(body)
    return struct.pack('<HHI', 0x0003, 8, total) + pool + resmap + bytes(body)


# ---------------- resources.arsc ----------------

def arsc(package, entries):
    """entries: Liste (Name, Dateipfad) – alle im Typ 'drawable', Konfiguration nodpi"""
    values = string_pool([p for _, p in entries], utf8=True)
    type_pool = string_pool(['drawable'], utf8=True)
    key_pool = string_pool([n for n, _ in entries], utf8=True)
    n = len(entries)
    spec = struct.pack('<HHIBBHI', 0x0202, 16, 16 + 4 * n, 1, 0, 0, n) + b'\0' * (4 * n)
    config = bytearray(64)
    struct.pack_into('<I', config, 0, 64)
    struct.pack_into('<H', config, 14, 0xFFFF)  # density = nodpi
    hdr = 20 + 64
    entries_start = hdr + 4 * n
    ebytes, offs = bytearray(), []
    for i in range(n):
        offs.append(len(ebytes))
        ebytes += struct.pack('<HHI', 8, 0, i) + struct.pack('<HBBI', 8, 0, T_STRING, i)
    tchunk = struct.pack('<HHIBBHII', 0x0201, hdr, entries_start + len(ebytes), 1, 0, 0, n, entries_start) + bytes(config)
    tchunk += b''.join(struct.pack('<I', o) for o in offs) + ebytes
    name16 = package.encode('utf-16-le')[:254].ljust(256, b'\0')
    phdr = 288
    type_off = phdr
    key_off = phdr + len(type_pool)
    pbody = type_pool + key_pool + spec + tchunk
    pchunk = struct.pack('<HHII', 0x0200, phdr, phdr + len(pbody), 0x7f) + name16 + struct.pack('<IIIII', type_off, 1, key_off, n, 0) + pbody
    total = 12 + len(values) + len(pchunk)
    return struct.pack('<HHII', 0x0002, 12, total, 1) + values + pchunk


# ---------------- ZIP ----------------

DOS_TIME, DOS_DATE = 0, (1 << 9) | (1 << 5) | 1  # 01.01.1981


def build_zip(files):
    """files: Liste (Name, Bytes, komprimieren?) -> ZIP-Bytes; unkomprimierte Daten 4-Byte-ausgerichtet"""
    out, central = bytearray(), bytearray()
    for name, data, compress in files:
        nb = name.encode('utf-8')
        crc = zlib.crc32(data) & 0xFFFFFFFF
        if compress:
            co = zlib.compressobj(9, zlib.DEFLATED, -15)
            payload = co.compress(data) + co.flush()
            method = 8
        else:
            payload, method = data, 0
        offset = len(out)
        extra = b''
        if method == 0:
            pad = (4 - (offset + 30 + len(nb)) % 4) % 4
            extra = b'\0' * pad
        out += struct.pack('<IHHHHHIIIHH', 0x04034b50, 20, 0x0800 if any(c > 127 for c in nb) else 0, method,
                           DOS_TIME, DOS_DATE, crc, len(payload), len(data), len(nb), len(extra)) + nb + extra
        if method == 0:
            assert len(out) % 4 == 0
        out += payload
        central += struct.pack('<IHHHHHHIIIHHHHHII', 0x02014b50, 20, 20, 0x0800 if any(c > 127 for c in nb) else 0, method,
                               DOS_TIME, DOS_DATE, crc, len(payload), len(data), len(nb), 0, 0, 0, 0, 0, offset) + nb
    cd_off = len(out)
    eocd = struct.pack('<IHHHHIIH', 0x06054b50, 0, 0, len(files), len(files), len(central), cd_off, 0)
    return bytes(out), bytes(central), eocd


# ---------------- APK-Signatur v2 ----------------

def lp(b):
    return struct.pack('<I', len(b)) + b


def chunk_digest(sections):
    digests = []
    for sec in sections:
        for i in range(0, len(sec), 1 << 20):
            c = sec[i:i + (1 << 20)]
            digests.append(hashlib.sha256(b'\xa5' + struct.pack('<I', len(c)) + c).digest())
    return hashlib.sha256(b'\x5a' + struct.pack('<I', len(digests)) + b''.join(digests)).digest()


def sign_v2(entries, central, eocd, key, cert):
    digest = chunk_digest([entries, central, eocd])
    cert_der = cert.public_bytes(serialization.Encoding.DER)
    signed_data = lp(lp(struct.pack('<I', 0x0103) + lp(digest))) + lp(lp(cert_der)) + lp(b'')
    sig = key.sign(signed_data, padding.PKCS1v15(), hashes.SHA256())
    pub = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    signer = lp(signed_data) + lp(lp(struct.pack('<I', 0x0103) + lp(sig))) + lp(pub)
    v2 = lp(lp(signer))
    pair = struct.pack('<QI', 4 + len(v2), 0x7109871a) + v2
    size = len(pair) + 8 + 16
    block = struct.pack('<Q', size) + pair + struct.pack('<Q', size) + b'APK Sig Block 42'
    new_eocd = bytearray(eocd)
    struct.pack_into('<I', new_eocd, 16, len(entries) + len(block))
    return entries + block + central + bytes(new_eocd)


def load_key(p12_path, password):
    with open(p12_path, 'rb') as f:
        key, cert, _ = pkcs12.load_key_and_certificates(f.read(), password.encode())
    return key, cert


# ---------------- Zusammenbau ----------------
import xml.etree.ElementTree as ET

ANDROID_KEY = '{%s}' % ANDROID_NS
CONFIG_FLAGS = {'mcc': 0x1, 'mnc': 0x2, 'locale': 0x4, 'touchscreen': 0x8, 'keyboard': 0x10, 'keyboardHidden': 0x20,
                'navigation': 0x40, 'orientation': 0x80, 'screenLayout': 0x100, 'uiMode': 0x200, 'screenSize': 0x400,
                'smallestScreenSize': 0x800, 'density': 0x1000, 'layoutDirection': 0x2000, 'fontScale': 0x40000000}
ORIENTATION = {'unspecified': -1, 'landscape': 0, 'portrait': 1, 'user': 2, 'behind': 3, 'sensor': 4, 'nosensor': 5}
KIND = {'versionCode': 'int', 'minSdkVersion': 'int', 'targetSdkVersion': 'int', 'versionName': 'str', 'label': 'str',
        'name': 'str', 'icon': 'ref', 'drawable': 'ref', 'allowBackup': 'bool', 'exported': 'bool',
        'screenOrientation': 'orient', 'configChanges': 'flags'}


def from_xml(path, rid):
    """Text-XML -> Elem-Baum; android:-Attribute werden typisiert wie bei aapt2."""
    def conv(node):
        attrs = []
        for k, v in node.attrib.items():
            if not k.startswith(ANDROID_KEY):
                attrs.append((None, k, T_STRING, v))
                continue
            name = k[len(ANDROID_KEY):]
            kind = KIND.get(name)
            if name not in ATTR or kind is None:
                raise SystemExit('Attribut android:%s wird vom Offline-Build nicht unterstützt' % name)
            if kind == 'int':
                attrs.append(('android', name, T_DEC, int(v)))
            elif kind == 'str':
                attrs.append(('android', name, T_STRING, v))
            elif kind == 'bool':
                attrs.append(('android', name, T_BOOL, 0xFFFFFFFF if v == 'true' else 0))
            elif kind == 'orient':
                attrs.append(('android', name, T_DEC, ORIENTATION[v]))
            elif kind == 'flags':
                val = 0
                for f in v.split('|'):
                    val |= CONFIG_FLAGS[f.strip()]
                attrs.append(('android', name, T_HEX, val))
            else:
                if not v.startswith('@drawable/'):
                    raise SystemExit('Nur @drawable/-Verweise unterstützt: ' + v)
                attrs.append(('android', name, T_REF, rid[v[len('@drawable/'):]]))
        return Elem(node.tag, attrs, [conv(c) for c in node])
    return conv(ET.parse(path).getroot())


def build(app_dir, dex_path, out_path, p12, password):
    res_dir = os.path.join(app_dir, 'res')
    pngs = sorted(f[:-4] for f in os.listdir(os.path.join(res_dir, 'drawable-nodpi')) if f.endswith('.png'))
    xmls = sorted(f[:-4] for f in os.listdir(os.path.join(res_dir, 'drawable-anydpi-v26')) if f.endswith('.xml'))
    res = sorted(pngs + xmls)
    paths = {n: 'res/drawable-nodpi/%s.%s' % (n, 'xml' if n in xmls else 'png') for n in res}
    rid = {n: 0x7f010000 + i for i, n in enumerate(res)}
    man_tree = from_xml(os.path.join(app_dir, 'AndroidManifest.xml'), rid)
    package = [a[3] for a in man_tree.attrs if a[1] == 'package'][0]
    files = [('AndroidManifest.xml', axml(man_tree), True),
             ('classes.dex', open(dex_path, 'rb').read(), True),
             ('resources.arsc', arsc(package, [(n, paths[n]) for n in res]), False)]
    for n in xmls:
        files.append((paths[n], axml(from_xml(os.path.join(res_dir, 'drawable-anydpi-v26', n + '.xml'), rid)), True))
    for n in pngs:
        files.append((paths[n], open(os.path.join(res_dir, 'drawable-nodpi', n + '.png'), 'rb').read(), False))
    assets = []
    for root, _, names in os.walk(os.path.join(app_dir, 'assets')):
        for nm in names:
            full = os.path.join(root, nm)
            assets.append(('assets/' + os.path.relpath(full, os.path.join(app_dir, 'assets')).replace(os.sep, '/'), full))
    for rel, full in sorted(assets):
        files.append((rel, open(full, 'rb').read(), True))
    entries, central, eocd = build_zip(files)
    key, cert = load_key(p12, password)
    apk = sign_v2(entries, central, eocd, key, cert)
    with open(out_path, 'wb') as f:
        f.write(apk)
    return apk


if __name__ == '__main__':
    if len(sys.argv) != 6:
        print('Aufruf: apkbuild.py app/ classes.dex ausgabe.apk schluessel.p12 passwort')
        sys.exit(2)
    apk = build(*sys.argv[1:6])
    print('%s: %.2f MB' % (sys.argv[3], len(apk) / 1e6))
