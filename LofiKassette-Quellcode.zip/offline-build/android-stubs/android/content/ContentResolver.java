package android.content;
import android.net.Uri;
public abstract class ContentResolver {
    public final Uri insert(Uri url, ContentValues values) { return null; }
    public final java.io.OutputStream openOutputStream(Uri uri) throws java.io.FileNotFoundException { return null; }
    public final int update(Uri uri, ContentValues values, String where, String[] selectionArgs) { return 0; }
    public final int delete(Uri url, String where, String[] selectionArgs) { return 0; }
}
