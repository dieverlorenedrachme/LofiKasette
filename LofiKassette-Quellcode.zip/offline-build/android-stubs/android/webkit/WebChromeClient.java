package android.webkit;
public class WebChromeClient {
    public WebChromeClient() {}
    public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) { return false; }
    public boolean onShowFileChooser(WebView webView, ValueCallback<android.net.Uri[]> filePathCallback, FileChooserParams fileChooserParams) { return false; }
    public static abstract class FileChooserParams {
        public static android.net.Uri[] parseResult(int resultCode, android.content.Intent data) { return null; }
        public abstract android.content.Intent createIntent();
    }
}
