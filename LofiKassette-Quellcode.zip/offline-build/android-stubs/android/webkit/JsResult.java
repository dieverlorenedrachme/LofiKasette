package android.webkit;
public class JsResult {}
