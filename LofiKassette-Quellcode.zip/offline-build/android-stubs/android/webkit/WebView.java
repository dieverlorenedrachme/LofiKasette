package android.webkit;
public class WebView extends android.view.View {
    public WebView(android.content.Context context) {}
    public WebSettings getSettings() { return null; }
    public void setWebChromeClient(WebChromeClient client) {}
    public void loadUrl(String url) {}
    public void evaluateJavascript(String script, ValueCallback<String> resultCallback) {}
    public void setBackgroundColor(int color) {}
    public void setOverScrollMode(int mode) {}
}
