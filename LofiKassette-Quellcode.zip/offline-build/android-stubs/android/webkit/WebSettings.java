package android.webkit;
public abstract class WebSettings {
    public abstract void setJavaScriptEnabled(boolean flag);
    public abstract void setDomStorageEnabled(boolean flag);
    public abstract void setMediaPlaybackRequiresUserGesture(boolean require);
    public abstract void setTextZoom(int textZoom);
    public abstract void setSupportZoom(boolean support);
}
