package android.view;
public class View {
    public void setSystemUiVisibility(int visibility) {}
    public void setBackgroundColor(int color) {}
    public void setOverScrollMode(int mode) {}
}
