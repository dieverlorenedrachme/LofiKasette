package android.view;
public abstract class Window {
    public static final int FEATURE_NO_TITLE = 1;
    public void addFlags(int flags) {}
    public void clearFlags(int flags) {}
    public abstract void setStatusBarColor(int color);
    public abstract void setNavigationBarColor(int color);
    public abstract void setBackgroundDrawable(android.graphics.drawable.Drawable drawable);
    public abstract View getDecorView();
}
