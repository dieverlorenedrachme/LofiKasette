package android.app;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
public class Activity extends android.content.Context {
    public Activity() {}
    protected void onCreate(Bundle savedInstanceState) {}
    protected void onPause() {}
    protected void onDestroy() {}
    public void onBackPressed() {}
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {}
    public final boolean requestWindowFeature(int featureId) { return false; }
    public Window getWindow() { return null; }
    public void setContentView(View view) {}
    public void finish() {}
    public void startActivityForResult(Intent intent, int requestCode) {}
    public android.content.ContentResolver getContentResolver() { return null; }
}
