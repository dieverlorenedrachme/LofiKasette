#!/usr/bin/env python3
"""
dexcheck – liest eine DEX-Datei unabhängig vom Erzeuger ein und prüft sie:
  * Kopf, Prüfsumme (Adler-32), SHA-1-Signatur, Map-Liste, Ausrichtung
  * Sortierregeln der ID-Tabellen (wie der ART-Dateiverifizierer)
  * Disassembly aller Methoden
  * Datenfluss-Typprüfung der Register (angelehnt an den ART-Methodenverifizierer):
    Registerarten, Wide-Paare, nicht initialisierte Objekte, move-result-Regeln,
    Ausnahme-Handler, Feld- und Methodensignaturen.
Aufruf: dexcheck.py classes.dex [--dump]
"""
import hashlib
import struct
import sys
import zlib

FMT = {}


def _set(ops, name, fmt):
    for i, op in enumerate(ops):
        FMT[op] = (name[i] if isinstance(name, list) else name, fmt)


_set([0x00], 'nop', '10x')
_set([0x01, 0x02, 0x03], ['move', 'move/from16', 'move/16'], None)
FMT[0x01] = ('move', '12x'); FMT[0x02] = ('move/from16', '22x'); FMT[0x03] = ('move/16', '32x')
FMT[0x04] = ('move-wide', '12x'); FMT[0x05] = ('move-wide/from16', '22x'); FMT[0x06] = ('move-wide/16', '32x')
FMT[0x07] = ('move-object', '12x'); FMT[0x08] = ('move-object/from16', '22x'); FMT[0x09] = ('move-object/16', '32x')
FMT[0x0a] = ('move-result', '11x'); FMT[0x0b] = ('move-result-wide', '11x'); FMT[0x0c] = ('move-result-object', '11x')
FMT[0x0d] = ('move-exception', '11x')
FMT[0x0e] = ('return-void', '10x'); FMT[0x0f] = ('return', '11x'); FMT[0x10] = ('return-wide', '11x'); FMT[0x11] = ('return-object', '11x')
FMT[0x12] = ('const/4', '11n'); FMT[0x13] = ('const/16', '21s'); FMT[0x14] = ('const', '31i'); FMT[0x15] = ('const/high16', '21h')
FMT[0x16] = ('const-wide/16', '21s'); FMT[0x17] = ('const-wide/32', '31i'); FMT[0x18] = ('const-wide', '51l'); FMT[0x19] = ('const-wide/high16', '21h')
FMT[0x1a] = ('const-string', '21c'); FMT[0x1b] = ('const-string/jumbo', '31c'); FMT[0x1c] = ('const-class', '21c')
FMT[0x1d] = ('monitor-enter', '11x'); FMT[0x1e] = ('monitor-exit', '11x')
FMT[0x1f] = ('check-cast', '21c'); FMT[0x20] = ('instance-of', '22c'); FMT[0x21] = ('array-length', '12x')
FMT[0x22] = ('new-instance', '21c'); FMT[0x23] = ('new-array', '22c')
FMT[0x27] = ('throw', '11x'); FMT[0x28] = ('goto', '10t'); FMT[0x29] = ('goto/16', '20t'); FMT[0x2a] = ('goto/32', '30t')
for i, n in enumerate(['cmpl-float', 'cmpg-float', 'cmpl-double', 'cmpg-double', 'cmp-long']):
    FMT[0x2d + i] = (n, '23x')
for i, n in enumerate(['eq', 'ne', 'lt', 'ge', 'gt', 'le']):
    FMT[0x32 + i] = ('if-' + n, '22t')
    FMT[0x38 + i] = ('if-' + n + 'z', '21t')
AV = ['', '-wide', '-object', '-boolean', '-byte', '-char', '-short']
for i, v in enumerate(AV):
    FMT[0x44 + i] = ('aget' + v, '23x'); FMT[0x4b + i] = ('aput' + v, '23x')
    FMT[0x52 + i] = ('iget' + v, '22c'); FMT[0x59 + i] = ('iput' + v, '22c')
    FMT[0x60 + i] = ('sget' + v, '21c'); FMT[0x67 + i] = ('sput' + v, '21c')
for i, n in enumerate(['virtual', 'super', 'direct', 'static', 'interface']):
    FMT[0x6e + i] = ('invoke-' + n, '35c'); FMT[0x74 + i] = ('invoke-' + n + '/range', '3rc')
UN = ['neg-int', 'not-int', 'neg-long', 'not-long', 'neg-float', 'neg-double', 'int-to-long', 'int-to-float',
      'int-to-double', 'long-to-int', 'long-to-float', 'long-to-double', 'float-to-int', 'float-to-long',
      'float-to-double', 'double-to-int', 'double-to-long', 'double-to-float', 'int-to-byte', 'int-to-char', 'int-to-short']
for i, n in enumerate(UN):
    FMT[0x7b + i] = (n, '12x')
BIN = ['add', 'sub', 'mul', 'div', 'rem', 'and', 'or', 'xor', 'shl', 'shr', 'ushr']
BINT = []
for t, names in (('int', BIN), ('long', BIN), ('float', BIN[:5]), ('double', BIN[:5])):
    for n in names:
        BINT.append((n, t))
for i, (n, t) in enumerate(BINT):
    FMT[0x90 + i] = ('%s-%s' % (n, t), '23x')
    FMT[0xb0 + i] = ('%s-%s/2addr' % (n, t), '12x')
LIT16 = ['add', 'rsub', 'mul', 'div', 'rem', 'and', 'or', 'xor']
for i, n in enumerate(LIT16):
    FMT[0xd0 + i] = ('%s-int/lit16' % n, '22s')
for i, n in enumerate(LIT16 + ['shl', 'shr', 'ushr']):
    FMT[0xd8 + i] = ('%s-int/lit8' % n, '22b')
SIZE = {'10x': 1, '12x': 1, '11n': 1, '11x': 1, '10t': 1, '20t': 2, '22x': 2, '21t': 2, '21s': 2, '21h': 2,
        '21c': 2, '23x': 2, '22b': 2, '22t': 2, '22s': 2, '22c': 2, '32x': 3, '30t': 3, '31t': 3, '31i': 3,
        '31c': 3, '35c': 3, '3rc': 3, '51l': 5}


class Fail(Exception):
    pass


def uleb(d, p):
    v = s = 0
    while True:
        b = d[p]; p += 1
        v |= (b & 0x7F) << s; s += 7
        if not b & 0x80:
            return v, p


def sleb(d, p):
    v = s = 0
    while True:
        b = d[p]; p += 1
        v |= (b & 0x7F) << s; s += 7
        if not b & 0x80:
            if b & 0x40:
                v -= 1 << s
            return v, p


def mutf8(d, p, n):
    units = []
    while len(units) < n:
        c = d[p]
        if c == 0:
            raise Fail('String kürzer als angegeben')
        if c < 0x80:
            units.append(c); p += 1
        elif c & 0xE0 == 0xC0:
            units.append(((c & 0x1F) << 6) | (d[p + 1] & 0x3F)); p += 2
        else:
            units.append(((c & 0xF) << 12) | ((d[p + 1] & 0x3F) << 6) | (d[p + 2] & 0x3F)); p += 3
    if d[p] != 0:
        raise Fail('String nicht nullterminiert')
    return ''.join(chr(u) for u in units)


def params_of(desc_list):
    return desc_list


class Dex:
    def __init__(self, data):
        self.d = d = data
        if d[:8] != b'dex\n035\0':
            raise Fail('falsche Magic')
        if struct.unpack_from('<I', d, 8)[0] != zlib.adler32(d[12:]) & 0xFFFFFFFF:
            raise Fail('Adler-32 falsch')
        if d[12:32] != hashlib.sha1(d[32:]).digest():
            raise Fail('SHA-1 falsch')
        h = struct.unpack_from('<IIIII I IIIIIIIIIIII II', d, 32)
        (fsize, hsize, endian, link_size, link_off, map_off,
         self.ns, s_off, self.nt, t_off, self.np, p_off, self.nf, f_off, self.nm, m_off, self.nc, c_off,
         data_size, data_off) = h
        if fsize != len(d): raise Fail('file_size')
        if hsize != 0x70: raise Fail('header_size')
        if endian != 0x12345678: raise Fail('endian')
        if data_off + data_size != len(d): raise Fail('Datenbereich endet nicht am Dateiende')
        for n, o in ((self.ns, s_off), (self.nt, t_off), (self.np, p_off), (self.nf, f_off), (self.nm, m_off), (self.nc, c_off)):
            if n == 0 and o != 0: raise Fail('Offset bei leerer Tabelle')
            if o % 4: raise Fail('ID-Tabelle nicht ausgerichtet')
        self.strings = []
        for i in range(self.ns):
            so = struct.unpack_from('<I', d, s_off + 4 * i)[0]
            if so < data_off: raise Fail('string_data außerhalb Datenbereich')
            n, p = uleb(d, so)
            self.strings.append(mutf8(d, p, n))
        for a, b in zip(self.strings, self.strings[1:]):
            if a.encode('utf-16-be', 'surrogatepass') >= b.encode('utf-16-be', 'surrogatepass'):
                raise Fail('string_ids nicht sortiert/eindeutig: %r %r' % (a, b))
        self.types = [self.strings[struct.unpack_from('<I', d, t_off + 4 * i)[0]] for i in range(self.nt)]
        tix = [struct.unpack_from('<I', d, t_off + 4 * i)[0] for i in range(self.nt)]
        if tix != sorted(set(tix)): raise Fail('type_ids nicht sortiert/eindeutig')
        for t in self.types:
            self.check_desc(t)
        self.protos = []
        prev = None
        for i in range(self.np):
            sh, rt, po = struct.unpack_from('<III', d, p_off + 12 * i)
            params = []
            if po:
                if po % 4: raise Fail('type_list nicht ausgerichtet')
                n = struct.unpack_from('<I', d, po)[0]
                params = list(struct.unpack_from('<%dH' % n, d, po + 4))
            key = (rt, params)
            if prev is not None and not prev < key: raise Fail('proto_ids nicht sortiert')
            prev = key
            shorty = self.strings[sh]
            exp = ''.join('L' if t[0] in 'L[' else t[0] for t in [self.types[rt]] + [self.types[x] for x in params])
            if shorty != exp: raise Fail('Shorty falsch %s != %s' % (shorty, exp))
            self.protos.append((self.types[rt], [self.types[x] for x in params]))
        self.fields = []
        prev = None
        for i in range(self.nf):
            c, t, n = struct.unpack_from('<HHI', d, f_off + 8 * i)
            key = (c, n, t)
            if prev is not None and not prev < key: raise Fail('field_ids nicht sortiert')
            prev = key
            self.fields.append((self.types[c], self.strings[n], self.types[t]))
        self.methods = []
        prev = None
        for i in range(self.nm):
            c, pr, n = struct.unpack_from('<HHI', d, m_off + 8 * i)
            key = (c, n, pr)
            if prev is not None and not prev < key: raise Fail('method_ids nicht sortiert')
            prev = key
            self.methods.append((self.types[c], self.strings[n], self.protos[pr]))
        self.classes = []
        seen = set()
        for i in range(self.nc):
            (ci, acc, sup, ifo, src, ann, cdo, sv) = struct.unpack_from('<8I', d, c_off + 32 * i)
            name = self.types[ci]
            sup_name = self.types[sup] if sup != 0xFFFFFFFF else None
            ifaces = []
            if ifo:
                n = struct.unpack_from('<I', d, ifo)[0]
                ifaces = [self.types[x] for x in struct.unpack_from('<%dH' % n, d, ifo + 4)]
            if acc & ~0x7611: raise Fail('ungültige Klassen-Flags %x' % acc)
            self.classes.append({'name': name, 'acc': acc, 'super': sup_name, 'ifaces': ifaces, 'cdo': cdo})
            seen.add(name)
        # Oberklassen vor Unterklassen
        pos = {c['name']: i for i, c in enumerate(self.classes)}
        for i, c in enumerate(self.classes):
            for p in [c['super']] + c['ifaces']:
                if p in pos and pos[p] > i: raise Fail('Oberklasse nach Unterklasse')
        self.parse_class_data()
        self.check_map(map_off, data_off)

    def check_desc(self, t):
        i = 0
        while t[i] == '[':
            i += 1
        c = t[i]
        if c == 'L':
            if not t.endswith(';') or len(t) < 3: raise Fail('Typdeskriptor %r' % t)
        elif c not in 'VZBCSIJFD' or len(t) != i + 1:
            raise Fail('Typdeskriptor %r' % t)
        if c == 'V' and i: raise Fail('void-Array')

    def parse_class_data(self):
        d = self.d
        for c in self.classes:
            c['fields'], c['meths'] = [], []
            if not c['cdo']:
                continue
            p = c['cdo']
            sf, p = uleb(d, p); inf, p = uleb(d, p); dm, p = uleb(d, p); vm, p = uleb(d, p)
            for cnt, static in ((sf, True), (inf, False)):
                idx = 0
                for k in range(cnt):
                    diff, p = uleb(d, p); acc, p = uleb(d, p)
                    if k and diff == 0: raise Fail('Feld doppelt')
                    idx += diff
                    f = self.fields[idx]
                    if f[0] != c['name']: raise Fail('Feld gehört zu anderer Klasse')
                    if bool(acc & 8) != static: raise Fail('static-Flag Feld')
                    c['fields'].append((f, acc))
            for cnt, direct in ((dm, True), (vm, False)):
                idx = 0
                for k in range(cnt):
                    diff, p = uleb(d, p); acc, p = uleb(d, p); co, p = uleb(d, p)
                    if k and diff == 0: raise Fail('Methode doppelt')
                    idx += diff
                    m = self.methods[idx]
                    if m[0] != c['name']: raise Fail('Methode gehört zu anderer Klasse')
                    is_ctor = m[1] in ('<init>', '<clinit>')
                    if is_ctor != bool(acc & 0x10000): raise Fail('ACC_CONSTRUCTOR falsch bei %s' % m[1])
                    if direct != bool(acc & (0x8 | 0x2) or is_ctor): raise Fail('direct/virtual falsch bei %s' % m[1])
                    if bool(co) == bool(acc & (0x400 | 0x100)): raise Fail('Code/abstract falsch bei %s' % m[1])
                    if m[1] == '<init>' and acc & 8: raise Fail('statischer Konstruktor')
                    code = self.parse_code(co) if co else None
                    c['meths'].append((m, acc, code))

    def parse_code(self, co):
        d = self.d
        if co % 4: raise Fail('code_item nicht ausgerichtet')
        regs, ins, outs, tries, dbg, n = struct.unpack_from('<HHHHII', d, co)
        units = list(struct.unpack_from('<%dH' % n, d, co + 16))
        p = co + 16 + 2 * n
        tlist = []
        if tries:
            if n % 2: p += 2
            hl = p + 8 * tries
            for k in range(tries):
                sa, cnt, ho = struct.unpack_from('<IHH', d, p + 8 * k)
                q = hl + ho
                sz, q = sleb(d, q)
                hs = []
                for _ in range(abs(sz)):
                    t, q = uleb(d, q); a, q = uleb(d, q); hs.append((self.types[t], a))
                ca = None
                if sz <= 0:
                    ca, q = uleb(d, q)
                tlist.append((sa, sa + cnt, hs, ca))
            for a, b in zip(tlist, tlist[1:]):
                if a[1] > b[0]: raise Fail('try-Bereiche überlappen/unsortiert')
        return {'regs': regs, 'ins': ins, 'outs': outs, 'units': units, 'tries': tlist, 'off': co}

    def check_map(self, map_off, data_off):
        d = self.d
        if map_off % 4 or map_off < data_off: raise Fail('map_off')
        n = struct.unpack_from('<I', d, map_off)[0]
        items = [struct.unpack_from('<HHII', d, map_off + 4 + 12 * i) for i in range(n)]
        offs = [x[3] for x in items]
        if offs != sorted(offs): raise Fail('Map nicht sortiert')
        types = [x[0] for x in items]
        if len(set(types)) != len(types): raise Fail('Map-Typ doppelt')
        need = {0x0000: 1, 0x1000: 1}
        for t, _, cnt, _ in items:
            if t in need and cnt != need[t]: raise Fail('Map-Anzahl %x' % t)
        cnt = {x[0]: x[2] for x in items}
        for t, v in ((1, self.ns), (2, self.nt), (3, self.np), (4, self.nf), (5, self.nm), (6, self.nc)):
            if v and cnt.get(t) != v: raise Fail('Map/Kopf passen nicht (%d)' % t)
        codes = sum(1 for c in self.classes for (_, _, code) in c['meths'] if code)
        if codes and cnt.get(0x2001) != codes: raise Fail('Map: Anzahl code_items')
        if cnt.get(0x2002) != self.ns: raise Fail('Map: Anzahl string_data')


# ---------------- Disassembler ----------------

def decode_insn(units, pc):
    u = units[pc]
    op = u & 0xFF
    if op not in FMT:
        raise Fail('unbekannter Opcode 0x%02x bei %04x' % (op, pc))
    name, f = FMT[op]
    n = SIZE[f]
    if pc + n > len(units):
        raise Fail('Befehl ragt über das Ende hinaus bei %04x' % pc)
    A = (u >> 8) & 0xF; B = (u >> 12) & 0xF; AA = u >> 8
    w = units[pc:pc + n]
    x = {'op': op, 'name': name, 'fmt': f, 'size': n, 'pc': pc}
    def s16(v): return v - 0x10000 if v & 0x8000 else v
    def s32(lo, hi):
        v = lo | (hi << 16); return v - (1 << 32) if v & 0x80000000 else v
    if f == '10x':
        if AA and op == 0: raise Fail('Payload wird nicht unterstützt')
    elif f == '12x': x['regs'] = [A, B]
    elif f == '11n': x['regs'] = [A]; x['lit'] = B - 16 if B & 8 else B
    elif f == '11x': x['regs'] = [AA]
    elif f == '10t': x['target'] = pc + (AA - 256 if AA & 0x80 else AA)
    elif f == '20t': x['target'] = pc + s16(w[1])
    elif f == '22x': x['regs'] = [AA, w[1]]
    elif f == '21t': x['regs'] = [AA]; x['target'] = pc + s16(w[1])
    elif f == '21s': x['regs'] = [AA]; x['lit'] = s16(w[1])
    elif f == '21h': x['regs'] = [AA]; x['lit'] = w[1] << (16 if op == 0x15 else 48)
    elif f == '21c': x['regs'] = [AA]; x['idx'] = w[1]
    elif f == '23x': x['regs'] = [AA, w[1] & 0xFF, w[1] >> 8]
    elif f == '22b': x['regs'] = [AA, w[1] & 0xFF]; x['lit'] = ((w[1] >> 8) ^ 0x80) - 0x80
    elif f == '22t': x['regs'] = [A, B]; x['target'] = pc + s16(w[1])
    elif f == '22s': x['regs'] = [A, B]; x['lit'] = s16(w[1])
    elif f == '22c': x['regs'] = [A, B]; x['idx'] = w[1]
    elif f == '32x': x['regs'] = [w[1], w[2]]
    elif f == '30t': x['target'] = pc + s32(w[1], w[2])
    elif f == '31i': x['regs'] = [AA]; x['lit'] = s32(w[1], w[2])
    elif f == '31c': x['regs'] = [AA]; x['idx'] = w[1] | (w[2] << 16)
    elif f == '31t': raise Fail('switch/fill-array wird vom Prüfer nicht unterstützt')
    elif f == '35c':
        cnt, G = u >> 12, (u >> 8) & 0xF
        regs = [w[2] & 0xF, (w[2] >> 4) & 0xF, (w[2] >> 8) & 0xF, w[2] >> 12, G][:cnt]
        x['regs'] = regs; x['idx'] = w[1]
    elif f == '3rc':
        x['regs'] = list(range(w[2], w[2] + AA)); x['idx'] = w[1]
    elif f == '51l':
        x['regs'] = [AA]; x['lit'] = w[1] | (w[2] << 16) | (w[3] << 32) | (w[4] << 48)
    return x


def fmt_insn(dex, x):
    s = x['name']
    if 'regs' in x:
        if x['fmt'] in ('35c', '3rc'):
            s += ' {' + ', '.join('v%d' % r for r in x['regs']) + '}'
        else:
            s += ' ' + ', '.join('v%d' % r for r in x['regs'])
    if 'lit' in x:
        s += ', #%d' % x['lit']
    if 'target' in x:
        s += ', -> %04x' % x['target']
    if 'idx' in x:
        n = x['name']
        if n.startswith('const-string'):
            s += ', "%s"' % dex.strings[x['idx']].replace('\n', '\\n')
        elif n.startswith(('iget', 'iput', 'sget', 'sput')):
            f = dex.fields[x['idx']]; s += ', %s->%s:%s' % f
        elif n.startswith('invoke'):
            m = dex.methods[x['idx']]; s += ', %s->%s(%s)%s' % (m[0], m[1], ''.join(m[2][1]), m[2][0])
        else:
            s += ', %s' % dex.types[x['idx']]
    return s


# ---------------- Typprüfung ----------------
X = 'X'


def is_ref(t):
    return isinstance(t, tuple) and t[0] in ('ref', 'uninit', 'uthis') or t == ('c32', True)


def merge(a, b):
    if a == b:
        return a
    if a == X or b == X:
        return X
    sa, sb = set([a if not isinstance(a, tuple) else a[0]]), None
    if isinstance(a, tuple) and a[0] == 'c32' and b in ('I', 'F'):
        return b
    if isinstance(b, tuple) and b[0] == 'c32' and a in ('I', 'F'):
        return a
    if isinstance(a, tuple) and isinstance(b, tuple):
        if a[0] == 'c32' and b[0] == 'c32':
            return ('c32', a[1] and b[1])
        if a == ('c32', True) and b[0] == 'ref':
            return b
        if b == ('c32', True) and a[0] == 'ref':
            return a
        if a[0] == 'ref' and b[0] == 'ref':
            return ('ref', 'Ljava/lang/Object;')
    pairs = {('c64lo', 'Jlo'): 'Jlo', ('c64lo', 'Dlo'): 'Dlo', ('c64hi', 'Jhi'): 'Jhi', ('c64hi', 'Dhi'): 'Dhi'}
    if (a, b) in pairs: return pairs[(a, b)]
    if (b, a) in pairs: return pairs[(b, a)]
    return X


class Verifier:
    def __init__(self, dex, cls, m, acc, code):
        self.dex, self.cls, self.m, self.acc, self.code = dex, cls, m, acc, code
        self.where = '%s->%s%s' % (m[0], m[1], '(' + ''.join(m[2][1]) + ')' + m[2][0])

    def fail(self, pc, msg):
        raise Fail('%s @%04x: %s' % (self.where, pc, msg))

    def run(self):
        code, dex = self.code, self.dex
        units = code['units']
        insns, pc = {}, 0
        while pc < len(units):
            x = decode_insn(units, pc)
            insns[pc] = x
            pc += x['size']
        self.insns = insns
        order = sorted(insns)
        nxt = {a: b for a, b in zip(order, order[1:])}
        R = code['regs']
        for x in insns.values():
            for r in x.get('regs', []):
                wide = self.wide_use(x)
                if r >= R or (r in wide and r + 1 >= R):
                    self.fail(x['pc'], 'Register v%d außerhalb (%d)' % (r, R))
            if 'target' in x and x['target'] not in insns:
                self.fail(x['pc'], 'Sprungziel mitten im Befehl')
        handlers = {}
        for (a, b, hs, ca) in code['tries']:
            if a not in insns or (b not in insns and b != len(units)): self.fail(a, 'try-Grenze ungültig')
            for t, h in hs + ([(None, ca)] if ca is not None else []):
                if h not in insns: self.fail(h, 'Handler-Adresse ungültig')
                if insns[h]['op'] != 0x0d: self.fail(h, 'Handler beginnt nicht mit move-exception')
                handlers.setdefault(h, set()).add(t)
        self.handlers = handlers
        # Einstieg
        params = []
        if not self.acc & 8:
            params.append(('uthis', self.cls['name']) if self.m[1] == '<init>' else ('ref', self.cls['name']))
        for t in self.m[2][1]:
            if t[0] in 'JD':
                params += [t[0] + 'lo', t[0] + 'hi']
            elif t[0] in 'L[':
                params.append(('ref', t))
            elif t == 'F':
                params.append('F')
            else:
                params.append('I')
        if len(params) != code['ins']: self.fail(0, 'ins_size passt nicht (%d/%d)' % (len(params), code['ins']))
        if code['ins'] > R: self.fail(0, 'ins > registers')
        entry = [X] * (R - len(params)) + params
        states = {0: entry}
        work = [0]
        self.maxout = 0
        visits = 0
        while work:
            pc = work.pop()
            visits += 1
            if visits > 20000: self.fail(pc, 'Datenfluss konvergiert nicht')
            regs = list(states[pc])
            x = insns[pc]
            before = list(regs)
            succ = self.exec(x, regs, nxt.get(pc))
            # Ausnahmepfade
            if self.can_throw(x):
                for (a, b, hs, ca) in code['tries']:
                    if a <= pc < b:
                        for t, h in hs + ([(None, ca)] if ca is not None else []):
                            self.flow(states, work, h, before)
            for tpc in succ:
                if tpc is None:
                    self.fail(pc, 'Code läuft über das Methodenende hinaus')
                self.flow(states, work, tpc, regs)
        for pc in order:
            if pc not in states and insns[pc]['op'] != 0:
                pass  # unerreichbarer Code ist erlaubt
        if self.maxout > code['outs']: self.fail(0, 'outs_size zu klein')
        return len(states)

    def flow(self, states, work, pc, regs):
        old = states.get(pc)
        if old is None:
            states[pc] = list(regs); work.append(pc); return
        new = [merge(a, b) for a, b in zip(old, regs)]
        if new != old:
            states[pc] = new; work.append(pc)

    def wide_use(self, x):
        n, r = x['name'], x.get('regs', [])
        out = set()
        if 'wide' in n or 'long' in n or 'double' in n:
            if n.startswith(('move-wide', 'move-result-wide', 'return-wide', 'const-wide', 'aget-wide', 'aput-wide',
                             'iget-wide', 'iput-wide', 'sget-wide', 'sput-wide')):
                out.add(r[0])
                if n.startswith('move-wide'): out.add(r[1])
        return out

    def can_throw(self, x):
        n = x['name']
        return n.startswith(('invoke', 'iget', 'iput', 'sget', 'sput', 'aget', 'aput', 'new-', 'check-cast',
                             'const-string', 'const-class', 'array-length', 'throw', 'monitor', 'instance-of',
                             'div-', 'rem-', 'filled')) or '/lit' in n and n.startswith(('div', 'rem'))

    # --- Registerzugriffe ---
    def get(self, regs, r, pc):
        t = regs[r]
        if t == X: self.fail(pc, 'v%d undefiniert/Konflikt gelesen' % r)
        return t

    def use_int(self, regs, r, pc):
        t = self.get(regs, r, pc)
        if not (t == 'I' or (isinstance(t, tuple) and t[0] == 'c32')): self.fail(pc, 'v%d ist kein int (%r)' % (r, t))

    def use_float(self, regs, r, pc):
        t = self.get(regs, r, pc)
        if not (t == 'F' or (isinstance(t, tuple) and t[0] == 'c32')): self.fail(pc, 'v%d ist kein float (%r)' % (r, t))

    def use_cat1(self, regs, r, pc):
        t = self.get(regs, r, pc)
        if not (t in ('I', 'F') or (isinstance(t, tuple) and t[0] == 'c32')): self.fail(pc, 'v%d ist kein 32-Bit-Wert (%r)' % (r, t))
        return t

    def use_ref(self, regs, r, pc, allow_uninit=False):
        t = self.get(regs, r, pc)
        if t == ('c32', True): return 'null'
        if not isinstance(t, tuple) or t[0] not in ('ref', 'uninit', 'uthis'): self.fail(pc, 'v%d ist keine Referenz (%r)' % (r, t))
        if t[0] != 'ref' and not allow_uninit: self.fail(pc, 'v%d ist nicht initialisiert' % r)
        return t

    def use_wide(self, regs, r, pc, k=None):
        lo, hi = self.get(regs, r, pc), regs[r + 1]
        ok = (lo, hi) in (('Jlo', 'Jhi'), ('Dlo', 'Dhi'), ('c64lo', 'c64hi'))
        if not ok: self.fail(pc, 'v%d/v%d ist kein Wide-Paar (%r,%r)' % (r, r + 1, lo, hi))
        if k and lo[0] != 'c' and lo[0] != k: self.fail(pc, 'v%d hat falschen Wide-Typ' % r)
        return lo

    def put(self, regs, r, t):
        if r > 0 and regs[r - 1] in ('Jlo', 'Dlo', 'c64lo'): regs[r - 1] = X
        if r + 1 < len(regs) and regs[r] in ('Jlo', 'Dlo', 'c64lo'): regs[r + 1] = X
        regs[r] = t

    def put_wide(self, regs, r, k):
        if r > 0 and regs[r - 1] in ('Jlo', 'Dlo', 'c64lo'): regs[r - 1] = X
        if r + 2 < len(regs) and regs[r + 1] in ('Jlo', 'Dlo', 'c64lo'): regs[r + 2] = X
        regs[r] = k + 'lo'; regs[r + 1] = k + 'hi'

    def use_typed(self, regs, r, t, pc):
        c = t[0]
        if c in 'ZBCSI': self.use_int(regs, r, pc)
        elif c == 'F': self.use_float(regs, r, pc)
        elif c in 'JD': self.use_wide(regs, r, pc, c)
        else: self.use_ref(regs, r, pc)

    def put_typed(self, regs, r, t):
        c = t[0]
        if c in 'ZBCSI': self.put(regs, r, 'I')
        elif c == 'F': self.put(regs, r, 'F')
        elif c in 'JD': self.put_wide(regs, r, c)
        else: self.put(regs, r, ('ref', t))

    def exec(self, x, regs, nxt):
        dex, pc, n, op = self.dex, x['pc'], x['name'], x['op']
        r = x.get('regs', [])
        ft = [nxt]
        ret = self.m[2][0]
        prev = self.prev_insn(pc)
        if op in (0x0a, 0x0b, 0x0c):
            if not prev or not prev['name'].startswith('invoke'): self.fail(pc, 'move-result ohne vorheriges invoke')
            rt = dex.methods[prev['idx']][2][0]
            need = {0x0a: 'ZBCSIF', 0x0b: 'JD', 0x0c: 'L['}[op]
            if rt[0] not in need: self.fail(pc, 'move-result passt nicht zum Rückgabetyp %s' % rt)
            self.put_typed(regs, r[0], rt)
            return ft
        if op == 0x0d:
            if pc not in self.handlers: self.fail(pc, 'move-exception außerhalb eines Handlers')
            ts = self.handlers[pc]
            self.put(regs, r[0], ('ref', list(ts)[0] if len(ts) == 1 and None not in ts else 'Ljava/lang/Throwable;'))
            return ft
        if op in (0x01, 0x02, 0x03):
            self.put(regs, r[0], self.use_cat1(regs, r[1], pc)); return ft
        if op in (0x04, 0x05, 0x06):
            lo, hi = self.use_wide(regs, r[1], pc), regs[r[1] + 1]
            if lo.startswith('c64'): regs_k = None
            self.put(regs, r[0], lo); regs[r[0] + 1] = hi
            if r[0] > 0 and regs[r[0] - 1] in ('Jlo', 'Dlo', 'c64lo') and r[0] - 1 != r[0]: pass
            return ft
        if op in (0x07, 0x08, 0x09):
            t = self.get(regs, r[1], pc)
            if not is_ref(t): self.fail(pc, 'move-object mit Nicht-Referenz %r' % (t,))
            self.put(regs, r[0], t); return ft
        if op == 0x0e:
            if ret != 'V': self.fail(pc, 'return-void in Methode mit Rückgabewert')
            if self.m[1] == '<init>' and any(isinstance(t, tuple) and t[0] == 'uthis' for t in regs):
                self.fail(pc, 'Konstruktor endet ohne super()-Aufruf')
            return []
        if op == 0x0f:
            if ret[0] not in 'ZBCSIF': self.fail(pc, 'return passt nicht')
            self.use_typed(regs, r[0], ret, pc); return []
        if op == 0x10:
            if ret[0] not in 'JD': self.fail(pc, 'return-wide passt nicht')
            self.use_wide(regs, r[0], pc, ret[0]); return []
        if op == 0x11:
            if ret[0] not in 'L[': self.fail(pc, 'return-object passt nicht')
            self.use_ref(regs, r[0], pc); return []
        if op in (0x12, 0x13, 0x14, 0x15):
            self.put(regs, r[0], ('c32', x['lit'] == 0)); return ft
        if op in (0x16, 0x17, 0x18, 0x19):
            self.put(regs, r[0], 'c64lo'); regs[r[0] + 1] = 'c64hi'; return ft
        if op in (0x1a, 0x1b):
            self.put(regs, r[0], ('ref', 'Ljava/lang/String;')); return ft
        if op == 0x1c:
            self.put(regs, r[0], ('ref', 'Ljava/lang/Class;')); return ft
        if op in (0x1d, 0x1e, 0x27):
            self.use_ref(regs, r[0], pc)
            return [] if op == 0x27 else ft
        if op == 0x1f:
            self.use_ref(regs, r[0], pc); self.put(regs, r[0], ('ref', dex.types[x['idx']])); return ft
        if op == 0x20:
            self.use_ref(regs, r[1], pc); self.put(regs, r[0], 'I'); return ft
        if op == 0x21:
            t = self.use_ref(regs, r[1], pc)
            if t != 'null' and not t[1].startswith('['): self.fail(pc, 'array-length auf Nicht-Array')
            self.put(regs, r[0], 'I'); return ft
        if op == 0x22:
            t = dex.types[x['idx']]
            if not t.startswith('L'): self.fail(pc, 'new-instance mit Nicht-Klasse')
            self.put(regs, r[0], ('uninit', t, pc)); return ft
        if op == 0x23:
            self.use_int(regs, r[1], pc)
            t = dex.types[x['idx']]
            if not t.startswith('['): self.fail(pc, 'new-array ohne Array-Typ')
            self.put(regs, r[0], ('ref', t)); return ft
        if op in (0x28, 0x29, 0x2a):
            return [x['target']]
        if 0x2d <= op <= 0x31:
            if op in (0x2d, 0x2e): self.use_float(regs, r[1], pc); self.use_float(regs, r[2], pc)
            else:
                k = 'D' if op in (0x2f, 0x30) else 'J'
                self.use_wide(regs, r[1], pc, k); self.use_wide(regs, r[2], pc, k)
            self.put(regs, r[0], 'I'); return ft
        if 0x32 <= op <= 0x37:
            a, b = self.get(regs, r[0], pc), self.get(regs, r[1], pc)
            if is_ref(a) or is_ref(b):
                if op not in (0x32, 0x33): self.fail(pc, 'Größenvergleich mit Referenz')
                self.use_ref(regs, r[0], pc); self.use_ref(regs, r[1], pc)
            else:
                self.use_int(regs, r[0], pc); self.use_int(regs, r[1], pc)
            return ft + [x['target']]
        if 0x38 <= op <= 0x3d:
            a = self.get(regs, r[0], pc)
            if is_ref(a) and a != ('c32', True):
                if op not in (0x38, 0x39): self.fail(pc, 'Größenvergleich mit Referenz')
                self.use_ref(regs, r[0], pc)
            else:
                self.use_int(regs, r[0], pc)
            return ft + [x['target']]
        if 0x44 <= op <= 0x51:
            get = op < 0x4b
            v = op - (0x44 if get else 0x4b)
            arr = self.use_ref(regs, r[1], pc)
            self.use_int(regs, r[2], pc)
            comp = None if arr == 'null' else arr[1][1:]
            if arr != 'null' and not arr[1].startswith('['): self.fail(pc, 'aget/aput auf Nicht-Array')
            want = {0: 'IF', 1: 'JD', 2: 'L[', 3: 'Z', 4: 'B', 5: 'C', 6: 'S'}[v]
            if comp and comp[0] not in want: self.fail(pc, '%s passt nicht zu %s' % (n, arr[1]))
            if get:
                if v == 1: self.put_wide(regs, r[0], comp[0] if comp else 'J')
                elif v == 2: self.put(regs, r[0], ('ref', comp or 'Ljava/lang/Object;'))
                elif v == 0: self.put(regs, r[0], 'F' if comp == 'F' else 'I')
                else: self.put(regs, r[0], 'I')
            else:
                if v == 1: self.use_wide(regs, r[0], pc)
                elif v == 2: self.use_ref(regs, r[0], pc)
                elif v == 0: self.use_cat1(regs, r[0], pc)
                else: self.use_int(regs, r[0], pc)
            return ft
        if 0x52 <= op <= 0x6d:
            f = dex.fields[x['idx']]
            static = op >= 0x60
            base = 0x60 if op < 0x67 and static else 0x67 if static else 0x52 if op < 0x59 else 0x59
            v = op - base
            put = op >= 0x67 or 0x59 <= op <= 0x5f
            want = {0: 'IF', 1: 'JD', 2: 'L[', 3: 'Z', 4: 'B', 5: 'C', 6: 'S'}[v]
            if f[2][0] not in want: self.fail(pc, '%s passt nicht zu Feldtyp %s' % (n, f[2]))
            self.check_field_exists(f, static, pc)
            if not static:
                o = self.use_ref(regs, r[1], pc, allow_uninit=True)
                if o != 'null' and o[0] != 'ref':
                    if not (o[0] == 'uthis' and put and f[0] == self.cls['name']):
                        self.fail(pc, 'Feldzugriff auf nicht initialisiertes Objekt')
            if put:
                self.use_typed(regs, r[0], f[2], pc)
            else:
                self.put_typed(regs, r[0], f[2])
            return ft
        if 0x6e <= op <= 0x78:
            m = dex.methods[x['idx']]
            kind = x['name'].split('-')[1].split('/')[0]
            args = r
            self.maxout = max(self.maxout, len(args))
            ps = ([] if kind == 'static' else [m[0]]) + m[2][1]
            need = sum(2 if p[0] in 'JD' else 1 for p in ps)
            if need != len(args): self.fail(pc, 'Argumentanzahl %d statt %d für %s' % (len(args), need, m[1]))
            if x['fmt'] == '35c':
                pass
            i = 0
            for k, p in enumerate(ps):
                reg = args[i]
                if k == 0 and kind != 'static':
                    t = self.use_ref(regs, reg, pc, allow_uninit=(m[1] == '<init>'))
                    if m[1] == '<init>':
                        if kind != 'direct': self.fail(pc, 'Konstruktor ohne invoke-direct')
                        if t == 'null' or t[0] == 'ref': self.fail(pc, 'Konstruktor auf initialisiertem Objekt')
                        if t[0] == 'uninit' and t[1] != m[0]: self.fail(pc, 'Konstruktor falscher Klasse')
                        if t[0] == 'uthis' and m[0] not in (self.cls['name'], self.cls['super']):
                            self.fail(pc, 'this()-/super()-Aufruf auf fremde Klasse')
                        for j in range(len(regs)):
                            if regs[j] == t:
                                regs[j] = ('ref', t[1])
                    i += 1
                    continue
                if p[0] in 'JD':
                    self.use_wide(regs, reg, pc, p[0]); i += 2
                else:
                    self.use_typed(regs, reg, p, pc); i += 1
            if kind == 'direct' and m[1] != '<init>' and m[0] != self.cls['name']:
                self.fail(pc, 'invoke-direct auf fremde private Methode')
            if kind == 'interface' and m[0] in [c['name'] for c in dex.classes if not c['acc'] & 0x200]:
                self.fail(pc, 'invoke-interface auf Klasse')
            self.check_method_exists(m, kind, pc)
            return ft
        if 0x7b <= op <= 0x8f:
            nm = UN[op - 0x7b]
            src = nm.split('-to-')[0] if '-to-' in nm else nm.split('-')[1]
            dst = nm.split('-to-')[1] if '-to-' in nm else src
            if src in ('long', 'double'): self.use_wide(regs, r[1], pc, src[0].upper())
            elif src == 'float': self.use_float(regs, r[1], pc)
            else: self.use_int(regs, r[1], pc)
            if dst in ('long', 'double'): self.put_wide(regs, r[0], dst[0].upper())
            elif dst == 'float': self.put(regs, r[0], 'F')
            else: self.put(regs, r[0], 'I')
            return ft
        if 0x90 <= op <= 0xcf:
            two = op >= 0xb0
            name, t = BINT[op - (0xb0 if two else 0x90)]
            if two: d, a, b = r[0], r[0], r[1]
            else: d, a, b = r
            shift = name in ('shl', 'shr', 'ushr')
            if t in ('long', 'double'):
                self.use_wide(regs, a, pc, t[0].upper())
                if shift: self.use_int(regs, b, pc)
                else: self.use_wide(regs, b, pc, t[0].upper())
                self.put_wide(regs, d, t[0].upper())
            elif t == 'float':
                self.use_float(regs, a, pc); self.use_float(regs, b, pc); self.put(regs, d, 'F')
            else:
                self.use_int(regs, a, pc); self.use_int(regs, b, pc); self.put(regs, d, 'I')
            return ft
        if 0xd0 <= op <= 0xe2:
            self.use_int(regs, r[1], pc); self.put(regs, r[0], 'I'); return ft
        self.fail(pc, 'Befehl %s nicht geprüft' % n)

    def prev_insn(self, pc):
        best = None
        for a in self.insns:
            if a < pc and (best is None or a > best):
                best = a
        if best is None: return None
        x = self.insns[best]
        return x if best + x['size'] == pc else None

    def check_field_exists(self, f, static, pc):
        c = self.local_class(f[0])
        if c is None: return
        for (ff, acc) in c['fields']:
            if ff == f:
                if bool(acc & 8) != static: self.fail(pc, 'Feld static/instanz vertauscht')
                return
        if c['super'] and self.local_class(c['super']) is None:
            return  # könnte geerbt sein
        self.fail(pc, 'Feld %s->%s fehlt' % (f[0], f[1]))

    def check_method_exists(self, m, kind, pc):
        c = self.local_class(m[0])
        if c is None: return
        for (mm, acc, code) in c['meths']:
            if mm == m:
                if kind == 'static' and not acc & 8: self.fail(pc, 'invoke-static auf Instanzmethode')
                if kind == 'virtual' and acc & (8 | 2 | 0x10000): self.fail(pc, 'invoke-virtual auf direkte Methode')
                if kind == 'direct' and not acc & (2 | 0x10000): self.fail(pc, 'invoke-direct auf virtuelle Methode')
                return
        if kind in ('virtual', 'super', 'interface') and c['super'] and self.local_class(c['super']) is None:
            return
        self.fail(pc, 'Methode %s->%s fehlt' % (m[0], m[1]))

    def local_class(self, name):
        for c in self.dex.classes:
            if c['name'] == name: return c
        return None


def main(argv):
    path = argv[1]
    dump = '--dump' in argv
    dex = Dex(open(path, 'rb').read())
    total = 0
    for c in dex.classes:
        if dump:
            print('Klasse %s extends %s %s' % (c['name'], c['super'], ' implements ' + ', '.join(c['ifaces']) if c['ifaces'] else ''))
        for (m, acc, code) in c['meths']:
            if not code:
                continue
            v = Verifier(dex, c, m, acc, code)
            reached = v.run()
            total += 1
            if dump:
                print('  %s%s  acc=0x%x regs=%d ins=%d outs=%d' % (m[1], '(' + ''.join(m[2][1]) + ')' + m[2][0], acc, code['regs'], code['ins'], code['outs']))
                for pc in sorted(v.insns):
                    print('    %04x: %s' % (pc, fmt_insn(dex, v.insns[pc])))
                for (a, b, hs, ca) in code['tries']:
                    print('    try %04x-%04x %s%s' % (a, b, ' '.join('%s->%04x' % h for h in hs), ' alle->%04x' % ca if ca is not None else ''))
    print('OK: %d Klassen, %d Methoden geprüft, %d Strings, %d Typen, %d Methodenreferenzen' % (len(dex.classes), total, dex.ns, dex.nt, dex.nm))


if __name__ == '__main__':
    try:
        main(sys.argv)
    except Fail as e:
        print('FEHLER:', e)
        sys.exit(1)
