#!/usr/bin/env python3
"""
apkcheck – prüft eine APK unabhängig vom Bauwerkzeug:
  ZIP-Struktur (eigene Auswertung + Python-zipfile), Ausrichtung, APK-Signatur v2
  (Kryptografie und Inhalts-Digest), Binär-XML-Manifest, resources.arsc, DEX.
Aufruf: apkcheck.py app.apk
"""
import hashlib
import io
import re
import struct
import sys
import zipfile
import zlib

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding


class Bad(Exception):
    pass


def u32(b, o): return struct.unpack_from('<I', b, o)[0]
def u16(b, o): return struct.unpack_from('<H', b, o)[0]


def read_lp(b, o):
    n = u32(b, o)
    if o + 4 + n > len(b): raise Bad('Längenpräfix zu groß')
    return b[o + 4:o + 4 + n], o + 4 + n


def lp_seq(b):
    out, o = [], 0
    while o < len(b):
        item, o = read_lp(b, o)
        out.append(item)
    return out


# ---------- ZIP ----------
def parse_zip(apk):
    e = apk.rfind(b'PK\x05\x06')
    if e < 0 or e + 22 != len(apk): raise Bad('EOCD nicht am Ende')
    n, cd_size, cd_off = u16(apk, e + 10), u32(apk, e + 12), u32(apk, e + 16)
    if cd_off + cd_size != e: raise Bad('Zentralverzeichnis nicht direkt vor EOCD')
    entries, p = [], cd_off
    for _ in range(n):
        if u32(apk, p) != 0x02014b50: raise Bad('CD-Signatur')
        method, crc, csz, usz = u16(apk, p + 10), u32(apk, p + 16), u32(apk, p + 20), u32(apk, p + 24)
        nl, xl, cl, lho = u16(apk, p + 28), u16(apk, p + 30), u16(apk, p + 32), u32(apk, p + 42)
        name = apk[p + 46:p + 46 + nl].decode('utf-8')
        p += 46 + nl + xl + cl
        if u32(apk, lho) != 0x04034b50: raise Bad('Local-Header-Signatur bei ' + name)
        lm, lcrc, lcsz, lusz = u16(apk, lho + 8), u32(apk, lho + 14), u32(apk, lho + 18), u32(apk, lho + 22)
        lnl, lxl = u16(apk, lho + 26), u16(apk, lho + 28)
        if (lm, lcrc, lcsz, lusz) != (method, crc, csz, usz): raise Bad('Local/CD verschieden bei ' + name)
        if u16(apk, lho + 6) & 0x8: raise Bad('Datendeskriptor nicht erwartet')
        if apk[lho + 30:lho + 30 + lnl].decode('utf-8') != name: raise Bad('Name verschieden')
        data_off = lho + 30 + lnl + lxl
        raw = apk[data_off:data_off + csz]
        data = raw if method == 0 else zlib.decompress(raw, -15)
        if len(data) != usz or zlib.crc32(data) & 0xFFFFFFFF != crc: raise Bad('CRC/Größe falsch bei ' + name)
        entries.append({'name': name, 'method': method, 'off': data_off, 'data': data, 'lho': lho})
    return entries, cd_off, e


# ---------- Signatur v2 ----------
def verify_v2(apk, cd_off, eocd_off):
    if apk[cd_off - 16:cd_off] != b'APK Sig Block 42': raise Bad('kein APK Signing Block')
    size2 = struct.unpack_from('<Q', apk, cd_off - 24)[0]
    start = cd_off - size2 - 8
    if struct.unpack_from('<Q', apk, start)[0] != size2: raise Bad('Blockgrößen verschieden')
    p, pairs = start + 8, {}
    while p < cd_off - 24:
        ln = struct.unpack_from('<Q', apk, p)[0]
        pid = u32(apk, p + 8)
        pairs[pid] = apk[p + 12:p + 8 + ln]
        p += 8 + ln
    if p != cd_off - 24: raise Bad('Paare füllen den Block nicht exakt')
    if 0x7109871a not in pairs: raise Bad('keine v2-Signatur')
    signers = lp_seq(read_lp(pairs[0x7109871a], 0)[0])
    if len(signers) != 1: raise Bad('Anzahl Signierer')
    signed, o = read_lp(signers[0], 0)
    sigs, o = read_lp(signers[0], o)
    pub, o = read_lp(signers[0], o)
    digests, q = read_lp(signed, 0)
    certs, q = read_lp(signed, q)
    attrs, q = read_lp(signed, q)
    pubkey = serialization.load_der_public_key(pub)
    ok = False
    for s in lp_seq(sigs):
        algo = u32(s, 0)
        sig = read_lp(s, 4)[0]
        if algo == 0x0103:
            pubkey.verify(sig, signed, padding.PKCS1v15(), hashes.SHA256())
            ok = True
    if not ok: raise Bad('keine RSA-SHA256-Signatur')
    cert = x509.load_der_x509_certificate(lp_seq(certs)[0])
    if cert.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo) != pub:
        raise Bad('Zertifikat passt nicht zum öffentlichen Schlüssel')
    want = None
    for d in lp_seq(digests):
        if u32(d, 0) == 0x0103:
            want = read_lp(d, 4)[0]
    eocd = bytearray(apk[eocd_off:])
    struct.pack_into('<I', eocd, 16, start)  # CD-Offset wird als Blockanfang behandelt
    chunks = []
    for sec in (apk[:start], apk[cd_off:eocd_off], bytes(eocd)):
        for i in range(0, len(sec), 1 << 20):
            c = sec[i:i + (1 << 20)]
            chunks.append(hashlib.sha256(b'\xa5' + struct.pack('<I', len(c)) + c).digest())
    got = hashlib.sha256(b'\x5a' + struct.pack('<I', len(chunks)) + b''.join(chunks)).digest()
    if got != want: raise Bad('Inhalts-Digest stimmt nicht')
    return cert


# ---------- Binär-XML ----------
def parse_pool(b, o):
    tp, hs, size, cnt, scnt, flags, ss, sts = struct.unpack_from('<HHIIIIII', b, o)
    if tp != 1: raise Bad('Stringpool erwartet')
    utf8 = bool(flags & 0x100)
    out = []
    for i in range(cnt):
        p = o + ss + u32(b, o + hs + 4 * i)
        if utf8:
            n = b[p]; p += 2 if n & 0x80 else 1
            m = b[p]
            if m & 0x80: m = ((m & 0x7F) << 8) | b[p + 1]; p += 2
            else: p += 1
            out.append(b[p:p + m].decode('utf-8'))
            if b[p + m] != 0: raise Bad('UTF-8-String nicht terminiert')
        else:
            n = u16(b, p); p += 2
            if n & 0x8000: n = ((n & 0x7FFF) << 16) | u16(b, p); p += 2
            out.append(b[p:p + 2 * n].decode('utf-16-le'))
            if u16(b, p + 2 * n) != 0: raise Bad('UTF-16-String nicht terminiert')
    return out, o + size


def parse_axml(b):
    if u16(b, 0) != 3 or u32(b, 4) != len(b): raise Bad('AXML-Kopf')
    strings, o = parse_pool(b, 8)
    ids = []
    if u16(b, o) == 0x0180:
        n = (u32(b, o + 4) - 8) // 4
        ids = [u32(b, o + 8 + 4 * i) for i in range(n)]
        o += u32(b, o + 4)
    lines, depth, root = [], 0, None
    stack = []
    while o < len(b):
        tp, hs, size = struct.unpack_from('<HHI', b, o)
        if tp == 0x0102:
            ns, name, ast, asz, ac = struct.unpack_from('<IIHHH', b, o + 16)
            attrs, prev = [], -1
            for i in range(ac):
                a = o + 16 + ast + i * asz
                ans, an, raw, vs, r0, dt, data = struct.unpack_from('<IIIHBBI', b, a)
                rid = ids[an] if an < len(ids) else None
                if rid is not None:
                    if rid <= prev: raise Bad('Attribute nicht nach Ressourcen-ID sortiert in <%s>' % strings[name])
                    prev = rid
                elif ans != 0xFFFFFFFF:
                    raise Bad('android-Attribut ohne Ressourcen-ID: %s' % strings[an])
                val = strings[data] if dt == 3 else data
                attrs.append((strings[an], rid, dt, val, ans != 0xFFFFFFFF))
            el = {'tag': strings[name], 'attrs': attrs, 'kids': []}
            if stack: stack[-1]['kids'].append(el)
            else: root = el
            stack.append(el)
        elif tp == 0x0103:
            stack.pop()
        o += size
    if stack: raise Bad('Elemente nicht geschlossen')
    return root


def xml_text(el, ind=0):
    def fmt(a):
        name, rid, dt, val, isns = a
        v = {1: lambda x: '@0x%08x' % x, 3: lambda x: x, 0x10: str, 0x11: lambda x: '0x%x' % x,
             0x12: lambda x: 'true' if x else 'false'}[dt](val)
        return '%s%s="%s"' % ('android:' if isns else '', name, v)
    s = '  ' * ind + '<%s %s>' % (el['tag'], ' '.join(fmt(a) for a in el['attrs']))
    return '\n'.join([s] + [xml_text(k, ind + 1) for k in el['kids']])


def attr(el, name):
    for a in el['attrs']:
        if a[0] == name: return a[3]
    return None


# ---------- resources.arsc ----------
def parse_arsc(b):
    if u16(b, 0) != 2 or u32(b, 4) != len(b): raise Bad('ARSC-Kopf')
    values, o = parse_pool(b, 12)
    if u16(b, o) != 0x0200: raise Bad('Paket erwartet')
    pkg = o
    pid = u32(b, pkg + 8)
    name = b[pkg + 12:pkg + 268].decode('utf-16-le').rstrip('\0')
    types, _ = parse_pool(b, pkg + u32(b, pkg + 268))
    keys, _ = parse_pool(b, pkg + u32(b, pkg + 276))
    q, end, res = pkg + u16(b, pkg + 2), pkg + u32(b, pkg + 4), {}
    while q < end:
        tp, hs, size = struct.unpack_from('<HHI', b, q)
        if tp == 0x0201:
            tid, cnt, estart = b[q + 8], u32(b, q + 12), u32(b, q + 16)
            density = u16(b, q + 20 + 14)
            for i in range(cnt):
                eo = u32(b, q + hs + 4 * i)
                if eo == 0xFFFFFFFF: continue
                e = q + estart + eo
                esz, efl, key = struct.unpack_from('<HHI', b, e)
                vsz, r0, dt, data = struct.unpack_from('<HBBI', b, e + esz)
                rid = (pid << 24) | (tid << 16) | i
                res[rid] = (types[tid - 1], keys[key], values[data] if dt == 3 else data, density)
        q += size
    return name, res


def main(path):
    apk = open(path, 'rb').read()
    entries, cd_off, eocd_off = parse_zip(apk)
    names = [e['name'] for e in entries]
    with zipfile.ZipFile(io.BytesIO(apk)) as z:
        if z.testzip() is not None: raise Bad('zipfile meldet Fehler')
        if sorted(z.namelist()) != sorted(names): raise Bad('zipfile sieht andere Einträge')
    if len(set(names)) != len(names): raise Bad('doppelte Einträge')
    for e in entries:
        if e['method'] == 0 and e['off'] % 4: raise Bad('nicht ausgerichtet: ' + e['name'])
    by = {e['name']: e for e in entries}
    if by['resources.arsc']['method'] != 0: raise Bad('resources.arsc muss unkomprimiert sein')
    cert = verify_v2(apk, cd_off, eocd_off)
    man = parse_axml(by['AndroidManifest.xml']['data'])
    print(xml_text(man))
    if man['tag'] != 'manifest': raise Bad('Wurzel ist nicht <manifest>')
    pkg = attr(man, 'package')
    sdk = [k for k in man['kids'] if k['tag'] == 'uses-sdk'][0]
    app = [k for k in man['kids'] if k['tag'] == 'application'][0]
    act = [k for k in app['kids'] if k['tag'] == 'activity'][0]
    if not attr(act, 'name').startswith(pkg + '.'): raise Bad('Activity nicht im Paket')
    if attr(act, 'exported') != 0xFFFFFFFF: raise Bad('Launcher-Activity muss exported=true sein')
    filt = [k for k in act['kids'] if k['tag'] == 'intent-filter'][0]
    acts = [attr(k, 'name') for k in filt['kids']]
    if acts != ['android.intent.action.MAIN', 'android.intent.category.LAUNCHER']: raise Bad('Intent-Filter')
    rname, res = parse_arsc(by['resources.arsc']['data'])
    if rname != pkg: raise Bad('Paketname in resources.arsc')
    icon = attr(app, 'icon')
    if icon not in res: raise Bad('Icon-Ressource fehlt')
    print('Ressourcen:')
    for rid in sorted(res):
        t, k, v, dens = res[rid]
        print('  0x%08x %s/%s -> %s (Dichte 0x%x)' % (rid, t, k, v, dens))
        if v not in by: raise Bad('Ressourcendatei fehlt: %s' % v)
    ic = parse_axml(by[res[icon][2]]['data'])
    if ic['tag'] != 'adaptive-icon': raise Bad('Icon ist kein adaptive-icon')
    for k in ic['kids']:
        d = attr(k, 'drawable')
        if d not in res: raise Bad('Icon-Ebene verweist ins Leere')
        png = by[res[d][2]]['data']
        if png[:8] != b'\x89PNG\r\n\x1a\n': raise Bad('PNG ungültig')
    # Assets: alles, was index.html lädt, muss vorhanden sein
    html = by['assets/index.html']['data'].decode('utf-8')
    for ref in re.findall(r'(?:src|href)="([^"#:]+)"', html):
        if 'assets/' + ref not in by: raise Bad('Asset fehlt: ' + ref)
    print('Zertifikat: %s, gültig bis %s, SHA-256 %s' % (cert.subject.rfc4514_string(), cert.not_valid_after_utc.date(),
                                                          cert.fingerprint(hashes.SHA256()).hex()[:32] + '…'))
    print('OK: %d Einträge, Signatur v2 gültig, minSdk %d, targetSdk %d, %.2f MB' % (
        len(entries), attr(sdk, 'minSdkVersion'), attr(sdk, 'targetSdkVersion'), len(apk) / 1e6))
    return by


if __name__ == '__main__':
    try:
        main(sys.argv[1])
    except Bad as e:
        print('FEHLER:', e)
        sys.exit(1)
