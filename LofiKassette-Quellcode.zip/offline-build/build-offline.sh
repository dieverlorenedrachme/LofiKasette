#!/usr/bin/env bash
# Baut die APK ohne Android-SDK und ohne Internet (nur JDK 17+, Python 3, python3-cryptography).
# Ablauf: javac gegen Stubs -> eigener DEX-Übersetzer -> DEX-Prüfung -> APK bauen + signieren -> APK-Prüfung
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="deliverables/LofiKassette-3.0.apk"
rm -rf build && mkdir -p build/stubs build/classes deliverables

JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"
$JAVAC -source 8 -target 8 -Xlint:-options -nowarn -d build/stubs $(find offline-build/android-stubs -name '*.java')
$JAVAC -source 8 -target 8 -Xlint:all -Xlint:-options -encoding UTF-8 -g:none -cp build/stubs -d build/classes app/src/de/lofikassette/app/*.java

python3 offline-build/dexgen.py build/classes.dex $(find build/classes -name '*.class' | sort)
python3 offline-build/dexcheck.py build/classes.dex

python3 offline-build/apkbuild.py app build/classes.dex "$OUT" lofikassette-development.p12 android
python3 offline-build/apkcheck.py "$OUT"
