#!/usr/bin/env python3
"""Erzeugt die Ebenen des adaptiven App-Icons (Kassette) als PNG, 432 x 432 px (108 dp @ 4x)."""
import sys
from PIL import Image, ImageDraw, ImageFilter

S = 432          # Zielgröße
K = 4            # Überabtastung für glatte Kanten
N = S * K
NIGHT, BODY, EDGE = (29, 24, 41), (58, 49, 80), (80, 69, 106)
CREAM, INK, WINDOW = (244, 233, 216), (42, 35, 56), (34, 28, 48)
STRIPES = [(244, 184, 105), (185, 163, 240), (134, 205, 184), (231, 160, 180)]
LAMP, TAPE = (244, 184, 105), (107, 77, 64)


def u(v):  # dp-Koordinate (0..108) -> Pixel in der Überabtastung
    return int(round(v * N / 108.0))


def rr(d, box, r, **kw):
    d.rounded_rectangle([u(box[0]), u(box[1]), u(box[2]), u(box[3])], radius=u(r), **kw)


def background():
    im = Image.new('RGB', (N, N), NIGHT)
    glow = Image.new('L', (N, N), 0)
    ImageDraw.Draw(glow).ellipse([u(14), u(52), u(94), u(128)], fill=120)
    glow = glow.filter(ImageFilter.GaussianBlur(u(14)))
    warm = Image.new('RGB', (N, N), (120, 78, 60))
    im = Image.composite(warm, im, glow)
    return im.resize((S, S), Image.LANCZOS)


def cassette(mono=False):
    im = Image.new('RGBA', (N, N), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    body = (255, 255, 255, 255) if mono else BODY + (255,)
    # Gehäuse: 64 x 42 dp, mittig in der 66-dp-Schutzzone
    x0, y0, x1, y1 = 22, 33, 86, 75
    rr(d, (x0, y0, x1, y1), 5, fill=body, outline=None if mono else EDGE + (255,), width=u(1.2))
    if mono:
        cut = (0, 0, 0, 0)
        rr(d, (x0 + 4, y0 + 4, x1 - 4, y0 + 25), 2.5, fill=cut)  # Etikett ausgespart
        rr(d, (38, 51, 70, 60), 3, fill=(255, 255, 255, 255))
        for cx in (45.5, 62.5):
            d.ellipse([u(cx - 3.2), u(55.5 - 3.2), u(cx + 3.2), u(55.5 + 3.2)], fill=cut)
        d.polygon([(u(34), u(75)), (u(37), u(68)), (u(71), u(68)), (u(74), u(75))], fill=cut)
        return shrink(im)
    # Etikett mit Farbstreifen
    rr(d, (x0 + 4, y0 + 4, x1 - 4, y0 + 25), 2.5, fill=CREAM + (255,))
    for i, c in enumerate(STRIPES):
        yy = y0 + 14 + i * 1.5
        d.rectangle([u(x0 + 4), u(yy), u(x1 - 4), u(yy + 1.1)], fill=c + (255,))
    # Handschrift-Andeutung auf dem Etikett
    import math
    for a, b in ((0, 40), (48, 96)):  # zwei "Wörter"
        pts = [(u(30 + k * 0.25), u(42 + 0.75 * math.sin(k * 0.33) - k * 0.01)) for k in range(a, b)]
        d.line(pts, fill=INK + (255,), width=u(1.1), joint='curve')
    # Fenster mit Spulen
    rr(d, (38, 51, 70, 60), 3, fill=WINDOW + (255,))
    d.ellipse([u(45.5 - 5.5), u(55.5 - 5.5), u(45.5 + 5.5), u(55.5 + 5.5)], fill=TAPE + (255,))
    d.ellipse([u(62.5 - 3.8), u(55.5 - 3.8), u(62.5 + 3.8), u(55.5 + 3.8)], fill=TAPE + (255,))
    for cx in (45.5, 62.5):
        d.ellipse([u(cx - 2.8), u(55.5 - 2.8), u(cx + 2.8), u(55.5 + 2.8)], fill=LAMP + (255,))
        d.ellipse([u(cx - 1.1), u(55.5 - 1.1), u(cx + 1.1), u(55.5 + 1.1)], fill=WINDOW + (255,))
    # Unterer Steg
    d.polygon([(u(34), u(75)), (u(37), u(68)), (u(71), u(68)), (u(74), u(75))], fill=EDGE + (255,))
    for cx in (41, 67):
        d.ellipse([u(cx - 1.3), u(71.5 - 1.3), u(cx + 1.3), u(71.5 + 1.3)], fill=WINDOW + (255,))
    return shrink(im)


def shrink(im, f=0.82):
    """Kassette in die 66-dp-Schutzzone verkleinern (Ecken innerhalb des Kreises)."""
    n = int(N * f)
    small = im.resize((n, n), Image.LANCZOS)
    out = Image.new('RGBA', (N, N), (0, 0, 0, 0))
    out.paste(small, ((N - n) // 2, (N - n) // 2 + u(1)))
    return out.resize((S, S), Image.LANCZOS)


def main(out_dir):
    background().save(out_dir + '/ic_launcher_background.png', optimize=True)
    cassette().save(out_dir + '/ic_launcher_foreground.png', optimize=True)
    cassette(mono=True).save(out_dir + '/ic_launcher_monochrome.png', optimize=True)
    # Vorschau wie im Launcher (Kreismaske, 72 dp sichtbar)
    bg, fg = Image.open(out_dir + '/ic_launcher_background.png').convert('RGBA'), Image.open(out_dir + '/ic_launcher_foreground.png')
    comp = Image.alpha_composite(bg, fg)
    crop = comp.crop((72, 72, 360, 360))
    mask = Image.new('L', crop.size, 0)
    ImageDraw.Draw(mask).ellipse([0, 0, crop.size[0] - 1, crop.size[1] - 1], fill=255)
    prev = Image.new('RGBA', crop.size, (255, 255, 255, 0))
    prev.paste(crop, (0, 0), mask)
    return prev


if __name__ == '__main__':
    p = main(sys.argv[1])
    if len(sys.argv) > 2:
        p.save(sys.argv[2])
